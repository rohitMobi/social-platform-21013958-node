//v7 imports

import admin from './api/v1/controllers/admin/routes';
import bid from './api/v1/controllers/bid/routes';
import nft from './api/v1/controllers/nft/routes';
import notification from './api/v1/controllers/notification/routes';
import socket from './api/v1/controllers/socket/routes';
import staticContent from './api/v1/controllers/static/routes';
import user from './api/v1/controllers/users/routes';
import cron from "./api/v1/controllers/cron/routes";

/**
 *
 *
 * @export
 * @param {any} app
 */

export default function routes(app) {

  app.use('/api/v1/admin', admin)
  app.use('/api/v1/bid', bid)
  app.use('/api/v1/nft', nft)
  app.use('/api/v1/notification', notification)
  app.use('/api/v1/socket', socket)
  app.use('/api/v1/static', staticContent)
  app.use('/api/v1/user', user)
  app.use('/api/v1/cron', cron)


  return app;
}
