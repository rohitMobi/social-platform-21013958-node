module.exports = Object.freeze({
    ACTIVE: 'ACTIVE',
    BLOCK: 'BLOCK',
    DELETE: 'DELETE',
    EXPIRED: 'EXPIRED',
    STOPPED:'STOPPED'
})