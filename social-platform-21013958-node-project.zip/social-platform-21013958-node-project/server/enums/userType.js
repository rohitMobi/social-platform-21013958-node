module.exports = Object.freeze({
    ADMIN: 'Admin',
    USER: 'User',
    SUBADMIN: 'Subadmin',
    CREATOR: 'Creator'
})