import Mongoose, { Schema } from "mongoose";
import status from '../enums/status';
import mongoosePaginate from "mongoose-paginate";
import mongooseAggregatePaginate from "mongoose-aggregate-paginate";
const options = {
    collection: "collection",
    timestamps: true
};

const schemaDefination = new Schema(
    {
        userId: {
            type: Schema.Types.ObjectId,
            ref: 'user'
        },
        amount:{
            type:String
        },
        contractAddress: {
            type: String
        },
        name: {
            type: String
        },
        title: {
            type: String
        },
        baseURI: {
            type: String
        },
        image: {
            type: String
        },
        description: {
            type: String
        },
        categoryType: {
            type: String
        },
        duration:{
            type: String 
        },
        likesUsers: [{
            type: Schema.Types.ObjectId,
            ref: 'user'
        }],
        subscriptionUsers: [{
            type: Schema.Types.ObjectId,
            ref: 'user'
        }],
        subscriptionCount: {
            type: Number
        },
        likesCount: {
            type: Number
        },
        status: { type: String, default: status.ACTIVE }
    },
    options
);

schemaDefination.plugin(mongoosePaginate);
schemaDefination.plugin(mongooseAggregatePaginate);
module.exports = Mongoose.model("collection", schemaDefination);

