import Mongoose, { Schema } from "mongoose";
import mongoosePaginate from "mongoose-paginate";
import mongooseAggregatePaginate from "mongoose-aggregate-paginate";
import status from '../enums/status';

const options = {
    collection: "hashTag",
    timestamps: true,
};

const hashTagModel = new Schema(
    {
        hashTagName: { type: String },
        postCount: { type: Number, default: 0 },
        reelsCount: { type: Number, default: 0 },
        userCount: { type: Number, default: 0 },
        postDetails: [{
            postId: {
                type: Schema.Types.ObjectId,
                ref: 'post'
            },
        }],
        reelsDetails: [{
            reelsId: {
                type: Schema.Types.ObjectId,
                ref: 'reels'
            },
        }],
        status: { type: String, default: status.ACTIVE },
    },
    options
);
hashTagModel.plugin(mongoosePaginate);
hashTagModel.plugin(mongooseAggregatePaginate);
module.exports = Mongoose.model("hashTag", hashTagModel);

Mongoose.model("hashTag", hashTagModel).find({ status: status.ACTIVE }, async (err, result) => {
    if (err) {
        console.log("Default hashTag creation error", err);
    }
    else if (result.length != 0) {
        console.log("Default hashTag already created.");
    }
    else {
        var obj = {
            hashTagName: "#motivation",
            status: status.ACTIVE
        }
        var obj1 = {
            hashTagName: "#music",
            status: status.ACTIVE
        }
        var obj2 = {
            hashTagName: "#love",
            status: status.ACTIVE
        }
        var obj3 = {
            hashTagName: "#fashion",
            status: status.ACTIVE
        }
        var obj4 = {
            hashTagName: "#beautiful",
            status: status.ACTIVE
        }
        var obj5 = {
            hashTagName: "#art",
            status: status.ACTIVE
        }
        var obj6 = {
            hashTagName: "#happy",
            status: status.ACTIVE
        }
        var obj7 = {
            hashTagName: "#cute",
            status: status.ACTIVE
        }
        var obj8 = {
            hashTagName: "#nature",
            status: status.ACTIVE
        }
        var obj9 = {
            hashTagName: "#style",
            status: status.ACTIVE
        }
        var obj10 = {
            hashTagName: "#repost",
            status: status.ACTIVE
        }
        var obj11 = {
            hashTagName: "#smile",
            status: status.ACTIVE
        }
        var obj12 = {
            hashTagName: "#photo",
            status: status.ACTIVE
        }
        var obj13 = {
            hashTagName: "#life",
            status: status.ACTIVE
        }
        var obj14 = {
            hashTagName: "#amazing",
            status: status.ACTIVE
        }
        var obj15 = {
            hashTagName: "#enjoying",
            status: status.ACTIVE
        }
        var obj16 = {
            hashTagName: "#goodDay",
            status: status.ACTIVE
        }
        var obj17 = {
            hashTagName: "#boaringDay",
            status: status.ACTIVE
        }
        var obj18 = {
            hashTagName: "#sunset",
            status: status.ACTIVE
        }
        var obj19 = {
            hashTagName: "#like",
            status: status.ACTIVE
        }
        var obj20 = {
            hashTagName: "#disLike",
            status: status.ACTIVE
        }
        var obj21 = {
            hashTagName: "#trending",
            status: status.ACTIVE
        }
        Mongoose.model("hashTag", hashTagModel).create(
            obj, obj1, obj2, obj3, obj4, obj5, obj6, obj7, obj8, obj9, obj10, obj11, obj12, obj13, obj14, obj15, obj16, obj17, obj18, obj19, obj20, obj21,
            (err1, staticResult) => {
                if (err1) {
                    console.log("Default hash tag error.", err1);
                }
                else {
                    console.log("Default hash tag created.", staticResult)
                }
            })
    }
})


