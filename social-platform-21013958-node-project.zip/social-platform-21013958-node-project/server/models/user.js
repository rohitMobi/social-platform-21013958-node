import config from "config";
import axios from 'axios';
import bcrypt from 'bcryptjs';
import Mongoose, { Schema } from "mongoose";
import mongoosePaginate from "mongoose-paginate";
import mongooseAggregatePaginate from "mongoose-aggregate-paginate";
import userType from "../enums/userType";
import status from '../enums/status';
import commonFunction from '../../server/helper/util';
import { required } from "joi/lib/types/lazy";
const mnemonic = config.get('mnemonic');
import binance from '../api/v1/binance/binance'

const options = {
  collection: "user",
  timestamps: true,
};

const userModel = new Schema(
  {
    walletAddress: { type: String },
    bnbAccount: {
      address: { type: String },
      privateKey: { type: String }
    },
    hastack: { type: String },
    ip: { type: String },
    firstName: { type: String },
    lastName: { type: String },
    name: { type: String },
    userName: { type: String, default: "" },
    email: { type: String, default: "" },
    dob: { type: String },
    gender: { type: String },
    profilePic: { type: String },
    coverPic: { type: String },
    massPageUrl: { type: String },
    bio: { type: String },
    facebook: { type: String },
    twitter: { type: String },
    instagram: { type: String },
    linkedIn: { type: String },
    location: { type: String },
    countryCode: { type: String },
    noOfBundle: { type: Number, default: 0 },
    mobileNumber: { type: String, default: "" },
    userType: { type: String, default: userType.USER },
    socialId: { type: String },
    socialType: { type: String },
    password: { type: String },
    planType: { type: String, default: "Basic" },
    pass: { type: String },
    twoFAUrl: { type: String },
    base32: { type: String },
    deviceToken: { type: String },
    deviceType: { type: String },
    referralCode: { type: String },
    refereeCode: { type: String },
    isReset: { type: Boolean },
    otp: { type: Number },
    subscriberCount: { type: Number, default: 0 },
    emailVerification: { type: Boolean, default: false },
    otpVerification: { type: Boolean, default: false },
    otpTime: { type: Number },
    blockStatus: { type: Boolean, default: false },
    isUpdated: { type: Boolean, default: false },
    // isNewUser: { type: Boolean, default: true },
    // massBalance: { type: Number, default: 0 },
    // usdtBalance: { type: Number, default: 0 },
    // ethBalance: { type: Number, default: 0 },
    bnbBalace: { type: Number, default: 0 },
    adminTotalToken: { type: Number, default: 0 },
    // btcBalance: { type: Number, default: 0 },
    isSocial: { type: Boolean, default: false },
    isStory: { type: Boolean, default: false },
    isOnline: { type: Boolean, default: false },
    isPost: { type: Boolean, default: false },
    subscribePlan: [{
      type: Schema.Types.ObjectId,
      ref: 'plan'
    }],
    subscribers: [{
      type: Schema.Types.ObjectId,
      ref: 'user'
    }],
    followers: [{
      type: Schema.Types.ObjectId,
      ref: 'user'
    }],
    followersCount: {
      type: Number,
      default: 0
    },
    following: [{
      type: Schema.Types.ObjectId,
      ref: 'user'
    }],
    interest: [{
      type: String
    }],
    followingCount: {
      type: Number,
      default: 0
    },
    supporters: [{
      type: Schema.Types.ObjectId,
      ref: 'user'
    }],
    blockedUser: [{
      type: Schema.Types.ObjectId,
      ref: 'user'
    }],
    myWatchlist: [{
      type: Schema.Types.ObjectId,
      ref: 'post'
    }],
    likesCollection: [{
      type: Schema.Types.ObjectId,
      ref: 'collection'
    }],
    likesSubscription: [{
      type: Schema.Types.ObjectId,
      ref: 'collectionSubscription'
    }],
    likesPost: [{
      type: Schema.Types.ObjectId,
      ref: 'post'
    }],
    likesCommentOnPostPromotionId: [{
      type: String
    }],
    likesCommentOnReelsId: [{
      type: String
    }],
    likesPostPromotion: [{
      type: Schema.Types.ObjectId,
      ref: 'postPromotion'
    }],
    likesReels: [{
      type: Schema.Types.ObjectId,
      ref: 'reels'
    }],
    likesAuction: [{
      type: Schema.Types.ObjectId,
      ref: 'auctionNft'
    }],
    likesCommentOnPostId: [{
      type: String
    }],
    mightUser: [{
      type: Schema.Types.ObjectId,
      ref: 'user'
    }],
    ignoreUser: [{
      type: Schema.Types.ObjectId,
      ref: 'user'
    }],
    saveReels: [{
      type: Schema.Types.ObjectId,
      ref: 'reels'
    }],
    hidePost: [{
      type: Schema.Types.ObjectId,
      ref: 'post'
    }],
    notifications: {
      like: { type: Boolean, default: true },
      comment: { type: Boolean, default: true },
      mention: { type: Boolean, default: true },
      post: { type: Boolean, default: true },
      share: { type: Boolean, default: true },
      follow: { type: Boolean, default: true },
      event: { type: Boolean, default: true },
      collection: { type: Boolean, default: true },
      subscribe: { type: Boolean, default: true },
    },
    permissions: {
      collectionManagement: { type: Boolean, default: false },
      postManagement: { type: Boolean, default: false },
      notificationManagement: { type: Boolean, default: false },
      auctionManagement: { type: Boolean, default: false },
      feeManagement: { type: Boolean, default: false },
      userManagement: { type: Boolean, default: false }
    },
    signupBonus: { type: Number, default: 0 },
    refferralBonus: { type: Number, default: 0 },
    firstTime: { type: Boolean, default: false },
    status: { type: String, default: status.ACTIVE }
  },
  options
);
userModel.plugin(mongoosePaginate);
userModel.plugin(mongooseAggregatePaginate);
module.exports = Mongoose.model("user", userModel);

Mongoose.model("user", userModel).find({ userType: userType.ADMIN }, async (err, result) => {
  if (err) {
    console.log("Default admin creation error", err);
  }
  else if (result.length != 0) {
    console.log("Default admin already created.");
  }
  else {
    let binanceRes = await binance.generateBNBWallet(0, `${mnemonic}`);
    var obj = {
      name: "Vishnu",
      userName: "vishnu@123",
      email: "no-vishnu@mobiloitte.com",
      bnbAccount: {
        address: binanceRes.address,
        privateKey: binanceRes.privateKey
      },
      password: bcrypt.hashSync("Mobiloitte@1"),
      referralCode: await commonFunction.getReferralCode(),
      otpVerification: true,
      userType: userType.ADMIN,
      status: status.ACTIVE,
      gender: "Male",
      mobileNumber: "8521529565",
      permissions: {
        collectionManagement: true,
        postManagement: true,
        notificationManagement: true,
        auctionManagement: true,
        feeManagement: true,
        userManagement: true
      }
    }
    Mongoose.model("user", userModel).create(obj, (err1, staticResult) => {
      if (err1) {
        console.log("Default admin error.", err1);
      }
      else {
        console.log("Default admin created.", staticResult)
      }
    })
  }
})


