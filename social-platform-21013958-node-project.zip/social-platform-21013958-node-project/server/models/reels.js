import Mongoose, { Schema } from "mongoose";
import mongoosePaginate from "mongoose-paginate";
import mongooseAggregatePaginate from "mongoose-aggregate-paginate";
const options = {
    collection: "reels",
    timestamps: true
};
const schema = Mongoose.Schema;
var reelsSchema = new schema(
    {
        userId: {
            type: Schema.Types.ObjectId,
            ref: 'user'
        },
        details: {
            type: String
        },
        reelsurl: [{
            type: String
        }],
        likesCount: {
            type: Number,
            default: 0
        },
        LikesId: {
            type: Array
        },
        totalComment: {
            type: Number,
            default: 0
        },
        likesUsers: [{
            type: Schema.Types.ObjectId,
            ref: 'user'
        }],
        comment: [{
            userId: {
                type: Schema.Types.ObjectId,
                ref: 'user'
            },
            message: {
                type: String
            },
            totalReply: {
                type: Number,
                default: 0
            },
            likesUsers: [{
                type: Schema.Types.ObjectId,
                ref: 'user'
            }],
            likesCount: {
                type: Number,
                default: 0
            },
            time: { type: String },
            reply: [{
                userId: {
                    type: Schema.Types.ObjectId,
                    ref: 'user'
                },
                commentId: {
                    type: String
                },
                message: {
                    type: String
                },
                time: { type: String }
            }]
        }],
        viewUser: [{
            userId: {
                type: Schema.Types.ObjectId,
                ref: 'user'
            },
        }],
        reportedId: [{
            type: Schema.Types.ObjectId,
            ref: 'report'
        }],
        reportCount: {
            type: Number,
            default: 0
        },
        totalView: {
            type: Number,
            default: 0
        },
        hashTagId: [{
            type: Schema.Types.ObjectId,
            ref: 'hashTag'
        }],
        hashTagCount: {
            type: Number,
            default: 0
        },
        reelsShareUserId: [{
            type: Schema.Types.ObjectId,
            ref: 'user'
        }],
        reelsShareCount: {
            type: Number,
            default: 0
        },
        status: {
            type: String,
            enum: ["ACTIVE", "BLOCK", "DELETE"],
            default: "ACTIVE"
        },
    },
    options
);
reelsSchema.plugin(mongoosePaginate);
reelsSchema.plugin(mongooseAggregatePaginate);
module.exports = Mongoose.model("reels", reelsSchema);