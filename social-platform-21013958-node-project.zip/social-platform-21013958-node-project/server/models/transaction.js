import Mongoose, { Schema } from "mongoose";
import status from '../enums/status';
import mongoosePaginate from "mongoose-paginate";
import mongooseAggregatePaginate from "mongoose-aggregate-paginate";

const options = {
    collection: "transaction",
    timestamps: true
};

const schemaDefination = new Schema(
    {
        userId: {
            type: Schema.Types.ObjectId,
            ref: 'user'
        },
        acutionId: {
            type: Schema.Types.ObjectId,
            ref: 'auctionNft'
        },
        bidId: {
            type: Schema.Types.ObjectId,
            ref: 'bid'
        },
        nftId: {
            type: Schema.Types.ObjectId,
            ref: 'nft'
        },
        nftUserId: {
            type: Schema.Types.ObjectId,
            ref: 'user'
        },
        planId: {
            type: Schema.Types.ObjectId,
            ref: 'plan'
        },
        postId: {
            type: Schema.Types.ObjectId,
            ref: 'post'
        },
        collectionId: {
            type: Schema.Types.ObjectId,
            ref: 'collection'
        },
        subscriptionId: {
            type: Schema.Types.ObjectId,
            ref: 'collectionSubscription'
        },
        promotionId: {
            type: Schema.Types.ObjectId,
            ref: 'postPromotion'
        },
        planUserId: {
            type: Schema.Types.ObjectId,
            ref: 'user'
        },
        referrarId: {
            type: Schema.Types.ObjectId,
            ref: 'user'
        },
        toDonationUser: {
            type: Schema.Types.ObjectId,
            ref: 'user'
        },
        commission: { type: Number },
        amount: { type: Number },
        transactionHash: { type: String },
        coinName: { type: String },
        fromAddress: { type: String },
        toAddress: { type: String },
        transactionStatus: { type: String, enum: ["PENDING", "SUCCESS", "FAILED"], default: "SUCCESS" },
        transactionType: {
            type: String,
            enum: [
                "BUY_AUCTION",
                "SOLD_AUCTION",
                "BUY_POST",
                "SOLD_POST",
                "COLLECTION_SHARE_AMOUNT",
                "COLLECTION_RECEIVE_AMOUNT",
                "COLLECTION_SUBSCRIBE_RECEIVE_COMMISSION",
                "COLLECTION_SUBSCRIBE_SHARE",
                "COLLECTION_SUBSCRIBE_RECEIVE",
                "DEPOSIT_FOR_ADMIN",
                "DEPOSIT_FOR_USER",
                "WITHDRAW_FOR_ADMIN",
                "WITHDRAW_FOR_USER",
                "POST_PROMOTION_RECEIVE",
                "POST_PROMOTION_SHARE",
                "AMOUNT_RECEIVED",
                "BUY_POST_RECEIVE_COMMISSION",
                "BUY_AUCTION_RECEIVE_COMMISSION",
                "BID_ACCEPT_RECEIVE_COMMISSION",
                "REFERRAL_FOR_ADMIN",
                "REFERRAL_FOR_USER",
                "SIGNUP_FOR_ADMIN",
                "SIGNUP_FOR_USER"
            ]
        },
        status: { type: String, default: status.ACTIVE }
    },
    options
);
schemaDefination.plugin(mongoosePaginate);
schemaDefination.plugin(mongooseAggregatePaginate);
module.exports = Mongoose.model("transaction", schemaDefination);

