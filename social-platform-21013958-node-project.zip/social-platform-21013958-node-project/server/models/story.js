import Mongoose, { Schema } from "mongoose";
import mongoosePaginate from "mongoose-paginate";
import mongooseAggregatePaginate from "mongoose-aggregate-paginate";
const options = {
    collection: "story",
    timestamps: true
};
const schema = Mongoose.Schema;
var storySchema = new schema(
    {
        userId: {
            type: String
        },
        details: {
            type: String
        },
        story: [{
            type: String
        }],
        likes: {
            type: Number,
            default: 0
        },
        LikesId: {
            type: Array
        },
        totalComment: {
            type: Number,
            default: 0
        },
        comment: [{
            commentId: {
                type: String
            },
            message: {
                type: String
            },
            totalReply: {
                type: Number,
                default: 0
            },
            reply: [{
                commentId: {
                    type: String
                },
                message: {
                    type: String
                },
            }]
        }],
        viewUser: [{
            userId: {
                type: Schema.Types.ObjectId,
                ref: 'user'
            },
            visible: {
                type: Boolean,
                default: false
            },
        }],
        totalView: {
            type: Number,
            default: 0
        },
        timeExpired: {
            type: String
        },
        visible: {
            type: Boolean,
            default: false
        },
        storyType: {
            type: String,
            enum: ["PRIVATE", "PUBLIC"],
            default: "PUBLIC"
        },
        status: {
            type: String,
            enum: ["ACTIVE", "BLOCK", "DELETE"],
            default: "ACTIVE"
        },
    },
    options
);
storySchema.plugin(mongoosePaginate);
storySchema.plugin(mongooseAggregatePaginate);
module.exports = Mongoose.model("story", storySchema);