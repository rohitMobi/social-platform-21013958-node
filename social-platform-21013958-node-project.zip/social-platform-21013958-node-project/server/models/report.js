import Mongoose, { Schema } from "mongoose";
import mongoosePaginate from "mongoose-paginate";
import mongooseAggregatePaginate from "mongoose-aggregate-paginate";
const options = {
    collection: "report",
    timestamps: true
};
const schema = Mongoose.Schema;
var reportSchema = new schema(
    {
        postId: {
            type: schema.Types.ObjectId,
            ref: 'post'
        },
        commentId: {
            type: schema.Types.ObjectId,
            ref: 'post'
        },
        reelsId: {
            type: schema.Types.ObjectId,
            ref: 'reels'
        },
        auctionId: {
            type: schema.Types.ObjectId,
            ref: 'auctionNft'
        },
        auctionNftId: {
            type: Schema.Types.ObjectId,
            ref: 'auctionNft'
        },
        orderId: {
            type: Schema.Types.ObjectId,
            ref: 'order'
        },
        userId: {
            type: Schema.Types.ObjectId,
            ref: 'user'
        },
        userName: {
            type: String
        },
        message: {
            type: String
        },
        actionApply: {
            type: Boolean, default: false
        },
        type: {
            type: String,
            enum: ["POST", "AUCTION","REELS"],
        },
        status: {
            type: String,
            enum: ["ACTIVE", "BLOCK", "DELETE"],
            default: "ACTIVE"
        },
    },
    options
);
reportSchema.plugin(mongoosePaginate);
reportSchema.plugin(mongooseAggregatePaginate);
module.exports = Mongoose.model("report", reportSchema);