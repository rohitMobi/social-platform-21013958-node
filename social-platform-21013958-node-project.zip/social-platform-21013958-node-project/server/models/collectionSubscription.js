import Mongoose, { Schema } from "mongoose";
import status from '../enums/status';
import mongoosePaginate from "mongoose-paginate";
import mongooseAggregatePaginate from "mongoose-aggregate-paginate";
const options = {
    collection: "collectionSubscription",
    timestamps: true
};

const collectionSubscriptionDefination = new Schema(
    {
        userId: {
            type: Schema.Types.ObjectId,
            ref: 'user'
        },
        collectionId: {
            type: Schema.Types.ObjectId,
            ref: 'collection'
        },
        duration:{
            type: String 
        },
        amount:{
            type: String 
        },
        subscriptionStatus:{
            type: String,
            enum:["SUBSCRIBE","UNSUBSCRIBE"] 
        },
        likesUsers: [{
            type: Schema.Types.ObjectId,
            ref: 'user'
        }],
        likesCount: {
            type: Number
        },
        status: { type: String, default: status.ACTIVE }
    },
    options
);

collectionSubscriptionDefination.plugin(mongoosePaginate);
collectionSubscriptionDefination.plugin(mongooseAggregatePaginate);
module.exports = Mongoose.model("collectionSubscription", collectionSubscriptionDefination);

