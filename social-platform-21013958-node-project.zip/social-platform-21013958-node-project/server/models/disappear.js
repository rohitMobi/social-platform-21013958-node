import Mongoose, { Schema } from "mongoose";
import status from '../enums/status';

const options = {
  collection: "disappear",
  timestamps: true,
};
const appearModel = new Schema(
  {
    disappear: { type: Boolean, default: false },
    time: { type: Number, default: 0 },
    senderId: {
      type: Mongoose.Schema.Types.ObjectId,
      ref: 'user'
    },
    receiverId: {
      type: Mongoose.Schema.Types.ObjectId,
      ref: 'user'
    },
    status: { type: String, default: status.ACTIVE },
  },
  options
);
module.exports = Mongoose.model("disappear", appearModel);



