import Mongoose, { Schema } from "mongoose";
import status from '../enums/status';
import mongoosePaginate from "mongoose-paginate";
import mongooseAggregatePaginate from "mongoose-aggregate-paginate";

const schemaDefination = new Schema(
    {
        userId: {
            type: Schema.Types.ObjectId,
            ref: 'user'
        },
        postId: {
            type: Schema.Types.ObjectId,
            ref: 'post'
        },
        likesUsers: [{
            type: Schema.Types.ObjectId,
            ref: 'user'
        }],
        likesCount: {
            type: Number,
            default: 0
        },
        dateTime: { type: String },
        url: { type: String },
        comment: [{
            userId: {
                type: Schema.Types.ObjectId,
                ref: 'user'
            },
            message: {
                type: String
            },
            totalReply: {
                type: Number,
                default: 0
            },
            likesUsers: [{
                type: Schema.Types.ObjectId,
                ref: 'user'
            }],
            likesCount: {
                type: Number,
                default: 0
            },
            time: { type: String },
            reply: [{
                userId: {
                    type: Schema.Types.ObjectId,
                    ref: 'user'
                },
                commentId: {
                    type: String
                },
                message: {
                    type: String
                },
                time: { type: String }
            }]
        }],
        totalComment: {
            type: Number,
            default: 0
        },
        postTitle: {
            type: String
        },
        amount: {
            type: String
        },
        tag: [{
            type: Schema.Types.ObjectId,
            ref: 'user'
        }],
        interest: [{
            type: String
        }],
        mediaUrl: {
            type: String
        },
        minAge: {
            type: String
        },
        maxAge: {
            type: String
        },
        details: {
            type: String
        },
        reportedId: [{
            type: Schema.Types.ObjectId,
            ref: 'report'
        }],
        likesReportCount: {
            type: Number,
            default: 0
        },
        isSubscribed: {
            type: Boolean,
            default: true
        },
        type: {
            type: String
        },
        reactOnPostPromoted: { type: Array },
        reactOnPostPromotedCount: {
            type: Number,
            default: 0
        },
        status: { type: String, default: status.ACTIVE }
    },
    { timestamps: true }
);

schemaDefination.plugin(mongoosePaginate);
schemaDefination.plugin(mongooseAggregatePaginate);
module.exports = Mongoose.model("postPromotion", schemaDefination);