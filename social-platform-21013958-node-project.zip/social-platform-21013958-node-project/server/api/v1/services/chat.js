// import chatModel from "../../../models/chatting";
// import userModel from "../../../models/user";


// const chatServices = {

//     createChat: async (insertObj) => {
//         return await chatModel.create(insertObj);
//     },

//     findChat: async (query) => {
//         return await chatModel.findOne(query);
//     },

//     updateChat: async (query, updateObj) => {
//         return await chatModel.findOneAndUpdate(query, updateObj, { new: true }).populate([{ path: "senderId", select: 'first_name last_name email avatar_hash' }, { path: "receiverId", select: 'first_name last_name email avatar_hash' }, { path: 'groupId', select: 'groupName groupImage' }, { path: "messages.senderId", select: 'first_name last_name email avatar_hash' }]);
//     },

//     viewChat: async (query) => {
//         return await chatModel.findOne(query).populate([{ path: "senderId", select: 'first_name last_name email avatar_hash' }, { path: "receiverId", select: 'first_name last_name email avatar_hash' }, { path: 'groupId', select: 'groupName groupImage' }, { path: "messages.senderId", select: 'first_name last_name email avatar_hash' }]);
//     },

//     findChatMessage: async (chatId, messageId) => {
//         return await chatModel.findOne({ _id: chatId, "messages._id": messageId }).select({ messages: { $elemMatch: { _id: messageId } } });
//     },

//     findChatMessages: async (chatId, messageId) => {
//         return await chatModel.findOne({ _id: chatId, "messages._id": { $in: messageId } });
//     },

//     updateMessage: async (query, updateObj) => {
//         return await chatModel.findOneAndUpdate(query, updateObj, { new: true });
//     },

//     findChatWithPopulate: async (validatedBody, query) => {
//         const { page, limit, search } = validatedBody;
//         if (search) {
//             query.messages = { $elemMatch: { message: { $regex: search, $options: 'i' } } }
//         }

//         let options = {
//             page: parseInt(page) || 1,
//             limit: parseInt(limit) || 10,
//             sort: { "messages.createdAt": -1 },
//             populate: ([{ path: "senderId", select: 'first_name last_name email avatar_hash' }, { path: "receiverId", select: 'first_name last_name email avatar_hash' }, { path: 'groupId', select: 'groupName groupImage' }, { path: "messages.senderId", select: 'first_name last_name email avatar_hash' }])
//         };
//         return await chatModel.paginate(query, options);

//     },

//     chatList: async (query) => {
//         return await chatModel.find(query);
//     },


//     findChatAndPopulate: async (query) => {
//         return await chatModel.findOne(query).select('-senderId -receiverId -chatType -messages -clearStatus')
//     },

//     // chatList: async (query) => {
//     //     let activeIds = await getActiveUser();
//     //     query.userId = { $in: activeIds };
//     //     return await chatModel.find(query);
//     // }
// }

// module.exports = { chatServices };


// const getActiveUser = async () => {
//     let userId = await userModel.find({ blockStatus: false }).select('_id');
//     userId = userId.map(i => i._id);
//     return userId;
// }



import chatModel from "../../../models/chatting";
import userModel from "../../../models/user";


const chatServices = {

    createChat: async (insertObj) => {
        return await chatModel.create(insertObj);
    },

    findChat: async (query) => {
        return await chatModel.findOne(query).populate('senderId receiverId messages.receiverId');
    },

    updateChat: async (query, updateObj) => {
        return await chatModel.findOneAndUpdate(query, updateObj, { new: true });
    },

    chatList: async (query) => {
        let activeIds = await getActiveUser();
        query.userId = { $in: activeIds };
        return await chatModel.find(query).populate('senderId receiverId messages.receiverId');
    }
}

module.exports = { chatServices };


const getActiveUser = async () => {
    let userId = await userModel.find({ blockStatus: false }).select('_id');
    userId = userId.map(i => i._id);
    console.log(userId, typeof (userId[0]))
    return userId;
}