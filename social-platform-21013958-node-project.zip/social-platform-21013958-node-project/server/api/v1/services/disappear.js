import disappearModel from "../../../models/disappear";

const disappearServices = {

    findDisappear: async (query) => {
        return await disappearModel.findOne(query);
    },
    createDisappear: async (insertObj) => {
        return await disappearModel.create(insertObj);
    },
    updateDisappear: async (query, updateObj) => {
        return await disappearModel.findOneAndUpdate(query, updateObj, { new: true });
    },

}

module.exports = { disappearServices };