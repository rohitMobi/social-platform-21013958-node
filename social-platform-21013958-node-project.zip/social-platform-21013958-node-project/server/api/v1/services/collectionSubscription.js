import collectionSubscriptionModel from "../../../models/collectionSubscription";

const collectionSubscriptionServices = {

    createCollectionSubscription: async (insertObj) => {
        return await collectionSubscriptionModel.create(insertObj);
    },

    findCollectionSubscription: async (query) => {
        return await collectionSubscriptionModel.findOne(query).populate("collectionId userId");
    },

    updateCollectionSubscription: async (query, updateObj) => {
        return await collectionSubscriptionModel.findOneAndUpdate(query, updateObj, { new: true });
    },
    collectionSubscriptionList: async (query) => {
        return await collectionSubscriptionModel.find(query).populate("collectionId userId");
    },
    collectionSubscriptionUserList: async (query) => {
        return await collectionSubscriptionModel.find(query).populate("collectionId userId");
    },
    userSubscribeCollectionList: async (query) => {
        return await collectionSubscriptionModel.find(query).populate('collectionId userId');
    },
}

module.exports = { collectionSubscriptionServices };