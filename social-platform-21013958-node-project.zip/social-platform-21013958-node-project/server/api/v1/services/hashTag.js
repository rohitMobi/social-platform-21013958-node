import hashModel from "../../../models/hashTag";
import status from '../../../enums/status';

const hashTagServices = {

    createHashTag: async (insertObj) => {
        return await hashModel.create(insertObj);
    },
    findHashTag: async (query) => {
        return await hashModel.findOne(query).populate([{ path: 'postDetails.postId reelsDetails.reelsId', populate: { path: "userId" } }]).sort({ createdAt: -1 });
    },

    updateHashTag: async (query, updateObj) => {
        return await hashModel.findOneAndUpdate(query, updateObj, { new: true });
    },
    hashTagList: async (query) => {
        return await hashModel.find(query);
    },

    paginateHashTagSearch: async (validatedBody) => {
        let query = { status: { $ne: status.DELETE } }
        const { search, fromDate, toDate, page, limit } = validatedBody;
        if (search) {
            query.$or = [
                { hashTagName: { $regex: search, $options: 'i' } },
            ]
        }
        if (fromDate && !toDate) {
            query.createdAt = { $gte: fromDate };
        }
        if (!fromDate && toDate) {
            query.createdAt = { $lte: toDate };
        }
        if (fromDate && toDate) {
            query.$and = [
                { createdAt: { $gte: fromDate } },
                { createdAt: { $lte: toDate } },
            ]
        }
        let options = {
            page: parseInt(page) || 1,
            limit: parseInt(limit) || 10,
            sort: { createdAt: -1 },
            // populate: ('userId comment.userId comment.reply.userId')
            // populate: { path: 'userId comment.userId' }
        };
        return await hashModel.paginate(query, options);
    },

}

module.exports = { hashTagServices };

