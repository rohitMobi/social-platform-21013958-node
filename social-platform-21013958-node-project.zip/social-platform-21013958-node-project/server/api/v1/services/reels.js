import reelsModel from  "../../../models/reels"
import status from '../../../enums/status';

const reelsServices={
    createReels: async (insertObj) => {
        return await reelsModel.create(insertObj);
    },
    findReels: async (query) => {
        return await reelsModel.findOne(query).populate('userId comment.userId comment.reply.userId');
    },
    updateReelsById: async (query, updateObj) => {
        return await reelsModel.findByIdAndUpdate(query, updateObj, { new: true });
    },
    updateReels: async (query, updateObj) => {
        return await reelsModel.findOneAndUpdate(query, updateObj, { new: true });
    },
    reelsList: async (query) => {
        return await reelsModel.find(query) 
    },
    paginateSearchReels: async (validatedBody) => {
        let query = { status: { $ne: status.DELETE } };
        const { page, limit } = validatedBody;
        let options = {
            page: parseInt(page) || 1,
            limit: parseInt(limit) || 15,
            sort: { createdAt: -1 },
            populate: ('userId comment.userId comment.reply.userId')
        };
        return await reelsModel.paginate(query, options);
    },
    deleteReelsComment: async (validatedBody) => {
        return await reelsModel.findOneAndUpdate({ _id: validatedBody.reelsId, 'comment._id': validatedBody.commentId }, { $pull: { comment: { _id: validatedBody.commentId } }, $inc: { totalComment: -1 } }, { new: true });
    },
}

module.exports = { reelsServices };