import collectionModel from "../../../models/collection";
import userModel from "../../../models/user";
import status from '../../../enums/status';


const collectionServices = {

    createCollection: async (insertObj) => {
        return await collectionModel.create(insertObj);
    },

    findCollection: async (query) => {
        return await collectionModel.findOne(query).populate('userId');
    },

    updateCollection: async (query, updateObj) => {
        return await collectionModel.findOneAndUpdate(query, updateObj, { new: true });
    },

    collectionList: async (query) => {
        let activeIds = await getActiveUser();
        query.userId = { $in: activeIds };
        return await collectionModel.find(query);
    },
    collectionListAll: async (query) => {
        return await collectionModel.find(query).populate('userId');
    },
    findCollectionCount: async (query) => {
        return await collectionModel.count(query);
    },

    collectionPaginateSearch: async (validatedBody) => {
        let activeIds = await getActiveUser();
        let query = { status: { $ne: status.DELETE }, userId: { $in: activeIds } };
        const { search, fromDate, toDate, page, limit } = validatedBody;
        if (search) {
            query.$or = [
                { name: { $regex: search, $options: 'i' } },
                { symbol: { $regex: search, $options: 'i' } },
                { categoryType: { $regex: search, $options: 'i' } }
            ]
        }
        if (fromDate && !toDate) {
            query.createdAt = { $gte: fromDate };
        }
        if (!fromDate && toDate) {
            query.createdAt = { $lte: toDate };
        }
        if (fromDate && toDate) {
            query.$and = [
                { createdAt: { $gte: fromDate } },
                { createdAt: { $lte: toDate } },
            ]
        }
        let options = {
            page: page || 1,
            limit: limit || 10,
            sort: { createdAt: -1 },
            populate: ('userId')
        };
        return await collectionModel.paginate(query, options);
    },

    collectionSearchList: async (validatedBody) => {
        let activeIds = await getActiveUser();
        let query = { status: { $ne: status.DELETE }, userId: { $in: activeIds } };
        const { search, fromDate, toDate, page, limit } = validatedBody;
        if (search) {
            query.$or = [
                { name: { $regex: search, $options: 'i' } },
                { symbol: { $regex: search, $options: 'i' } },
                { categoryType: { $regex: search, $options: 'i' } }
            ]
        }
        if (fromDate && !toDate) {
            query.createdAt = { $gte: fromDate };
        }
        if (!fromDate && toDate) {
            query.createdAt = { $lte: toDate };
        }
        if (fromDate && toDate) {
            query.$and = [
                { createdAt: { $gte: fromDate } },
                { createdAt: { $lte: toDate } },
            ]
        }
        let options = {
            page: page || 1,
            limit: limit || 10,
            sort: { createdAt: -1 },
            populate: ('userId')
        };
        return await collectionModel.find(query);
    },

    myCollectionPaginateSearch: async (validatedBody, userId) => {
        let query = { $and: [{ status: { $ne: status.DELETE } }, { $or: [{ userId: userId }, { collectionType: "DEFAULT" }] }] }
        const { search, fromDate, toDate, page, limit } = validatedBody;
        if (search) {
            query.$or = [
                { name: { $regex: search, $options: 'i' } },
                { symbol: { $regex: search, $options: 'i' } },
            ]
        }
        if (fromDate && !toDate) {
            query.createdAt = { $gte: fromDate };
        }
        if (!fromDate && toDate) {
            query.createdAt = { $lte: toDate };
        }
        if (fromDate && toDate) {
            query.$and = [
                { createdAt: { $gte: fromDate } },
                { createdAt: { $lte: toDate } },
            ]
        }
        let options = {
            page: page || 1,
            limit: limit || 10,
            sort: { createdAt: -1 },
            populate: ('userId')
        };
        return await collectionModel.paginate(query, options);
    },
    allCollectionPaginateSearch: async (validatedBody) => {
        let query = { status: { $ne: status.DELETE }, userId: validatedBody.userId }
        const { search, fromDate, toDate, page, limit } = validatedBody;
        if (search) {
            query.$or = [
                { name: { $regex: search, $options: 'i' } },
                { symbol: { $regex: search, $options: 'i' } },
            ]
        }
        if (fromDate && !toDate) {
            query.createdAt = { $gte: fromDate };
        }
        if (!fromDate && toDate) {
            query.createdAt = { $lte: toDate };
        }
        if (fromDate && toDate) {
            query.$and = [
                { createdAt: { $gte: fromDate } },
                { createdAt: { $lte: toDate } },
            ]
        }
        let options = {
            page: page || 1,
            limit: limit || 10,
            sort: { createdAt: -1 },
            populate: ('userId')
        };
        return await collectionModel.paginate(query, options);
    },
    userCollectionListAll: async (query) => {
        return await collectionModel.find(query).select('_id');
    },
    collectionSearchListWithToken: async (validatedBody) => {
        let query = { status: { $ne: status.DELETE } };
        const { search, fromDate, toDate, page, limit } = validatedBody;
        if (search) {
            query.$or = [
                { name: { $regex: search, $options: 'i' } },
                { symbol: { $regex: search, $options: 'i' } },
                { categoryType: { $regex: search, $options: 'i' } }
            ]
        }
        if (fromDate && !toDate) {
            query.createdAt = { $gte: fromDate };
        }
        if (!fromDate && toDate) {
            query.createdAt = { $lte: toDate };
        }
        if (fromDate && toDate) {
            query.$and = [
                { createdAt: { $gte: fromDate } },
                { createdAt: { $lte: toDate } },
            ]
        }
        return await collectionModel.find(query).populate('userId').sort({amount:-1});
    },

}

module.exports = { collectionServices };


const getActiveUser = async () => {
    let userId = await userModel.find({ blockStatus: false }).select('_id');
    userId = userId.map(i => i._id);
    return userId;
}
