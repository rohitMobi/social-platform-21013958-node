
import collectionNftModel from "../../../models/collectionNft";
import userModel from "../../../models/user";
import status from '../../../enums/status';
import mongoose from "mongoose";


const collectionNftServices = {

    createCollectionNft: async (insertObj) => {
        return await collectionNftModel.create(insertObj);
    },

    findCollectionNft: async (query) => {
        return await collectionNftModel.findOne(query);
    },

    updateCollectionNft: async (query, updateObj) => {
        return await collectionNftModel.findOneAndUpdate(query, updateObj, { new: true });
    },

    CollectionNftList: async (query) => {
        // let activeIds = await getActiveUser();
        // query.userId = { $in: activeIds };
        return await collectionNftModel.find(query);
    },

    allNftAuctionList: async (validatedBody) => {
        let query = { status: { $ne: status.DELETE } };
        const { search, fromDate, toDate, page, limit } = validatedBody;
        if (search) {
            query.$or = [
                { tokenName: { $regex: search, $options: 'i' } },
                { tokenId: { $regex: search, $options: 'i' } },
                { title: { $regex: search, $options: 'i' } },
                { network: { $regex: search, $options: 'i' } },
                { details: { $regex: search, $options: 'i' } },
                { mediaType: { $regex: search, $options: 'i' } },
            ]
        }
        if (fromDate && !toDate) {
            query.createdAt = { $gte: fromDate };
        }
        if (!fromDate && toDate) {
            query.createdAt = { $lte: toDate };
        }
        if (fromDate && toDate) {
            query.$and = [
                { createdAt: { $gte: fromDate } },
                { createdAt: { $lte: toDate } },
            ]
        }
        let options = {
            page: page || 1,
            limit: limit || 10,
            sort: { createdAt: -1 },
            populate: [{ path: 'userId', select: '-ethAccount.privateKey' }]
        };
        return await collectionNftModel.paginate(query, options);
    },

}

module.exports = { collectionNftServices };

const getActiveUser = async () => {
    let userId = await userModel.find({ blockStatus: false }).select('_id');
    userId = userId.map(i => i._id);
    return userId;
}

// getActiveUser();
