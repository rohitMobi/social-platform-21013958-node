
import audienceModel from "../../../models/audience";
import userModel from "../../../models/user";
import status from '../../../enums/status';
import mongoose from "mongoose";


const audienceServices = {

    createAudience: async (insertObj) => {
        return await audienceModel.create(insertObj);
    },

    findAudience: async (query) => {
        return await audienceModel.findOne(query);
    },

    findAudience1: async (query) => {
        return await audienceModel.findOne(query).populate('userId nftId');
    },

    updateAudience: async (query, updateObj) => {
        return await audienceModel.findOneAndUpdate(query, updateObj, { new: true });
    },

    audienceList: async (userId, bundleIds) => {
        // let activeIds = await getActiveUser();
        return await audienceModel.aggregate([
            { $match: { status: { $ne: status.DELETE }, users: { $in: [userId] }, nftId: { $in: bundleIds } } },
            {
                $addFields: {
                    "isLike": {
                        $cond: {
                            if: { $in: [mongoose.Types.ObjectId(userId), "$likesUsers"] },
                            then: true,
                            else: false
                        }
                    }
                }
            },
            {
                $lookup: {
                    "from": "nft",
                    "let": { "nft_id": "$nftId" },
                    pipeline: [
                        {
                            "$match": {
                                "$expr": {
                                    $in: ["$_id", "$$nft_id"]
                                },
                            }
                        },
                        {
                            $lookup: {
                                from: "user",
                                localField: "userId",
                                foreignField: "_id",
                                as: "userId"
                            }
                        },
                        { $unwind: "$userId" },
                        { $project: { "userId.ethAccount.privateKey": 0, "userId.password": 0 } }
                    ],
                    as: "nftId"
                }
            },
            // {
            //     $lookup: {
            //         from: "nft",
            //         localField: "nftId",
            //         foreignField: "_id",
            //         as: "nftId"
            //     }
            // },
            { $sort: { createdAt: -1 } },

        ])
        // return await audienceModel.find({ status: { $ne: status.DELETE }, users: { $in: userId }, nftId: { $in: bundleIds } }).populate({
        //     path: 'nftId',
        //     populate: {
        //         path: 'userId',
        //         model: 'user', select: { 'ethAccount.privateKey': 0 },
        //     }
        // })
    },

    postList: async (query) => {
        return await audienceModel.find(query);
    },
    postList1: async (query) => {
        return await audienceModel.find(query);
    },
    multiUpdate: async (updateObj) => {
        return await audienceModel.updateMany({}, updateObj, { multi: true });
    },

    feedUpdateAll: async (query, updateObj) => {
        return await audienceModel.updateMany(query, updateObj, { multi: true });
    },
}

module.exports = { audienceServices };

const getActiveUser = async () => {
    let userId = await userModel.find({ blockStatus: false }).select('_id');
    userId = userId.map(i => i._id);
    return userId;
}
