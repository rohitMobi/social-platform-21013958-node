
import notificationModel from "../../../models/notification";
import userModel from "../../../models/user";


const notificationServices = {

    createNotification: async (insertObj) => {
        return await notificationModel.create(insertObj);
    },

    findNotification: async (query) => {
        return await notificationModel.findOne(query).populate('userId likeBy commentBy subscriberId reportedBy promotionId postId reelsId collectionId subscriptionId storyId bidId buyId');
    },

    updateNotification: async (query, updateObj) => {
        return await notificationModel.findOneAndUpdate(query, updateObj, { new: true });
    },

    multiUpdateNotification: async (query, updateObj) => {
        return await notificationModel.updateMany(query, updateObj, { multi: true });
    },

    notificationList: async (query) => {
        let activeIds = await getActiveUser();
        query.userId = { $in: activeIds };
        return await notificationModel.find(query).populate('userId likeBy commentBy subscriberId reportedBy promotionId postId reelsId collectionId subscriptionId storyId bidId buyId');
    },

    notificationUserList: async (query) => {
        return await notificationModel.find(query).populate('userId likeBy commentBy subscriberId reportedBy promotionId postId reelsId collectionId subscriptionId storyId bidId buyId');
    },

    notificationListWithSort: async (query) => {
        // let activeIds = await getActiveUser();
        // query.userId = { $in: activeIds };
        return await notificationModel.find(query).populate('userId likeBy commentBy subscriberId reportedBy promotionId postId reelsId collectionId subscriptionId storyId bidId buyId').sort({ createdAt: -1 })
    },
    notificationDeleteMany: async (query) => {
        return await notificationModel.deleteMany(query);
    },

}

module.exports = { notificationServices };


const getActiveUser = async () => {
    let userId = await userModel.find({ blockStatus: false }).select('_id');
    userId = userId.map(i => i._id);
    return userId;
}
