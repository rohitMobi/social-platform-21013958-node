import storyModel from  "../../../models/story"
import status from '../../../enums/status';

const storyServices={
    createStory: async (insertObj) => {
        return await storyModel.create(insertObj);
    },
    findStory: async (query) => {
        return await storyModel.findOne(query);
    },
    updateStoryById: async (query, updateObj) => {
        return await storyModel.findByIdAndUpdate(query, updateObj, { new: true });
    },
    updateStory: async (query, updateObj) => {
        return await storyModel.findOneAndUpdate(query, updateObj, { new: true });
    },
    storyList: async (query) => {
        return await storyModel.find(query) 
    },
    paginateSearchStory: async (validatedBody) => {
        let query = { status: { $ne: status.DELETE },userId:validatedBody.userId ,visible:false};
        const { fromDate, toDate, page, limit } = validatedBody;

        if (fromDate && !toDate) {
            query.createdAt = { $gte: fromDate };
        }
        if (!fromDate && toDate) {
            query.createdAt = { $lte: toDate };
        }
        if (fromDate && toDate) {
            query.$and = [
                { createdAt: { $gte: fromDate } },
                { createdAt: { $lte: toDate } },
            ]
        }
        let options = {
            page: parseInt(page) || 1,
            limit: parseInt(limit) || 15,
            sort: { createdAt: -1 }
        };
        return await storyModel.paginate(query, options);
    },
}

module.exports = { storyServices };