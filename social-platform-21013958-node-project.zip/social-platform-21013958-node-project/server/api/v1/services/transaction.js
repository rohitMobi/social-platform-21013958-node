
import { query } from "express";
import transactionModel from "../../../models/transaction";
import userModel from "../../../models/user";
import status from '../../../enums/status';


const transactionServices = {

    createTransaction: async (insertObj) => {
        return await transactionModel.create(insertObj);
    },

    findTransaction: async (query) => {
        return await transactionModel.findOne(query);
    },

    updateTransaction: async (query, updateObj) => {
        return await transactionModel.findOneAndUpdate(query, updateObj, { new: true });
    },
    findTransactionCount: async (query) => {
        return await transactionModel.count(query);
    },

    transactionList: async (query) => {
        let activeIds = await getActiveUser();
        query.userId = { $in: activeIds };
        return await transactionModel.find(query).populate([{ path: 'userId', select: '-ethAccount.privateKey', populate: { path: 'subscribeNft' } }, { path: 'nftId' }, { path: 'nftUserId', select: '-ethAccount.privateKey' }]);
    },
    depositeList: async (query) => {
        return await transactionModel.find(query);
    },
    depositeList1: async (query) => {
        return await transactionModel.find(query).populate('userId toDonationUser nftUserId');
    },
    paginateTransactionSearch: async (validatedBody) => {
        let query = { status: { $ne: status.DELETE }, userId: validatedBody.userId }
        const { fromDate, toDate, page, limit, transactionType } = validatedBody;
        if (transactionType) {
            query.transactionType = transactionType
        }
        if (fromDate && !toDate) {
            query.createdAt = { $gte: fromDate };
        }
        if (!fromDate && toDate) {
            query.createdAt = { $lte: toDate };
        }
        if (fromDate && toDate) {
            query.$and = [
                { createdAt: { $gte: fromDate } },
                { createdAt: { $lte: toDate } },
            ]
        }
        let options = {
            page: parseInt(page) || 1,
            limit: parseInt(limit) || 10,
            sort: { createdAt: -1 },
            populate: ('userId')
        };
        return await transactionModel.paginate(query, options);
    },
    paginateWalletTransactionSearch: async (validatedBody) => {
        let query = { status: { $ne: status.DELETE }, userId: validatedBody.userId, transactionType: { $in: ["WITHDRAW_FOR_ADMIN", "DEPOSIT_FOR_ADMIN"] } }
        const { fromDate, toDate, page, limit } = validatedBody;
        if (fromDate && !toDate) {
            query.createdAt = { $gte: fromDate };
        }
        if (!fromDate && toDate) {
            query.createdAt = { $lte: toDate };
        }
        if (fromDate && toDate) {
            query.$and = [
                { createdAt: { $gte: fromDate } },
                { createdAt: { $lte: toDate } },
            ]
        }
        let options = {
            page: parseInt(page) || 1,
            limit: parseInt(limit) || 10,
            sort: { createdAt: -1 },
            populate: ('userId')
        };
        return await transactionModel.paginate(query, options);
    },

}

module.exports = { transactionServices };

const getActiveUser = async () => {
    let userId = await userModel.find({ blockStatus: false }).select('_id');
    userId = userId.map(i => i._id);
    return userId;
}
