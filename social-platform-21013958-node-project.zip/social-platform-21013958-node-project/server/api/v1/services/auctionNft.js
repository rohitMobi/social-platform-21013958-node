
import auctionNftModel from "../../../models/auctionNft";
import userModel from "../../../models/user";
import status from '../../../enums/status';
import mongoose from "mongoose";


const auctionNftServices = {

    createAuctionNft: async (insertObj) => {
        return await auctionNftModel.create(insertObj);
    },

    findAuctionNft: async (query) => {
        return await auctionNftModel.findOne(query).populate([{ path: 'userId', select: '-bnbAccount.privateKey' }, { path: 'bidId', options: { sort: { 'updatedAt': -1 } } }, { path: 'nftId' }]);
    },

    listAuction: async (query) => {
        return await auctionNftModel.find(query).populate('userId');
    },

    updateAuctionNft: async (query, updateObj) => {
        return await auctionNftModel.findOneAndUpdate(query, updateObj, { new: true });
    },
    findAuctionCount: async (query) => {
        return await auctionNftModel.count(query);
    },
    auctionNftList: async (query) => {
        // let activeIds = await getActiveUser();
        // query.userId = { $in: activeIds };
        return await auctionNftModel.find(query).populate([{ path: 'userId', select: '-bnbAccount.privateKey' }, { path: 'orderId' }, { path: 'nftId' }]).sort({ createdAt: -1 });
    },

    allNftAuctionList: async (validatedBody) => {
        let query = { status: { $ne: status.DELETE }, isSold: false, isBuy: false };
        const { search, fromDate, toDate, page, limit } = validatedBody;
        if (search) {
            query.$or = [
                { title: { $regex: search, $options: 'i' } },
                { details: { $regex: search, $options: 'i' } },
                { mediaType: { $regex: search, $options: 'i' } },
            ]
        }
        if (fromDate && !toDate) {
            query.createdAt = { $gte: fromDate };
        }
        if (!fromDate && toDate) {
            query.createdAt = { $lte: toDate };
        }
        if (fromDate && toDate) {
            query.$and = [
                { createdAt: { $gte: fromDate } },
                { createdAt: { $lte: toDate } },
            ]
        }
        let options = {
            page: parseInt(page) || 1,
            limit: parseInt(limit) || 10,
            sort: { createdAt: -1 },
            populate: [{ path: 'userId postId', select: '-bnbAccount.privateKey' }]
        };
        return await auctionNftModel.paginate(query, options);
    },

    nftAuctionList: async (validatedBody) => {
        let query = { status: { $ne: status.DELETE } };
        const { search, fromDate, toDate, page, limit } = validatedBody;
        if (search) {
            query.$or = [
                { title: { $regex: search, $options: 'i' } },
                { details: { $regex: search, $options: 'i' } },
                { mediaType: { $regex: search, $options: 'i' } },
            ]
        }
        if (fromDate && !toDate) {
            query.createdAt = { $gte: fromDate };
        }
        if (!fromDate && toDate) {
            query.createdAt = { $lte: toDate };
        }
        if (fromDate && toDate) {
            query.$and = [
                { createdAt: { $gte: fromDate } },
                { createdAt: { $lte: toDate } },
            ]
        }
        let options = {
            page: parseInt(page) || 1,
            limit: parseInt(limit) || 10,
            sort: { createdAt: -1 },
            populate: [{ path: 'userId postId', select: '-bnbAccount.privateKey' }]
        };
        return await auctionNftModel.find(query);
    },
    allmyNftAuctionList: async (validatedBody) => {
        let query = { status: { $ne: status.DELETE }, userId: validatedBody.userId, isSold: false,isBuy:false };
        const { search, fromDate, toDate, page, limit } = validatedBody;
        if (search) {
            query.$or = [
                { title: { $regex: search, $options: 'i' } },
                { details: { $regex: search, $options: 'i' } },
                { mediaType: { $regex: search, $options: 'i' } },
            ]
        }
        if (fromDate && !toDate) {
            query.createdAt = { $gte: fromDate };
        }
        if (!fromDate && toDate) {
            query.createdAt = { $lte: toDate };
        }
        if (fromDate && toDate) {
            query.$and = [
                { createdAt: { $gte: fromDate } },
                { createdAt: { $lte: toDate } },
            ]
        }
        let options = {
            page: parseInt(page) || 1,
            limit: parseInt(limit) || 10,
            sort: { createdAt: -1 },
            populate: [{ path: 'userId postId', select: '-bnbAccount.privateKey' }]
        };
        return await auctionNftModel.paginate(query, options);
    },

    allmyNftAuctionListBuy: async (validatedBody) => {
        let query = { status: { $ne: status.DELETE }, isBuy: true, buyerId: validatedBody.userId };
        const { search, fromDate, toDate, page, limit } = validatedBody;
        if (search) {
            query.$or = [
                { title: { $regex: search, $options: 'i' } },
                { details: { $regex: search, $options: 'i' } },
                { mediaType: { $regex: search, $options: 'i' } },
            ]
        }
        if (fromDate && !toDate) {
            query.createdAt = { $gte: fromDate };
        }
        if (!fromDate && toDate) {
            query.createdAt = { $lte: toDate };
        }
        if (fromDate && toDate) {
            query.$and = [
                { createdAt: { $gte: fromDate } },
                { createdAt: { $lte: toDate } },
            ]
        }
        let options = {
            page: parseInt(page) || 1,
            limit: parseInt(limit) || 10,
            sort: { createdAt: -1 },
            populate: [{ path: 'creatorId postId buyerId', select: '-bnbAccount.privateKey' }]
        };
        return await auctionNftModel.paginate(query, options);
    },

    nftAuctionList: async (validatedBody) => {
        let query = { status: { $ne: status.DELETE } };
        const { search, fromDate, toDate, page, limit } = validatedBody;
        if (search) {
            query.$or = [
                { title: { $regex: search, $options: 'i' } },
                { details: { $regex: search, $options: 'i' } },
                { mediaType: { $regex: search, $options: 'i' } },
            ]
        }
        if (fromDate && !toDate) {
            query.createdAt = { $gte: fromDate };
        }
        if (!fromDate && toDate) {
            query.createdAt = { $lte: toDate };
        }
        if (fromDate && toDate) {
            query.$and = [
                { createdAt: { $gte: fromDate } },
                { createdAt: { $lte: toDate } },
            ]
        }
        let options = {
            page: parseInt(page) || 1,
            limit: parseInt(limit) || 10,
            sort: { createdAt: -1 },
            populate: [{ path: 'userId postId', select: '-bnbAccount.privateKey' }]
        };
        return await auctionNftModel.find(query);
    },

    updateManyAction: async (query, updateObj) => {
        return await auctionNftModel.updateMany(query, updateObj, { new: true });
    },

    trendingAuctionList: async (validatedBody) => {
        let query = { status: { $ne: status.DELETE }, isSold: false, isBuy: false };
        const { search, fromDate, toDate, page, limit } = validatedBody;
        if (search) {
            query.$or = [
                { title: { $regex: search, $options: 'i' } },
                { details: { $regex: search, $options: 'i' } },
                { mediaType: { $regex: search, $options: 'i' } },
            ]
        }
        if (fromDate && !toDate) {
            query.createdAt = { $gte: fromDate };
        }
        if (!fromDate && toDate) {
            query.createdAt = { $lte: toDate };
        }
        if (fromDate && toDate) {
            query.$and = [
                { createdAt: { $gte: fromDate } },
                { createdAt: { $lte: toDate } },
            ]
        }
        let options = {
            page: parseInt(page) || 1,
            limit: parseInt(limit) || 10,
            sort: { likesCount: -1, updatedAt: -1 },
            populate: [{ path: 'userId postId', select: '-bnbAccount.privateKey' }]
        };
        return await auctionNftModel.paginate(query, options);
    },


}

module.exports = { auctionNftServices };

const getActiveUser = async () => {
    let userId = await userModel.find({ blockStatus: false }).select('_id');
    userId = userId.map(i => i._id);
    return userId;
}

// getActiveUser();