import userModel from "../../../models/user";
import status from '../../../enums/status';
import userType from "../../../enums/userType";
import mongoose from "mongoose";
import { query } from "express";



const userServices = {
  userCheck: async (userId) => {
    let query = { $and: [{ status: { $ne: status.DELETE } }, { $or: [{ email: userId }, { mobileNumber: userId }] }] }
    return await userModel.findOne(query);
  },

  checkUserExists: async (mobileNumber, email, userName) => {
    let query = { $and: [{ status: { $ne: status.DELETE } }, { $or: [{ email: email }, { mobileNumber: mobileNumber }, { userName: userName }] }] }
    return await userModel.findOne(query);
  },

  emailMobileExist: async (mobileNumber, email, userName, id) => {
    let query = { $and: [{ status: { $ne: status.DELETE } }, { _id: { $ne: id } }, { $or: [{ email: email }, { mobileNumber: mobileNumber }, { userName: userName }] }] }
    return await userModel.findOne(query);
  },

  checkSocialLogin: async (socialId, socialType) => {
    return await userModel.findOne({ socialId: socialId, socialType: socialType });
  },

  userCount: async () => {
    return await userModel.countDocuments();
  },
  findCount: async (query) => {
    return await userModel.count(query);
  },

  createUser: async (insertObj) => {
    return await userModel.create(insertObj);
  },

  findUser: async (query) => {
    return await userModel.findOne(query);
  },

  findUserData: async (query) => {
    return await userModel.findOne(query).populate([{ path: 'mightUser myWatchlist saveReels', populate: { path: 'userId' } }]).select('-password -otp');;
  },


  userSubscriberList: async (query) => {
    return await userModel.find(query).populate('subscribers').select('-bnbAccount.privateKey -password -otp');
  },

  usersupporterList: async (query) => {
    return await userModel.find(query).populate('supporters').select('-bnbAccount.privateKey -password -otp');;
  },

  userSubscriberListWithPagination: async (search, page, limit) => {
    let query = { status: { $ne: status.DELETE } };
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { walletAddress: { $regex: search, $options: 'i' } },
        { "ethAccount.address": { $regex: search, $options: 'i' } },
        { userName: { $regex: search, $options: 'i' } }
      ]
    }
    var options = {
      page: parseInt(page) || 1,
      limit: parseInt(limit) || 10,
      sort: { createdAt: -1 },
      select: '-ethAccount.privateKey'
    };
    return await userModel.paginate(query, options);
  },

  latestUserListWithPagination: async (search, page, limit, type) => {
    let query = { status: { $ne: status.DELETE } };
    if (type) {
      query.userType = type;
    }
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { walletAddress: { $regex: search, $options: 'i' } },
        { "ethAccount.address": { $regex: search, $options: 'i' } },
        { userName: { $regex: search, $options: 'i' } }
      ]
    }
    var options = {
      page: parseInt(page) || 1,
      limit: parseInt(limit) || 10,
      sort: { createdAt: -1 },
      select: '-ethAccount.privateKey'
    };
    return await userModel.paginate(query, options);
  },

  updateUser: async (query, updateObj) => {
    return await userModel.findOneAndUpdate(query, updateObj, { new: true }).select('-bnbAccount.privateKey -password -otp');
  },

  deleteUser: async (query, updateObj) => {
    return await userModel.findOneAndDelete(query,updateObj);
  },

  updateUserById: async (query, updateObj) => {
    return await userModel.findByIdAndUpdate(query, updateObj, { new: true }).select('-bnbAccount.privateKey -password -otp');
  },

  insertManyUser: async (obj) => {
    return await userModel.insertMany(obj).select('-bnbAccount.privateKey -password -otp');
  },

  creatorList: async (query) => {
    return await userModel.find(query).select('-bnbAccount.privateKey -password -otp');
  },
  paginateSearch: async (validatedBody) => {
    let query = { status: { $ne: status.DELETE } };
    const { search, fromDate, toDate, page, limit } = validatedBody;
    if (search) {
      query.$or = [
        { firstName: { $regex: search, $options: 'i' } },
        { lastName: { $regex: search, $options: 'i' } },
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { mobileNumber: { $regex: search, $options: 'i' } },
        { userName: { $regex: search, $options: 'i' } },
      ]
    }
    if (fromDate && !toDate) {
      query.createdAt = { $gte: fromDate };
    }
    if (!fromDate && toDate) {
      query.createdAt = { $lte: toDate };
    }
    if (fromDate && toDate) {
      query.$and = [
        { createdAt: { $gte: fromDate } },
        { createdAt: { $lte: toDate } },
      ]
    }
    let options = {
      page: page || 1,
      limit: limit || 15,
      sort: { createdAt: -1 },
      select: '-ethAccount.privateKey'
    };
    return await userModel.paginate(query, options);
  },

  paginateSearchUser: async (validatedBody) => {
    let query = { status: { $ne: status.DELETE }, userType: userType.USER };
    const { search, fromDate, toDate, page, limit } = validatedBody;
    if (search) {
      query.$or = [
        { firstName: { $regex: search, $options: 'i' } },
        { lastName: { $regex: search, $options: 'i' } },
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { mobileNumber: { $regex: search, $options: 'i' } },
        { userName: { $regex: search, $options: 'i' } },
      ]
    }
    if (fromDate && !toDate) {
      query.createdAt = { $gte: fromDate };
    }
    if (!fromDate && toDate) {
      query.createdAt = { $lte: toDate };
    }
    if (fromDate && toDate) {
      query.$and = [
        { createdAt: { $gte: fromDate } },
        { createdAt: { $lte: toDate } },
      ]
    }
    let options = {
      page: Number(page) || 1,
      limit: Number(limit) || 15,
      sort: { createdAt: -1 },
      select: '-ethAccount.privateKey'
    };
    return await userModel.paginate(query, options);
  },
  paginateSearchUserFind: async (validatedBody) => {
    let query = { status: { $ne: status.DELETE }, userType: userType.USER, otpVerification: true, isPost: true };
    const { search, fromDate, toDate, page, limit } = validatedBody;
    if (search) {
      query.$or = [
        { firstName: { $regex: search, $options: 'i' } },
        { lastName: { $regex: search, $options: 'i' } },
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { mobileNumber: { $regex: search, $options: 'i' } },
        { userName: { $regex: search, $options: 'i' } },
      ]
    }
    if (fromDate && !toDate) {
      query.createdAt = { $gte: fromDate };
    }
    if (!fromDate && toDate) {
      query.createdAt = { $lte: toDate };
    }
    if (fromDate && toDate) {
      query.$and = [
        { createdAt: { $gte: fromDate } },
        { createdAt: { $lte: toDate } },
      ]
    }
    return await userModel.find(query).sort({ createdAt: -1 });
  },

  profileSubscriberList: async (subscriberList) => {
    return userModel.find({ _id: { $in: subscriberList }, status: { $ne: status.DELETE } }).select('-bnbAccount.privateKey -profileSubscribe -subscriberList -permissions');
  },

  profileSubscribeList: async (profileSubscribe) => {
    return userModel.find({ _id: { $in: profileSubscribe }, status: { $ne: status.DELETE } }).select('-bnbAccount.privateKey -profileSubscribe -subscriberList -permissions');
  },


  userCount: async () => {
    return await userModel.countDocuments();
  },

  userList: async (validatedBody) => {
    let query = { status: { $ne: status.DELETE } };
    const { search, fromDate, toDate, page, limit } = validatedBody;
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { mobileNumber: { $regex: search, $options: 'i' } },
        { walletAddress: { $regex: search, $options: 'i' } },
        { "bnbAccount.address": { $regex: search, $options: 'i' } },
        { userName: { $regex: search, $options: 'i' } }
      ]
    }
    if (fromDate && !toDate) {
      query.createdAt = { $gte: fromDate };
    }
    if (!fromDate && toDate) {
      query.createdAt = { $lte: toDate };
    }
    if (fromDate && toDate) {
      query.$and = [
        { createdAt: { $gte: fromDate } },
        { createdAt: { $lte: toDate } },
      ]
    }
    let options = {
      page: page || 1,
      limit: limit || 10,
      sort: { createdAt: -1 },
      select: '-bnbAccount.privateKey'
    };
    return await userModel.paginate(query, options);
  },

  userFindList: async (validatedBody) => {
    let query = { status: { $ne: status.DELETE } };
    const { search, fromDate, toDate, page, limit } = validatedBody;
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { mobileNumber: { $regex: search, $options: 'i' } },
        { walletAddress: { $regex: search, $options: 'i' } },
        { "bnbAccount.address": { $regex: search, $options: 'i' } },
        { userName: { $regex: search, $options: 'i' } }
      ]
    }
    if (fromDate && !toDate) {
      query.createdAt = { $gte: fromDate };
    }
    if (!fromDate && toDate) {
      query.createdAt = { $lte: toDate };
    }
    if (fromDate && toDate) {
      query.$and = [
        { createdAt: { $gte: fromDate } },
        { createdAt: { $lte: toDate } },
      ]
    }
    let options = {
      page: page || 1,
      limit: limit || 10,
      sort: { createdAt: -1 },
      select: '-bnbAccount.privateKey'
    };
    return await userModel.find(query);
  },

  userAllDetails: async (_id, userId) => {
    let query = { _id: mongoose.Types.ObjectId(_id), status: { $ne: status.DELETE } };
    if (userId) {
      return await userModel.aggregate([
        { $match: query },
        {
          $addFields: {
            "isSubscribe": {
              $cond: {
                if: { $in: [mongoose.Types.ObjectId(userId), "$subscriberList"] },
                then: true,
                else: false
              }
            }
          }
        },
        {
          $lookup: {
            from: "nft",
            as: "bundleDetails",
            let: {
              user_id: "$_id"
            },
            pipeline: [
              { $match: { $expr: { $eq: ["$$user_id", "$userId"] } } },
              { $sort: { createdAt: -1 } },
              {
                $lookup: {
                  from: "user",
                  localField: "userId",
                  foreignField: "_id",
                  as: "userDetail"
                }
              },
              {
                $project: {
                  "userDetail.bnbAccount.privateKey": 0
                }
              },
              {
                $unwind: "$userDetail"
              },
            ],
          }
        },
        {
          $lookup: {
            from: "audience",
            localField: "_id",
            foreignField: "userId",
            as: "postList"
          }
        },
        {
          $project: {
            "bnbAccount.privateKey": 0
          }
        },
      ])
    } else {
      return await userModel.aggregate([
        { $match: query },
        {
          $lookup: {
            from: "nft",
            let: {
              user_id: "$_id"
            },
            pipeline: [
              { $match: { $expr: { $eq: ["$$user_id", "$userId"] } } },
              { $sort: { createdAt: -1 } },
              {
                $lookup: {
                  from: "user",
                  localField: "userId",
                  foreignField: "_id",
                  as: "userDetail"
                }
              },
              {
                $project: {
                  "userDetail.bnbAccount.privateKey": 0
                }
              },
              {
                $unwind: "$userDetail"
              },
            ],
            as: "bundleDetails",
          }
        },
        {
          $lookup: {
            from: "audience",
            localField: "_id",
            foreignField: "userId",
            as: "postList"
          }
        },
        {
          $project: {
            "bnbAccount.privateKey": 0
          }
        },
      ])
    }

  },

  userAllDetailsByUserName: async (userName, userId) => {
    let query = { userName: userName, status: { $ne: status.DELETE } };
    if (userId) {
      return await userModel.aggregate([
        { $match: query },
        {
          $addFields: {
            "isSubscribe": {
              $cond: {
                if: { $in: [mongoose.Types.ObjectId(userId), "$subscriberList"] },
                then: true,
                else: false
              }
            }
          }
        },
        {
          $lookup: {
            from: "nft",
            as: "bundleDetails",
            let: {
              user_id: "$_id"
            },
            pipeline: [
              { $match: { $expr: { $eq: ["$$user_id", "$userId"] } } },
              { $sort: { createdAt: -1 } },
              {
                $lookup: {
                  from: "user",
                  localField: "userId",
                  foreignField: "_id",
                  as: "userDetail"
                }
              },
              {
                $project: {
                  "userDetail.bnbAccount.privateKey": 0
                }
              },
              {
                $unwind: "$userDetail"
              },
            ],
          }
        },
        {
          $project: {
            "bnbAccount.privateKey": 0
          }
        },
      ])
    } else {
      return await userModel.aggregate([
        { $match: query },
        {
          $lookup: {
            from: "nft",
            as: "bundleDetails",
            let: {
              user_id: "$_id"
            },
            pipeline: [
              { $match: { $expr: { $eq: ["$$user_id", "$userId"] } } },
              { $sort: { createdAt: -1 } },
              {
                $lookup: {
                  from: "user",
                  localField: "userId",
                  foreignField: "_id",
                  as: "userDetail"
                }
              },
              {
                $project: {
                  "userDetail.bnbAccount.privateKey": 0
                }
              },
              {
                $unwind: "$userDetail"
              },
            ],
          }
        },
        {
          $project: {
            "bnbAccount.privateKey": 0
          }
        },
      ])
    }

  },

  multiUpdateForUser: async (updateObj) => {
    return await userModel.updateMany({}, updateObj, { multi: true });
  },



  userFindList: async (validatedBody) => {
    let query = { status: { $ne: status.DELETE } };
    const { search, fromDate, toDate, page, limit } = validatedBody;
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { mobileNumber: { $regex: search, $options: 'i' } },
        { walletAddress: { $regex: search, $options: 'i' } },
        { "bnbAccount.address": { $regex: search, $options: 'i' } },
        { userName: { $regex: search, $options: 'i' } }
      ]
    }
    if (fromDate && !toDate) {
      query.createdAt = { $gte: fromDate };
    }
    if (!fromDate && toDate) {
      query.createdAt = { $lte: toDate };
    }
    if (fromDate && toDate) {
      query.$and = [
        { createdAt: { $gte: fromDate } },
        { createdAt: { $lte: toDate } },
      ]
    }
    let options = {
      page: page || 1,
      limit: limit || 10,
      sort: { createdAt: -1 },
      select: '-bnbAccount.privateKey'
    };
    return await userModel.find(query);
  },

  trendingUser: async (validatedBody) => {
    let query = { status: { $ne: status.DELETE }, userType: userType.USER };
    const { search, fromDate, toDate, page, limit } = validatedBody;
    if (search) {
      query.$or = [
        { firstName: { $regex: search, $options: 'i' } },
        { lastName: { $regex: search, $options: 'i' } },
        { mobileNumber: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { mobileNumber: { $regex: search, $options: 'i' } },
        { userName: { $regex: search, $options: 'i' } },
      ]
    }
    if (fromDate && !toDate) {
      query.createdAt = { $gte: fromDate };
    }
    if (!fromDate && toDate) {
      query.createdAt = { $lte: toDate };
    }
    if (fromDate && toDate) {
      query.$and = [
        { createdAt: { $gte: fromDate } },
        { createdAt: { $lte: toDate } },
      ]
    }
    // let options = {
    //   page: Number(page) || 1,
    //   limit: Number(limit) || 15,
    //   sort: { followersCount: -1, followingCount: -1 },
    //   select: '-bnbAccount.privateKey'
    // };
    return await userModel.find(query).sort({followersCount: -1});
  },

  paginateSearchByAdmin: async (validatedBody) => {
    let query = { status: { $ne: status.DELETE }, userType:validatedBody.userType  };
    const { search, fromDate, toDate, page, limit, statusType } = validatedBody;
    if (search) {
      query.$or = [
        { firstName: { $regex: search, $options: 'i' } },
        { lastName: { $regex: search, $options: 'i' } },
        { mobileNumber: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { mobileNumber: { $regex: search, $options: 'i' } },
        { userName: { $regex: search, $options: 'i' } },
      ]
    }
    if (statusType) {
      query.status = statusType
    }
    if (fromDate && !toDate) {
      query.createdAt = { $gte: fromDate };
    }
    if (!fromDate && toDate) {
      query.createdAt = { $lte: toDate };
    }
    if (fromDate && toDate) {
      query.$and = [
        { createdAt: { $gte: fromDate } },
        { createdAt: { $lte: toDate } },
      ]
    }
    let options = {
      page: Number(page) || 1,
      limit: Number(limit) || 15,
      sort: { createdAt: -1 },
      select: '-bnbAccount.privateKey'
    };
    return await userModel.paginate(query, options);
  },

  userNameSearchforsignuptime: async (validatedBody) => {
    let query = { status: { $ne: status.DELETE } };
    const { search, page, limit } = validatedBody;
    if (search) {
      query.$or = [
        { userName: { $regex: search, $options: 'i' } },
      ]
    }
    let options = {
      page: Number(page) || 1,
      limit: Number(limit) || 15,
      sort: { createdAt: -1 },
      select: '-bnbAccount.privateKey'
    };
    return await userModel.paginate(query, options);
  },


}

module.exports = { userServices };
