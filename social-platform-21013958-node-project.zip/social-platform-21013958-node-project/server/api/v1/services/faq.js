import faqModel from  "../../../models/faq"
import status from '../../../enums/status';

const faqServices={
    createFaq: async (insertObj) => {
        return await faqModel.create(insertObj);
    },
    findFaq: async (query) => {
        return await faqModel.findOne(query);
    },
    updateFaqById: async (query, updateObj) => {
        return await faqModel.findByIdAndUpdate(query, updateObj, { new: true });
    },
    faqList: async () => {
        return await faqModel.find({}) 
    },
}

module.exports = { faqServices };