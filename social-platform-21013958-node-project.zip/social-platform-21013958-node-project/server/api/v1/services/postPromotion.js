import postPromotionModel from "../../../models/postPromotion";
import status from '../../../enums/status';

const postPromotionServices = {

    createPostPromotion: async (insertObj) => {
        return await postPromotionModel.create(insertObj);
    },

    findPostPromotion: async (query) => {
        return await postPromotionModel.findOne(query).populate('userId postId comment.userId comment.reply.userId')
    },

    updatePostPromotion: async (query, updateObj) => {
        return await postPromotionModel.findOneAndUpdate(query, updateObj, { new: true });
    },

    postPromotionList: async (query) => {
        return await postPromotionModel.find(query).populate('userId postId comment.userId comment.reply.userId');
    },
    findPostPromotionCount: async (query) => {
        return await postPromotionModel.count(query);
    },

    paginatePostPromotionSearch: async (validatedBody) => {
        let query = { status: { $ne: status.DELETE }, userId: validatedBody.userId }
        const { search, fromDate, toDate, page, limit } = validatedBody;
        if (search) {
            query.$or = [
                { postTitle: { $regex: search, $options: 'i' } }
            ]
        }
        if (fromDate && !toDate) {
            query.createdAt = { $gte: fromDate };
        }
        if (!fromDate && toDate) {
            query.createdAt = { $lte: toDate };
        }
        if (fromDate && toDate) {
            query.$and = [
                { createdAt: { $gte: fromDate } },
                { createdAt: { $lte: toDate } },
            ]
        }
        let options = {
            page: parseInt(page) || 1,
            limit: parseInt(limit) || 10,
            sort: { createdAt: -1 },
            populate: ('userId postId comment.userId comment.reply.userId')
        };
        return await postPromotionModel.paginate(query, options);
    },
    allPaginatePostPromotionSearch: async (validatedBody) => {
        let query = { status: { $ne: status.DELETE } }
        const { search, fromDate, toDate, page, limit } = validatedBody;
        if (search) {
            query.$or = [
                { postTitle: { $regex: search, $options: 'i' } }
            ]
        }
        if (fromDate && !toDate) {
            query.createdAt = { $gte: fromDate };
        }
        if (!fromDate && toDate) {
            query.createdAt = { $lte: toDate };
        }
        if (fromDate && toDate) {
            query.$and = [
                { createdAt: { $gte: fromDate } },
                { createdAt: { $lte: toDate } },
            ]
        }
        let options = {
            page: parseInt(page) || 1,
            limit: parseInt(limit) || 10,
            sort: { createdAt: -1 },
            populate: ('userId postId comment.userId comment.reply.userId')
        };
        return await postPromotionModel.paginate(query, options);
    },
    deletePostPromotionComment: async (validatedBody) => {
        return await postPromotionModel.findOneAndUpdate({ _id: validatedBody.postPromotionId, 'comment._id': validatedBody.commentId }, { $pull: { comment: { _id: validatedBody.commentId } }, $inc: { totalComment: -1 } }, { new: true });
    },

}

module.exports = { postPromotionServices };