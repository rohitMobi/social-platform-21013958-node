import Joi from "joi";
import _ from "lodash";
import config from "config";
import jwt from "jsonwebtoken";
import userModel from "../../../../models/user";
import apiError from '../../../../helper/apiError';
import { pushNotification } from "../../../../helper/util";
import response from '../../../../../assets/response';
import bcrypt from 'bcryptjs';
import responseMessage from '../../../../../assets/responseMessage';
import { userServices } from '../../services/user';
import { bufferServices } from '../../services/bufferUser';
import { chatServices } from '../../services/chat';
import chatSchema from '../../../../models/chatting';
import { transactionServices } from '../../services/transaction';
import { notificationServices } from '../../services/notification';
import { planServices } from '../../services/plan';
import { subscriptionServices } from '../../services/subscription';
import { reportServices } from '../../services/report';
import { orderServices } from '../../services/order';
import { storyServices } from '../../services/story';
import { audienceServices } from '../../services/audience';
import { nftServices } from '../../services/nft';
import { activityServices } from '../../services/userActivity';
import { collectionServices } from '../../services/collection';
import { postServices } from '../../services/post';
import { collectionSubscriptionServices } from '../../services/collectionSubscription'
import { auctionNftServices } from '../../services/auctionNft'
import { socialServices } from '../../services/social';
import { requestServices } from '../../services/request'
import { disappearServices } from '../../services/disappear'
import { postPromotionServices } from '../../services/postPromotion'
import { interestServices } from '../../services/interest'
import { feeServices } from '../../services/fee'
import { hashTagServices } from '../../services/hashTag'
import { durationServices } from '../../services/duration'
import { reelsServices } from '../../services/reels'
import { logHistoryServices } from '../../services/logHistory';
const { createLogHistory, findLogHistory, updateLogHistory, logHistoryList, logHistoryWithPagination, paginateSearchLogHistory } = logHistoryServices;
const { createReels, findReels, updateReelsById, updateReels, reelsList, paginateSearchReels, deleteReelsComment } = reelsServices
const { createDuration, findDuration, updateDuration, durationList } = durationServices
const { createHashTag, findHashTag, updateHashTag, hashTagList, paginateHashTagSearch } = hashTagServices;
const { createFee, findFee, updateFee, feeList } = feeServices
const { createInterest, findInterest, updateInterest, interestList, paginateSearchInterest } = interestServices
const { createPostPromotion, findPostPromotion, updatePostPromotion, postPromotionList, paginatePostPromotionSearch, allPaginatePostPromotionSearch, deletePostPromotionComment } = postPromotionServices
const { createDisappear, findDisappear, updateDisappear } = disappearServices
const { createRequest, findRequest, updateRequestById, requestList } = requestServices
const { paginateSearchSocial } = socialServices
const { createAuctionNft, findAuctionNft, listAuction, updateAuctionNft, auctionNftList, allNftAuctionList, allmyNftAuctionList, allmyNftAuctionListBuy, nftAuctionList, updateManyAction, trendingAuctionList } = auctionNftServices
const { createCollectionSubscription, findCollectionSubscription, updateCollectionSubscription, collectionSubscriptionList, userSubscribeCollectionList, collectionSubscriptionUserList } = collectionSubscriptionServices;
const { createUserPost, findOnePost, updatePost, listPost, paginatePostSearch, paginateAllPostSearch, paginatePostSearchBuy, paginateAllPostSearchPrivatePublic, allPostList, paginateAllPostSearchPrivatePublicTrending, tagPostbyuserlist, deletePostComment, deletePostCommentReply, paginateAllPostSearchPrivatePublicFind } = postServices;
const { createCollection, findCollection, updateCollection, collectionList, collectionPaginateSearch, myCollectionPaginateSearch, collectionListAll, userCollectionListAll, allCollectionPaginateSearch, collectionSearchList, findCollectionCount } = collectionServices;
const { createActivity, findActivity, updateActivity, multiUpdateActivity, activityList, activityListWithSort, findAllActivity, paginateSearch } = activityServices;
const { createAudience, findAudience, findAudience1, updateAudience, audienceList, multiUpdate, feedUpdateAll, postList } = audienceServices;
const { createBuffer, findBuffer, updateBuffer, bufferDelete, bufferList } = bufferServices;
const { userCheck, creatorList, profileSubscribeList, profileSubscriberList, userCount, checkUserExists, emailMobileExist, latestUserListWithPagination, createUser, findUser, multiUpdateForUser, findUserData, updateUser, updateUserById, userAllDetails, userAllDetailsByUserName, checkSocialLogin, userSubscriberListWithPagination, userSubscriberList, usersupporterList, paginateSearchUser, userFindList, trendingUser, userNameSearchforsignuptime, paginateSearchUserFind, findCount } = userServices;
const { createChat, findChat, updateChat, chatList } = chatServices;
const { createTransaction, findTransaction, updateTransaction, transactionList, depositeList, depositeList1, paginateTransactionSearch, paginateWalletTransactionSearch } = transactionServices;
const { createNotification, findNotification, updateNotification, notificationList, notificationDeleteMany } = notificationServices;
const { createPlan, findPlan, updatePlan, planList } = planServices;
const { createSubscription, findSubscription, updateSubscription, subscriptionList } = subscriptionServices;
const { createOrder, findOrder, updateOrder, orderList } = orderServices;
const { createReport, findReport, findAllReport, updateReport, updateReportById, paginateSearchReport } = reportServices;
const { createStory, findStory, updateStoryById, storyList, updateStory, paginateSearchStory } = storyServices;
const { createNft, findNft, findNft1, updateNft, nftSubscriber, nftSubscriberList, nftList, nftPaginateSearch, myNftPaginateSearch, multiUpdateBundle, sharedBundleList, sharedBundleListPerticular } = nftServices;

import commonFunction from '../../../../helper/util';
import fs from 'fs';
import mongoose from "mongoose";
import moment from 'moment';
import status from '../../../../enums/status';
import userType from "../../../../enums/userType";
import speakeasy from 'speakeasy';
import axios from 'axios';
import { join } from "path/posix";
let baseUrl = config.get("hostAddress")

const mnemonic = config.get('mnemonic');
import binance from '../../binance/binance'
import e, { query } from "express";
import { varint } from "protocol-buffers-encodings";
import config1 from '../../binance/config'
import Web3 from "web3";
import ip from 'ip';
const web3 = new Web3(new Web3.providers.HttpProvider(config1.BNB_URL));

export class userController {

    /**
     * @swagger
     * /user/register:
     *   post:
     *     tags:
     *       - USER
     *     description: register
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: register
     *         description: register
     *         in: body
     *         required: true
     *         schema:
     *           $ref: '#/definitions/register'
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async register(req, res, next) {
        const validationSchema = {
            userName: Joi.string().required(),
            email: Joi.string().optional(),
            countryCode: Joi.string().optional(),
            mobileNumber: Joi.string().optional(),
            password: Joi.string().required(),
            dob: Joi.string().optional(),
            gender: Joi.string().optional(),
            refereeCode: Joi.string().allow('').optional(),
        };
        try {
            if (req.body.email) {
                req.body.email = (req.body.email).toLowerCase();
            }
            if (req.body.userName) {
                req.body.userName = (req.body.userName).toLowerCase()
            }
            var result;
            const { userName, password, email, dob, gender, mobileNumber, countryCode, refereeCode } = await Joi.validate(req.body, validationSchema);
            var userInfo = await checkUserExists(mobileNumber, email, userName);
            if (userInfo) {
                if (userInfo.email == email) {
                    throw apiError.conflict(responseMessage.EMAIL_EXIST);
                }
                if (userInfo.userName == userName) {
                    throw apiError.conflict(responseMessage.USER_NAME_EXIST);
                }
                if (userInfo.mobileNumber == mobileNumber) {
                    throw apiError.conflict(responseMessage.MOBILE_EXIST);
                }
            } else {
                let [feeRes, referralRes, adminRes, referralUserRes] = await Promise.all([
                    findFee({ type: "SIGNUP", status: { $ne: status.DELETE } }),
                    findFee({ type: "REFERREL", status: { $ne: status.DELETE } }),
                    findUser({ userType: userType.ADMIN, status: { $ne: status.DELETE } }),
                    findUser({ referralCode: refereeCode, status: status.ACTIVE })])
                // if (Number(feeRes.amount) > Number(adminRes.bnbBalace)) {
                //     throw apiError.badRequest(responseMessage.ADMIN_LOW_BALANCE)
                // }
                if (refereeCode) {
                    if (!referralUserRes) {
                        throw apiError.badRequest(responseMessage.REFERRAL);
                    }
                    //     if (Number(referralRes.amount) > Number(adminRes.bnbBalace)) {
                    //         throw apiError.badRequest(responseMessage.ADMIN_LOW_BALANCE)
                    //     }
                }
                req.body.referralCode = await commonFunction.makeReferral()
                let otp = commonFunction.getOTP();
                if (email) {
                    await commonFunction.sendMailWithTemplateNodemailer(email, otp);
                }
                if (mobileNumber) {
                    let number = `${countryCode}${mobileNumber}`
                    commonFunction.sendSmsTwilio(number, otp);
                }
                let getCount = fs.readFileSync('./count.json')
                let updateCount = {
                    count: JSON.parse(getCount).count + 1
                }
                fs.writeFileSync('./count.json', JSON.stringify(updateCount))
                let binanceRes = await binance.generateBNBWallet((JSON.parse(getCount).count + 1), `${mnemonic}`);
                if (binanceRes.generatedMessage == false) {
                    throw apiError.internal(responseMessage.BLOCKCHAIN_ERROR)
                } else {
                    req.body.bnbAccount = {
                        address: binanceRes.address,
                        privateKey: binanceRes.privateKey
                    }
                    req.body.password = bcrypt.hashSync(password);
                    req.body.otpTime = new Date().getTime();
                    req.body.otp = otp
                    // req.body.userType = userType.CREATOR
                    result = await createUser(req.body)
                    if (refereeCode) {
                        await createTransaction({
                            userId: adminRes._id,
                            amount: Number(referralRes.amount),
                            transactionType: "REFERRAL_FOR_ADMIN"
                        })
                        await createTransaction({
                            userId: referralUserRes._id,
                            amount: Number(referralRes.amount),
                            transactionType: "REFERRAL_FOR_USER"
                        })
                        await Promise.all([
                            // updateUser({ _id: adminRes._id }, { bnbBalace: Number(adminRes.bnbBalace) - Number(referralRes.amount) }),
                            updateUser({ _id: referralUserRes._id }, { bnbBalace: Number(referralUserRes.bnbBalace) + Number(referralRes.amount), refferralBonus: Number(referralUserRes.refferralBonus) + Number(referralRes.amount) })])
                    }
                    await createTransaction({
                        userId: adminRes._id,
                        amount: Number(feeRes.amount),
                        transactionType: "SIGNUP_FOR_ADMIN"
                    })
                    await createTransaction({
                        userId: result._id,
                        amount: Number(feeRes.amount),
                        transactionType: "SIGNUP_FOR_USER"
                    })
                    await Promise.all([
                        // updateUser({ _id: adminRes._id }, { bnbBalace: Number(adminRes.bnbBalace) - Number(feeRes.amount) }),
                        updateUser({ _id: result._id }, { bnbBalace: Number(result.bnbBalace) + Number(feeRes.amount), signupBonus: Number(result.signupBonus) + Number(feeRes.amount) })])

                    result = _.omit(JSON.parse(JSON.stringify(result)), 'otp')
                    return res.json(new response(result, responseMessage.USER_CREATED));
                }

            }
        } catch (error) {

            console.log(error);
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/verifyOtp:
     *   put:
     *     tags:
     *       - USER
     *     description: verifyOtp
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: verifyOtp
     *         description: verifyOtp
     *         in: body
     *         required: true
     *         schema:
     *           $ref: '#/definitions/verifyOtp'
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async verifyOtp(req, res, next) {
        try {
            if (req.body.email) {
                req.body.email = (req.body.email).toLowerCase();
            }
            var result = await findUser({ $and: [{ status: { $ne: status.DELETE } }, { $or: [{ mobileNumber: req.body.email }, { email: req.body.email }] }] });
            if (!result) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            else {
                var otpTime = new Date().getTime();
                var diff = otpTime - result.otpTime;
                // if (result.otpVerification == true) {
                //     return res.json(new response(result, responseMessage.OTP_ALREADY_VIRIFIED));
                // } else {
                if (diff >= 300000) {
                    throw apiError.badRequest(responseMessage.OTP_EXPIRED);
                }
                else {
                    if (req.body.otp == result.otp) {
                        let result2 = await userModel.findOneAndUpdate({ _id: result._id }, { $set: { otpVerification: true } }, { new: true });
                        let token = await commonFunction.getToken({ id: result2._id, email: result2.email, userType: result2.userType });
                        let obj = {
                            email: result2.email || result2.mobileNumber,
                            userName: result2.userName,
                            token: token
                        }
                        return res.json(new response(obj, responseMessage.OTP_VIRIFIED));
                    }
                    else {
                        throw apiError.badRequest(responseMessage.INCORRECT_OTP);
                    }
                }
                // }
            }
        }
        catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/resendOtp:
     *   post:
     *     tags:
     *       - USER
     *     description: resendOtp
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: resendOtp
     *         description: resendOtp
     *         in: body
     *         required: true
     *         schema:
     *           $ref: '#/definitions/resendOtp'
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async resendOtp(req, res, next) {
        const validationSchema = {
            email: Joi.string().required()
        };
        try {
            if (req.body.email) {
                req.body.email = (req.body.email).toLowerCase();
            }
            const { email } = await Joi.validate(req.body, validationSchema);
            var userResult = await findUser({ $and: [{ status: { $ne: status.DELETE } }, { $or: [{ mobileNumber: email }, { email: email }] }] });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let otp = await commonFunction.getOTP();
            if (userResult.email == email) {
                commonFunction.sendMailWithTemplateNodemailer(email, otp)
            }
            if (userResult.mobileNumber == email) {
                let number = `+91${email}`
                commonFunction.sendSmsTwilio(number, otp);
            }

            let update = await updateUser({ _id: userResult._id }, { otp: otp, otpTime: new Date().getTime() });
            let obj = {
                _id: update._id,
                email: update.email || update.mobileNumber,
                userName: update.userName
            }
            return res.json(new response(obj, responseMessage.OTP_SEND));

        }
        catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/forgotPassword:
     *   post:
     *     tags:
     *       - USER
     *     description: forgotPassword
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: resendOtp
     *         description: resendOtp
     *         in: body
     *         required: true
     *         schema:
     *           $ref: '#/definitions/resendOtp'
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async forgotPassword(req, res, next) {
        const validationSchema = {
            email: Joi.string().required()
        };
        try {
            if (req.body.email) {
                req.body.email = (req.body.email).toLowerCase();
            }
            const { email } = await Joi.validate(req.body, validationSchema);
            var userResult = await findUser({ $and: [{ status: { $ne: status.DELETE } }, { $or: [{ mobileNumber: email }, { email: email }] }] });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }

            let otp = await commonFunction.getOTP();
            if (userResult.email == email) {
                commonFunction.sendMailWithTemplateNodemailer(email, otp);
            }
            if (userResult.mobileNumber == email) {
                let number = `+91${email}`
                commonFunction.sendSmsTwilio(number, otp);
            }

            let update = await updateUser({ _id: userResult._id }, { otp: otp, otpTime: new Date().getTime() });
            let obj = {
                otp: update.otp,
                email: update.email || update.mobileNumber,
                userName: update.userName
            }
            return res.json(new response(obj, responseMessage.OTP_SEND));

        }
        catch (error) {
            console.log(error);
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/resetPassword:
     *   post:
     *     tags:
     *       - USER
     *     description: Check for Social existence and give the access Token
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: email
     *         description: email
     *         in: formData
     *         required: true
     *       - name: password
     *         description: password
     *         in: formData
     *         required: true
     *       - name: confirmPassword
     *         description: confirmPassword
     *         in: formData
     *         required: true
     *     responses:
     *       200:
     *         description: Your password has been successfully changed.
     *       404:
     *         description: This user does not exist.
     *       422:
     *         description: Password not matched.
     *       500:
     *         description: Internal Server Error
     *       501:
     *         description: Something went wrong!
     */
    async resetPassword(req, res, next) {
        const validationSchema = {
            email: Joi.string().required(),
            password: Joi.string().required(),
            confirmPassword: Joi.string().required()

        };
        try {
            if (req.body.email) {
                req.body.email = (req.body.email).toLowerCase();
            }
            const { email, password, confirmPassword } = await Joi.validate(req.body, validationSchema);
            var userResult = await findUser({ $and: [{ status: { $ne: status.DELETE } }, { $or: [{ mobileNumber: email }, { email: email }] }] });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            else {
                if (userResult.otpVerification === false) {
                    throw apiError.badRequest(responseMessage.OTP_VERIFY_FIRST);
                }
                if (password == confirmPassword) {
                    let update = await updateUser({ _id: userResult._id }, { password: bcrypt.hashSync(password) });
                    return res.json(new response(update, responseMessage.PWD_CHANGED));
                }
                else {
                    throw apiError.notFound(responseMessage.PWD_NOT_MATCH);
                }
            }
        }
        catch (error) {
            console.log(error);
            return next(error);
        }
    }
    /**
     * @swagger
     * /user/login:
     *   post:
     *     tags:
     *       - USER
     *     description: login
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: login
     *         description: login
     *         in: body
     *         required: true
     *         schema:
     *           $ref: '#/definitions/login'
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async login(req, res, next) {
        const validationSchema = {
            email: Joi.string().required(),
            password: Joi.string().required(),
            deviceToken: Joi.string().optional(),
            deviceType: Joi.string().optional()
        };
        try {
            if (req.body.email) {
                req.body.email = (req.body.email).toLowerCase();
            }
            let token;
            const { email, password } = await Joi.validate(req.body, validationSchema);
            var userResult = await findUser({ $and: [{ status: { $ne: status.DELETE } }, { $or: [{ mobileNumber: email }, { email: email }] }] });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            if (userResult.otpVerification === false) {
                throw apiError.badRequest(responseMessage.INCORRECT_LOGIN);
            }
            if (!userResult.password || !bcrypt.compareSync(password, userResult.password)) {
                throw apiError.invalid(responseMessage.INCORRECT_LOGIN);
            }
            if (req.body.deviceToken && req.body.deviceType) {
                await updateUser({ _id: userResult._id }, { deviceToken: req.body.deviceToken, deviceType: req.body.deviceType });
            }
            token = await commonFunction.getToken({ id: userResult._id, email: userResult.email, userType: userResult.userType });
            let updateRes = await updateUser({ _id: userResult._id }, { isOnline: true });
            let obj = {
                _id: userResult._id,
                email: userResult.email || userResult.mobileNumber,
                userName: userResult.userName,
                token: token,
                userType: userResult.userType,
                bnbAccount: userResult.bnbAccount.address,
                permissions: userResult.permissions,
                status: userResult.status,
                isSocial: userResult.isSocial,
                isOnline: updateRes.isOnline
            }
            await createLogHistory({ userId: userResult._id, ip_Address: ip.address(), browser: req.headers['user-agent'], userType: userResult.userType, email: userResult.email })
            return res.json(new response(obj, responseMessage.LOGIN));
        }
        catch (error) {
            console.log("==error===", error)
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/userprofile:
     *   get:
     *     tags:
     *       - USER
     *     description: profile
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async userprofile(req, res, next) {
        try {
            let userResult = await findUserData({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let updateRes = await updateUser({ _id: userResult._id }, { isOnline: true });
            return res.json(new response(updateRes, responseMessage.USER_DETAILS));
        } catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/getBalance:
     *   get:
     *     tags:
     *       - USER
     *     description: getBalance
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async getBalance(req, res, next) {
        try {
            var userResult = await findUserData({ _id: req.userId, userType: userType.USER })
            var adminRes = await findUserData({ userType: userType.ADMIN })
            // var bnbBalance = await binance.getBalance(userResult.bnbAccount.address);
            var tokenBalance = await binance.getTokenBalance(userResult.bnbAccount.address)
            var balance = tokenBalance.balance;
            if (balance > 100 * 10 ** 18) {
                let adminAmount = 0.1 - 0.001;
                let adminTransfer = await binance.transfer(adminRes.bnbAccount.address, adminRes.bnbAccount.privateKey, userResult.bnbAccount.address, adminAmount)
                if (adminTransfer.Hash) {
                    let transferRes = await binance.tokenWithdraw(userResult.bnbAccount.address, userResult.bnbAccount.privateKey, adminRes.bnbAccount.address, balance);
                    if (transferRes.Success == true) {
                        balance = web3.utils.fromWei(balance);
                        await createTransaction({
                            userId: userResult._id,
                            amount: balance,
                            transactionHash: transferRes.Hash,
                            transactionType: "AMOUNT_RECEIVED"
                        })
                        let adminUp = await updateUser({ _id: adminRes._id }, { adminTotalToken: adminRes.adminTotalToken + parseFloat(balance) });
                        if (adminUp) {
                            var updateRes = await updateUser({ _id: userResult._id }, { bnbBalace: userResult.bnbBalace + parseFloat(balance) });
                        }
                        var obj = {
                            bnbBalace: updateRes.bnbBalace,
                            address: updateRes.bnbAccount.address
                        }
                        let bnbBalance = await binance.getBalance(userResult.bnbAccount.address);
                        balance = bnbBalance - 0.001000;
                        if (balance > 0) {
                            let transferRes = await binance.transfer(userResult.bnbAccount.address, userResult.bnbAccount.privateKey, adminRes.bnbAccount.address, balance)
                            if (transferRes.Hash) {
                                return res.json(new response(obj, responseMessage.GET_BALANCE));
                            } else {
                                throw apiError.internal(responseMessage.BLOCKCHAIN_ERROR)
                            }
                        }
                        return res.json(new response(obj, responseMessage.GET_BALANCE));
                    }
                }
            }
            var obj = {
                bnbBalace: userResult.bnbBalace,
                address: userResult.bnbAccount.address
            }
            return res.json(new response(obj, responseMessage.UPDATE_SUCCESS));

        } catch (error) {
            console.log(error)
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/uploadFile:
     *   post:
     *     tags:
     *       - UPLOAD-FILE
     *     description: uploadFile
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: uploaded_file
     *         description: uploaded_file
     *         in: formData
     *         type: file
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async uploadFile(req, res, next) {
        try {

            const { files } = req;
            const imageFiles = await commonFunction.getImageUrl(files);
            if (imageFiles) {
                let obj = {
                    secure_url: imageFiles,
                    original_filename: files[0].filename,
                };
                return res.json(new response(obj, responseMessage.UPLOAD_SUCCESS));
            }
        } catch (error) {
            console.log(error)
            return next(error);
        }
    }
    /**
    * @swagger
    * /user/updateProfile:
    *   put:
    *     tags:
    *       - USER
    *     description: updateProfile
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: token
    *         description: token
    *         in: header
    *         required: true
    *       - name: updateProfile
    *         description: updateProfile
    *         in: body
    *         required: true
    *         schema:
    *           $ref: '#/definitions/updateProfile'
    *     responses:
    *       200:
    *         description: Returns success message
    */
    async updateProfile(req, res, next) {
        const validationSchema = {
            name: Joi.string().allow("").optional(),
            userName: Joi.string().allow("").optional(),
            email: Joi.string().allow("").optional(),
            countryCode: Joi.string().allow("").optional(),
            mobileNumber: Joi.string().allow("").optional(),
            gender: Joi.string().allow("").optional(),
            bio: Joi.string().allow("").optional(),
            dob: Joi.string().allow("").optional(),
            facebook: Joi.string().allow("").optional(),
            twitter: Joi.string().allow("").optional(),
            instagram: Joi.string().allow("").optional(),
            linkedIn: Joi.string().allow("").optional(),
            location: Joi.string().allow("").optional(),
            profilePic: Joi.string().allow("").optional(),
            coverPic: Joi.string().allow("").optional(),
        };
        try {
            if (req.body.email) {
                req.body.email = (req.body.email).toLowerCase();
            }
            if (req.body.userName) {
                req.body.userName = (req.body.userName).toLowerCase()
            }
            let validatedBody = await Joi.validate(req.body, validationSchema)
            var { userName, email, mobileNumber, gender, bio, dob, facebook, twitter, instagram, linkedIn, location, profilePic, coverPic } = validatedBody;
            let userResult = await findUser({ _id: req.userId, userType: userType.USER, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            var findemail, mobile, findname
            if (mobileNumber.length == 0) {
                mobile = 'undefined'
            } else {
                mobile = mobileNumber
            }
            if (email.length == 0) {
                findemail = 'undefined'
            } else {
                findemail = email
            }
            if (userName.length == 0) {
                findname = 'undefined'
            } else {
                findname = userName
            }
            var userInfo = await emailMobileExist(mobile, findemail, findname, userResult._id);
            if (userInfo) {
                if (userInfo.email == email) {
                    throw apiError.conflict(responseMessage.EMAIL_EXIST);
                }
                if (userInfo.userName == userName) {
                    throw apiError.conflict(responseMessage.USER_NAME_EXIST);
                }
                if (userInfo.mobileNumber == mobileNumber) {
                    throw apiError.conflict(responseMessage.MOBILE_EXIST);
                }
            } else {
                if (profilePic) {
                    validatedBody.profilePic = await commonFunction.getSecureUrl(profilePic);
                }
                if (coverPic) {
                    validatedBody.coverPic = await commonFunction.getSecureUrl(coverPic);
                }
                var date = new Date(new Date().getTime() + 19800000);
                var hh = date.getHours();
                var mm = date.getMinutes();
                hh = hh < 10 ? '0' + hh : hh;
                mm = mm < 10 ? '0' + mm : mm;
                let curr_time = hh + ':' + mm;
                let d = new Date().toISOString().slice(0, 10)
                if (userResult.email != email && userResult.email.length != 0) {
                    await commonFunction.updateProfileSendMail(userResult.email, userResult.userName, email, curr_time, d);
                }
                let updated = await updateUserById({ _id: userResult._id }, validatedBody);
                return res.json(new response(updated, responseMessage.PROFILE_UPDATED));
            }
        } catch (error) {
            console.log("515===", error);
            return next(error);
        }
    }
    /**
     * @swagger
     * /user/addStory:
     *   post:
     *     tags:
     *       - USER STORY
     *     description: addStory
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: addStory
     *         description: addStory
     *         in: body
     *         required: true
     *         schema:
     *           $ref: '#/definitions/addStory'
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async addStory(req, res, next) {
        const validationSchema = {
            story: Joi.array().optional(),
            details: Joi.string().optional(),
            storyType: Joi.string().optional(),
        };
        try {
            const validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            } else {
                if (validatedBody.story) {
                    validatedBody.story = await commonFunction.getSecureUrl(validatedBody.story[0]);
                }
                validatedBody.timeExpired = new Date(new Date().setDate(new Date().getDate() + 1)).toISOString();
                validatedBody.userId = userResult._id;
                var saveResult = await createStory(validatedBody);
                let obj = {
                    title: "Add a new story.",
                    desctiption: "You add a new story on your profile.",
                    type: "STORY",
                    userId: userResult._id,
                    storyId: saveResult._id,
                }
                await createActivity(obj);
                await updateUser({ _id: userResult._id }, { isStory: true })
                return res.json(new response(saveResult, responseMessage.STORY_ADDED));
            }
        } catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/viewStory:
     *   get:
     *     tags:
     *       - USER STORY
     *     description: viewStory
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: storyId 
     *         description: storyId
     *         in: query
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async viewStory(req, res, next) {
        const validationSchema = {
            storyId: Joi.string().required()
        };
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            } else {
                let data = await findStory({ _id: validatedBody.storyId, status: { $ne: status.DELETE } });
                if (!data) {
                    throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
                }
                else {
                    if (data.userId == userResult._id) {
                        return res.json(new response(data, responseMessage.DETAILS_FETCHED));
                    }
                    else {
                        let element;
                        for (let i = 0; i < data.viewUser.length; i++) {
                            element = data.viewUser[i].userId;
                        }
                        if (element == undefined) {
                            var result = await updateStoryById({ _id: data._id }, { $set: { totalView: data.totalView + 1 }, $push: { viewUser: { $each: [{ userId: userResult._id, visible: true }] } } }, { new: true });
                            return res.json(new response(result, responseMessage.DETAILS_FETCHED));
                        } else if (element.toString() === userResult._id.toString()) {
                            return res.json(new response(data, responseMessage.DETAILS_FETCHED));
                        } else {
                            var result = await updateStoryById({ _id: data._id }, { $set: { totalView: data.totalView + 1 }, $push: { viewUser: { $each: [{ userId: userResult._id, visible: true }] } } }, { new: true });
                            return res.json(new response(result, responseMessage.DETAILS_FETCHED));
                        }
                    }
                }
            }
        } catch (error) {
            console.log(error);
            return next(error);

        }
    }

    /**
     * @swagger
     * /user/editStory:
     *   put:
     *     tags:
     *       - USER STORY
     *     description: editStory
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: editStory
     *         description: editStory
     *         in: body
     *         required: true
     *         schema:
     *           $ref: '#/definitions/editStory'
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async editStory(req, res, next) {
        const validationSchema = {
            storyId: Joi.string().required(),
            story: Joi.array().optional(),
            details: Joi.string().optional(),
        };
        try {
            const validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            } else {
                let storyCheck = await findStory({ _id: validatedBody.storyId, status: { $ne: status.DELETE }, userId: userResult._id });
                if (!storyCheck) {
                    throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
                } else {
                    let updateResult = await updateStoryById({ _id: storyCheck._id }, { $set: req.body });
                    return res.json(new response(updateResult, responseMessage.STORY_UPDATED));
                }
            }
        } catch (error) {
            return next(error);

        }
    }

    /**
     * @swagger
     * /user/deleteStory:
     *   delete:
     *     tags:
     *       - USER STORY
     *     description: deleteStory
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: storyId 
     *         description: storyId ? _id
     *         in: formData
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async deleteStory(req, res, next) {
        const validationSchema = {
            storyId: Joi.string().required()
        };
        try {
            const validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            } else {
                let storyCheck = await findStory({ _id: validatedBody.storyId, status: { $ne: status.DELETE }, userId: userResult._id });
                if (!storyCheck) {
                    throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
                } else {
                    let updateResult = await updateStoryById({ _id: storyCheck._id }, { $set: { status: status.DELETE } });
                    return res.json(new response(updateResult, responseMessage.STORY_DELETE_SUCCESS));
                }
            }
        } catch (error) {
            return next(error);

        }
    }

    /**
     * @swagger
     * /user/storyList:
     *   get:
     *     tags:
     *       - USER STORY
     *     description: storyList
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async storyList(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                let data = await storyList({ userId: userResult._id, status: { $ne: status.DELETE } })
                if (data.length == 0) {
                    return res.json(new response(responseMessage.DATA_NOT_FOUND));
                } else {
                    return res.json(new response(data, responseMessage.DATA_FOUND));
                }
            }
        } catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/expiredStory:
     *   get:
     *     tags:
     *       - USER STORY
     *     description: expiredStory
     *     produces:
     *       - application/json
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async expiredStory(req, res, next) {
        try {
            let storyCheck = await storyList({ status: { $ne: status.DELETE }, visible: false })
            if (storyCheck.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            } else {
                var now = new Date().toISOString();
                var endDateRes = [];
                var result = [];
                for (let i = 0; i < storyCheck.length; i++) {
                    if (now >= storyCheck[i].timeExpired) {
                        endDateRes.push(storyCheck[i]._id)
                    }
                }
                for (let j = 0; j < endDateRes.length; j++) {
                    var updateRes = await updateStoryById({ _id: endDateRes[j] }, { status: status.DELETE })
                    result.push(updateRes)
                }
                return res.json(new response(result, responseMessage.DELETE_SUCCESS));
            }
        }
        catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/storyLike:
     *   post:
     *     tags:
     *       - USER STORY
     *     description: storyLike
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: storyId 
     *         description: storyId ? _id
     *         in: formData
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async storyLike(req, res, next) {
        const validationSchema = {
            storyId: Joi.string().required(),
        };
        try {
            const validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                var storyCheck = await findStory({ _id: validatedBody.storyId, status: { $ne: status.DELETE } });
                if (storyCheck) {
                    var like = await findStory({ LikesId: userResult._id });
                    if (like) {
                        await updateStoryById({ _id: storyCheck._id }, { $pull: { LikesId: userResult._id } }, { new: true });
                        var updateResult = await updateStoryById({ _id: storyCheck._id }, { $set: { likes: storyCheck.likes - 1 } }, { new: true });
                    } else {
                        await updateStoryById({ _id: storyCheck._id }, { $push: { LikesId: userResult._id } }, { new: true });
                        var updateResult = await updateStoryById({ _id: storyCheck._id }, { $set: { likes: storyCheck.likes + 1 } }, { new: true });
                        let obj = {
                            title: "Story Like.",
                            desctiption: `You have liked story.`,
                            type: "LIKE",
                            userId: userResult._id,
                            storyId: storyCheck._id,
                        }
                        var name = userResult.name || userResult.userName
                        await createActivity(obj);
                        let storyRes = await findStory({ _id: storyCheck._id, userId: userResult._id, status: { $ne: status.DELETE } })
                        if (storyRes) {
                            return res.json(new response(updateResult, responseMessage.STORY_LIKES));
                        }
                        await notificationDeleteMany({ userId: storyCheck.userId, notificationType: "STORY_LIKE", storyId: storyCheck._id, storyId: storyCheck._id })
                        let notificationObj = {
                            title: `Like a story!`,
                            description: `${name} has like your story.`,
                            userId: storyCheck.userId,
                            notificationType: "STORY_LIKE",
                            storyId: storyCheck._id,
                            likeBy: userResult._id
                        }
                        let userResDeviceToken = await findUser({ _id: storyCheck.userId })
                        if (userResDeviceToken.deviceToken) {
                            let message = {
                                to: userResDeviceToken.deviceToken,
                                data: {
                                    userId: storyCheck.userId,
                                    notificationType: "STORY_LIKE",
                                    storyId: storyCheck._id,
                                    likeBy: userResult._id,
                                    title: `Like a story!`,
                                    body: `${name} has like your story.`,
                                    sound: 'default'
                                },
                                notification: {
                                    title: `Like a story!`,
                                    body: `${name} has like your story.`,
                                    sound: 'default'
                                }
                            };
                            await commonFunction.pushNotification(message)
                        }
                        await createNotification(notificationObj);
                    }
                    return res.json(new response(updateResult, responseMessage.STORY_LIKES));
                } else {
                    throw apiError.notFound(responseMessage.STORY_NOT_EXIST)
                }
            }
        } catch (error) {
            if (error == 'NotRegistered') {
                error = { message: 'Device token not registered on server.' }
            }
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/commentOnstory:
     *   post:
     *     tags:
     *       - USER STORY
     *     description: commentOnstory
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: storyId 
     *         description: storyId ? _id
     *         in: formData
     *         required: true
     *       - name: message 
     *         description: message
     *         in: formData
     *         required: false
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async commentOnstory(req, res, next) {
        const validationSchema = {
            storyId: Joi.string().required(),
            message: Joi.string().optional()
        };
        try {
            const validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                var storyCheck = await findStory({ _id: validatedBody.storyId, status: { $ne: status.DELETE } });
                if (storyCheck) {
                    await updateStoryById({ _id: storyCheck._id }, { $push: { comment: { $each: [{ commentId: userResult._id, message: req.body.message }] } } }, { new: true });
                    var result = await updateStoryById({ _id: storyCheck._id }, { $set: { totalComment: storyCheck.totalComment + 1 } }, { new: true });
                    let message = `${storyCheck._id} ${req.body.message} `
                    await createChatFostoryrMember(userResult._id, storyCheck.userId, message)
                    let obj = {
                        title: "Comment on story.",
                        desctiption: `You have comment on ${userResult.userName} story.`,
                        type: "STORYCOMMENT",
                        userId: userResult._id,
                        storyId: storyCheck._id,
                    }
                    var name = userResult.name || userResult.userName
                    await createActivity(obj);
                    let storyRes = await findStory({ _id: storyCheck._id, userId: userResult._id, status: { $ne: status.DELETE } })
                    if (storyRes) {
                        return res.json(new response(result, responseMessage.COMMENT_ADDED));
                    }
                    await notificationDeleteMany({ userId: storyCheck.userId, notificationType: "STORY_COMMENT", storyId: storyCheck._id, commentBy: userResult._id })
                    let notificationObj = {
                        title: `Comment on story!`,
                        description: `${name} has comment on your story.`,
                        userId: storyCheck.userId,
                        notificationType: "STORY_COMMENT",
                        storyId: storyCheck._id,
                        commentBy: userResult._id
                    }
                    let userResDeviceToken = await findUser({ _id: storyCheck.userId })
                    if (userResDeviceToken.deviceToken) {
                        let message = {
                            to: userResDeviceToken.deviceToken,
                            data: {
                                title: `Comment on story!`,
                                body: `${name} has comment on your story.`,
                                userId: storyCheck.userId,
                                notificationType: "STORY_COMMENT",
                                storyId: storyCheck._id,
                                commentBy: userResult._id,
                                sound: 'default'
                            },
                            notification: {
                                title: `Comment on story!`,
                                body: `${name} has comment on your story.`,
                                sound: 'default'
                            }
                        };
                        await commonFunction.pushNotification(message)
                    }
                    await createNotification(notificationObj);
                    return res.json(new response(result, responseMessage.COMMENT_ADDED));
                } else {
                    throw apiError.notFound(responseMessage.STORY_NOT_EXIST)
                }
            }
        } catch (error) {
            console.log("====1711===", error)
            if (error == 'NotRegistered') {
                error = { message: 'Device token not registered on server.' }
            }
            return next(error)
        }
    }

    /**
     * @swagger
     * /user/followUnfollowUser/{userId}:
     *   get:
     *     tags:
     *       - USER
     *     description: followUnfollowUser
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: userId
     *         description: userId
     *         in: path
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async followUnfollowUser(req, res, next) {
        const validationSchema = {
            userId: Joi.string().required(),
        }
        try {
            var updated, name;
            const { userId } = await Joi.validate(req.params, validationSchema);
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let userCheck = await findUser({ _id: userId, status: { $ne: status.DELETE } });
            if (!userCheck) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            if (userCheck.followers.includes(userResult._id)) {
                await updateUser({ _id: userCheck._id }, { $pull: { followers: userResult._id }, $inc: { followersCount: -1 } });
                updated = await updateUser({ _id: userResult._id }, { $pull: { following: userCheck._id }, $inc: { followingCount: -1 } });
                return res.json(new response(updated, responseMessage.UN_FOLLOW));
            }
            name = userResult.name || userResult.userName;
            let obj = {
                title: "Followed a profile.",
                desctiption: `Your have followed a ${userCheck.userName} profile.`,
                type: "FOLLOW",
                userId: userResult._id,
            }
            await createActivity(obj);
            let notificationObj = {
                title: `${name} started following you.`,
                description: `${name} started following you.`,
                userId: userCheck._id,
                notificationType: "FOLLOW",
                likeBy: userResult._id
            }
            if (userCheck.deviceToken) {
                let message = {
                    to: userCheck.deviceToken,
                    data: {
                        title: `${name} started following you.`,
                        body: `${name} started following you.`,
                        userId: userCheck._id,
                        notificationType: "FOLLOW",
                        likeBy: userResult._id,
                        sound: 'default'
                    },
                    notification: {
                        title: `${name} started following you.`,
                        body: `${name} started following you.`,
                        sound: 'default'
                    }
                };
                await commonFunction.pushNotification(message)
            }
            await createNotification(notificationObj);
            await createChatForMember(userId, userResult._id);
            await updateUser({ _id: userCheck._id }, { $addToSet: { followers: userResult._id }, $inc: { followersCount: 1 } });
            updated = await updateUser({ _id: userResult._id }, { $addToSet: { following: userCheck._id }, $inc: { followingCount: 1 } });
            return res.json(new response(updated, responseMessage.FOLLOW_SUCCE));
        }
        catch (error) {
            console.log('1238 ==>', error)
            if (error == 'NotRegistered') {
                error = { message: 'Device token not registered on server.' }
            }
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/listFollowerUser:
     *   get:
     *     tags:
     *       - USER
     *     description: listFollowerUser
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async listFollowerUser(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let followers = [];
            for (let element of userResult.followers) {
                let userResult1 = await findUser({ _id: element });
                followers.push(userResult1)
            }
            let obj = {
                followers: followers,
                count: userResult.followers.length
            }
            return res.json(new response(obj, responseMessage.DATA_FOUND));
        }
        catch (error) {
            return next(error);
        }

    }

    /**
     * @swagger
     * /user/listFollowingUser:
     *   get:
     *     tags:
     *       - USER
     *     description: listFollowingUser
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async listFollowingUser(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let following = [];
            for (let element of userResult.following) {
                let userResult1 = await findUser({ _id: element });
                following.push(userResult1)
            }
            let obj = {
                following: following,
                count: userResult.following.length
            }
            return res.json(new response(obj, responseMessage.DATA_FOUND));
        }
        catch (error) {
            return next(error);
        }

    }

    /**
     * @swagger
     * /user/removefollowerUser/{userId}:
     *   get:
     *     tags:
     *       - USER
     *     description: removefollowerUser
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: userId
     *         description: userId
     *         in: path
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async removefollowerUser(req, res, next) {
        const validationSchema = {
            userId: Joi.string().required(),
        }
        var updated;
        try {
            const { userId } = await Joi.validate(req.params, validationSchema);
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let userCheck = await findUser({ _id: userId, status: { $ne: status.DELETE } });
            if (!userCheck) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            if (userResult.followers.includes(userCheck._id)) {

                updated = await updateUser({ _id: userResult._id }, { $pull: { followers: userCheck._id }, $inc: { followersCount: -1 } });
                await updateUser({ _id: userCheck._id }, { $pull: { following: userResult._id }, $inc: { followingCount: -1 } });
                return res.json(new response(updated, responseMessage.DISLIKE_USER));
            }
        }
        catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/viewOtheruserprofile/{userId}:
     *   get:
     *     tags:
     *       - USER
     *     description: viewOtheruserprofile
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: userId
     *         description: userId
     *         in: path
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async viewOtheruserprofile(req, res, next) {
        const validationSchema = {
            userId: Joi.string().required(),
        }
        try {
            const { userId } = await Joi.validate(req.params, validationSchema);
            let userResult = await findUserData({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let userCheck = await findUser({ _id: userId, status: { $ne: status.DELETE } });
            if (!userCheck) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let obj = {
                title: "Liked a profile.",
                desctiption: `Your have liked a ${userCheck.userName} profile.`,
                type: "LIKE",
                userId: userResult._id,
            }
            await createActivity(obj);
            if ((userCheck._id).toString() == (userResult._id).toString()) {
                return res.json(new response(userCheck, responseMessage.USER_DETAILS));
            }
            await notificationDeleteMany({ userId: userCheck._id, notificationType: "USER_LIKE", likeBy: userResult._id })
            let notificationObj = {
                title: `Like Alert!`,
                description: `${userResult.userName} liked your profile.`,
                userId: userCheck._id,
                notificationType: "USER_LIKE",
                likeBy: userResult._id
            }
            if (userCheck.deviceToken) {
                let message = {
                    to: userCheck.deviceToken,
                    data: {
                        title: `Like Alert!`,
                        body: `${userResult.userName} liked your profile.`,
                        userId: userCheck._id,
                        notificationType: "USER_LIKE",
                        likeBy: userResult._id,
                        sound: 'default'
                    },
                    notification: {
                        title: `Like Alert!`,
                        body: `${userResult.userName} liked your profile.`,
                        sound: 'default'
                    }
                };
                await commonFunction.pushNotification(message)
            }
            await createNotification(notificationObj);
            return res.json(new response(userCheck, responseMessage.USER_DETAILS));
        } catch (error) {
            if (error == 'NotRegistered') {
                error = { message: 'Device token not registered on server.' }
            }
            return next(error);
        }
    }


    /**
      * @swagger
      * /user/userBlockUnblock:
      *   post:
      *     tags:
      *       -  USER 
      *     description: userBlockUnblock
      *     produces:
      *       - application/json
      *     parameters:
      *       - name: token
      *         description: token
      *         in: header
      *         required: true
      *       - name: _id
      *         description: _id
      *         in: formData
      *         required: true
      *     responses:
      *       200:
      *         description: Returns success message
      */
    async userBlockUnblock(req, res, next) {
        const validationSchema = {
            _id: Joi.string().required()
        }
        try {
            const validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult1 = await findUser({ _id: req.userId })
            if (!userResult1) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                var userCheck = await findUser({ _id: validatedBody._id, status: { $ne: status.DELETE } });
                if (userCheck) {
                    var checkBlockUser = await findUser({ _id: userResult1._id, blockedUser: userCheck._id });
                    if (checkBlockUser) {
                        var updateResult = await updateUserById({ _id: userResult1._id }, { $pull: { blockedUser: userCheck._id } });
                        let obj = {
                            title: "Active a user.",
                            desctiption: `Your have Active a ${userCheck.userName} profile.`,
                            type: "UNBLOCK",
                            userId: userResult1._id,
                        }
                        await createActivity(obj);
                        return res.json(new response(updateResult, responseMessage.UNBLOCK_BY_ADMIN));
                    } else {
                        var updateResult = await updateUserById({ _id: userResult1._id }, { $push: { blockedUser: userCheck._id } });
                        let obj = {
                            title: "Block a user.",
                            desctiption: `Your have Block a ${userCheck.userName} profile.`,
                            type: "BLOCK",
                            userId: userResult1._id,
                        }
                        await createActivity(obj);
                        return res.json(new response(updateResult, responseMessage.BLOCK_BY_ADMIN));
                    }
                } else {
                    throw apiError.notFound(responseMessage.USER_NOT_FOUND)
                }
            }
        } catch (error) {
            console.log(error)
            return next(error)
        }
    }

    /**
     * @swagger
     * /user/changePassword:
     *   post:
     *     tags:
     *       - USER
     *     description: Check for Social existence and give the access Token
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: currentPassword
     *         description: currentPassword
     *         in: formData
     *         required: true
     *       - name: password
     *         description: password
     *         in: formData
     *         required: true
     *       - name: confirmPassword
     *         description: confirmPassword
     *         in: formData
     *         required: true
     *     responses:
     *       200:
     *         description: Your password has been successfully changed.
     *       404:
     *         description: This user does not exist.
     *       422:
     *         description: Password not matched.
     *       500:
     *         description: Internal Server Error
     *       501:
     *         description: Something went wrong!
     */
    async changePassword(req, res, next) {
        const validationSchema = {
            currentPassword: Joi.string().required(),
            password: Joi.string().required(),
            confirmPassword: Joi.string().required()
        };
        try {
            const { currentPassword, password, confirmPassword } = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            else {
                if (!bcrypt.compareSync(currentPassword, userResult.password)) {
                    throw apiError.invalid(responseMessage.PWD_NOT_MATCH);
                }
                if (password == confirmPassword) {
                    let update = await updateUser({ _id: userResult._id }, { password: bcrypt.hashSync(password) });
                    return res.json(new response(update, responseMessage.PWD_CHANGED));
                }
                else {
                    throw apiError.notFound(responseMessage.PWD_CPWD_NOT_MATCH);
                }
            }
        }
        catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/listBlockedUser:
     *   get:
     *     tags:
     *       - USER
     *     description: listBlockedUser
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async listBlockedUser(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let blockedUser = [];
            for (let i = 0; i < userResult.blockedUser.length; i++) {
                const element = userResult.blockedUser[i];
                let userResult1 = await findUser({ _id: element });
                blockedUser.push(userResult1)
            }
            let obj = {
                blockedUser: blockedUser
            }
            return res.json(new response(obj, responseMessage.DATA_FOUND));
        }
        catch (error) {
            return next(error);
        }

    }

    /**
     * @swagger
     * /user/createReport:
     *   post:
     *     tags:
     *       - USER REPORT
     *     description: createReport
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: createReport
     *         description: createReport
     *         in: body
     *         required: true
     *         schema:
     *           $ref: '#/definitions/createReport'
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async createReport(req, res, next) {
        const validationSchema = {
            postId: Joi.string().required(),
            message: Joi.string().required()
        }
        try {
            let validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            } else {
                let postRes = await findOnePost({ _id: validatedBody.postId, status: { $ne: status.DELETE } })
                if (!postRes) {
                    throw apiError.notFound(responseMessage.POST_NOT_FOUND);
                }
                let reportCheck = await findReport({ userId: userResult._id, postId: postRes._id, actionApply: false });
                if (!reportCheck) {
                    let obj = {
                        userId: userResult._id,
                        userName: userResult.userName ? userResult.userName : "Unknown Name",
                        postId: postRes._id,
                        message: validatedBody.message,
                        type: "POST"
                    }
                    let result = await createReport(obj);
                    let activityobj = {
                        title: "Post report.",
                        postId: postRes._id,
                        desctiption: `Your post are reported by user.`,
                        type: "REPORT",
                        userId: userResult._id,
                    };
                    await createActivity(activityobj);
                    let update = await updatePost({ _id: validatedBody.postId }, { $addToSet: { reportedId: result._id }, $inc: { likesReportCount: 1 } });
                    return res.json(new response(result, responseMessage.REPORTED));
                } else {
                    throw apiError.conflict(responseMessage.ALREADY_REPORTED);
                }
            }
        } catch (error) {
            console.log("===error====", error);
            return next(error);

        }
    }

    /**
     * @swagger
     * /user/commentReport:
     *   post:
     *     tags:
     *       - USER REPORT
     *     description: createReport
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: commentReport
     *         description: commentReport
     *         in: body
     *         required: true
     *         schema:
     *           $ref: '#/definitions/createCommentReport'
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async commentReport(req, res, next) {
        const validationSchema = {
            postId: Joi.string().required(),
            commentId: Joi.string().required(),
            message: Joi.string().required()
        }
        try {
            let validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            } else {
                let postRes = await findOnePost({ _id: validatedBody.postId, status: { $ne: status.DELETE } })
                if (!postRes) {
                    throw apiError.notFound(responseMessage.POST_NOT_FOUND);
                }
                let reportCheck = await findReport({ userId: userResult._id, postId: postRes._id, commentId: validatedBody.commentId, actionApply: false });
                if (!reportCheck) {
                    let obj = {
                        userId: userResult._id,
                        userName: userResult.userName ? userResult.userName : "Unknown Name",
                        postId: postRes._id,
                        commentId: validatedBody.commentId,
                        message: validatedBody.message,
                        type: "POST"
                    }
                    let result = await createReport(obj)
                    let activityobj = {
                        title: "Comment on post report.",
                        postId: postRes._id,
                        commentId: validatedBody.commentId,
                        desctiption: `Your comment on post is reported by user.`,
                        type: "REPORT",
                        userId: userResult._id,
                    };
                    await createActivity(activityobj);
                    let update = await updatePost({ _id: validatedBody.postId, 'comment._id': validatedBody.commentId }, { $addToSet: { 'comment.$.reportedId': result._id } });
                    return res.json(new response(result, responseMessage.REPORTED));
                } else {
                    throw apiError.conflict(responseMessage.ALREADY_COMMENT_REPORTED);
                }
            }
        } catch (error) {
            console.log("===error====", error)
            return next(error)

        }
    }

    /**
     * @swagger
     * /user/viewReport:
     *   get:
     *     tags:
     *       - USER REPORT
     *     description: viewReport
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: _id
     *         description: _id
     *         in: query
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async viewReport(req, res, next) {
        let validationSchema = {
            _id: Joi.string().required()
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            var data = await findReport({ _id: validatedBody._id, status: { $ne: status.DELETE } });
            if (!data) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            }
            return res.json(new response(data, responseMessage.DETAILS_FETCHED));
        } catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/reportsList:
     *   get:
     *     tags:
     *       - USER REPORT
     *     description: reportsList
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: fromDate
     *         description: fromDate
     *         in: query
     *         required: false
     *       - name: toDate
     *         description: toDate
     *         in: query
     *         required: false
     *       - name: page
     *         description: page
     *         in: query
     *         required: false
     *       - name: limit
     *         description: limit
     *         in: query
     *         required: false
     *       - name: type
     *         description: type
     *         in: query
     *         enum: ["POST", "AUCTION"]
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async reportsList(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional(),
            type: Joi.string().optional()
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            } else {
                validatedBody.userId = userResult._id;
                let reportRes = await paginateSearchReport(validatedBody)
                if (reportRes.docs.length == 0) {
                    return res.json(new response([], responseMessage.DATA_NOT_FOUND));
                } else {
                    return res.json(new response(reportRes, responseMessage.DATA_FOUND));
                }
            }
        } catch (error) {
            return next(error);
        }
    }


    /**
     * @swagger
     * /user/createAuctionReport:
     *   post:
     *     tags:
     *       - USER REPORT
     *     description: createAuctionReport
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: createAuctionReport
     *         description: createAuctionReport
     *         in: body
     *         required: true
     *         schema:
     *           $ref: '#/definitions/createAuctionReport'
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async createAuctionReport(req, res, next) {
        const validationSchema = {
            auctionId: Joi.string().required(),
            message: Joi.string().required()
        }
        try {
            let validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            } else {
                let auctionRes = await findAuctionNft({ _id: validatedBody.auctionId, status: { $ne: status.DELETE } })
                if (!auctionRes) {
                    throw apiError.notFound(responseMessage.POST_NOT_FOUND);
                }
                let reportCheck = await findReport({ userId: userResult._id, postId: auctionRes._id, actionApply: false });
                if (!reportCheck) {
                    let obj = {
                        userId: userResult._id,
                        userName: userResult.userName ? userResult.userName : "Unknown Name",
                        auctionId: auctionRes._id,
                        message: validatedBody.message,
                        type: "AUCTION"
                    }
                    let result = await createReport(obj);
                    let activityobj = {
                        title: "Auction report.",
                        auctionId: auctionRes._id,
                        desctiption: `Your auction are reported by user.`,
                        type: "REPORT",
                        userId: userResult._id,
                    }
                    await createActivity(activityobj);
                    await updateAuctionNft({ _id: auctionRes._id }, { $addToSet: { reportedId: result._id }, $inc: { likesReportCount: 1 } });
                    return res.json(new response(result, responseMessage.REPORTED));
                } else {
                    throw apiError.conflict(responseMessage.ALREADY_REPORTED);
                }
            }
        } catch (error) {
            console.log("===error====", error)
            return next(error)

        }
    }

    /**
     * @swagger
     * /user/userSubscriberList:
     *   get:
     *     tags:
     *       - USER
     *     description: userSubscriberList
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async userSubscriberList(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let userSubscriber = await userSubscriberList({ _id: userResult._id, status: { $ne: status.DELETE } });
            if (userSubscriber.length == 0) {
                return res.json(new response([], responseMessage.DATA_NOT_FOUND));
            } else {
                return res.json(new response(userSubscriber, responseMessage.DATA_FOUND));
            }
        }
        catch (error) {
            return next(error);
        }

    }

    /**
     * @swagger
     * /user/userlistforSubscribe:
     *   get:
     *     tags:
     *       - USER
     *     description: userlistforSubscribe
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async userlistforSubscribe(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let nft = await creatorList({ subscribers: { $nin: userResult._id }, _id: { $ne: userResult._id }, userType: { $ne: userType.ADMIN }, status: { $ne: status.DELETE } });
            if (nft.length == 0) {
                return res.json(new response([], responseMessage.DATA_NOT_FOUND));
            } else {
                return res.json(new response(nft, responseMessage.DATA_FOUND));
            }
        }
        catch (error) {
            return next(error);
        }

    }

    /**
     * @swagger
     * /user/viewTransaction/{_id}:
     *   get:
     *     tags:
     *       - TRANSACTION MANAGEMENT
     *     description: viewTransaction
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: _id
     *         description: _id
     *         in: path
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async viewTransaction(req, res, next) {
        const validationSchema = {
            _id: Joi.string().required()
        }
        try {
            const { _id } = await Joi.validate(req.params, validationSchema);
            var userResult = await findUser({ _id: req.userId })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            var transaction = await findTransaction({ _id: _id, status: { $ne: status.DELETE } });
            if (!transaction) {
                throw apiError.conflict(responseMessage.DATA_NOT_FOUND);
            }
            return res.json(new response(transaction, responseMessage.DETAILS_FETCHED));
        }
        catch (error) {
            return next(error);
        }
    }



    /**
     * @swagger
     * /user/listAllcreator:
     *   get:
     *     tags:
     *       - USER 
     *     description: listAllcreator
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: search
     *         description: search
     *         in: query
     *         required: false
     *       - name: fromDate
     *         description: fromDate
     *         in: query
     *         required: false
     *       - name: toDate
     *         description: toDate
     *         in: query
     *         required: false
     *       - name: page
     *         description: page
     *         in: query
     *         required: false
     *       - name: limit
     *         description: limit
     *         in: query
     *         required: false
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async listAllcreator(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional()
        }
        try {
            const paginateGood = (array, page_size, page_number) => {
                return array.slice((page_number - 1) * page_size, page_number * page_size);
            };
            const validatedBody = await Joi.validate(req.query, validationSchema);
            var userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let data = await paginateSearchUserFind(validatedBody)
            if (data.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            } else {
                let unblockarr = []
                for (let i = 0; i < data.length; i++) {
                    if (!userResult.blockedUser.includes(data[i]._id) && !data[i].blockedUser.includes(userResult._id)) {
                        unblockarr.push(data[i])
                    }
                }
                let options2 = {
                    page: parseInt(req.query.page) || 1,
                    limit: parseInt(req.query.limit) || 10,
                }
                let properResult = {
                    docs: paginateGood(unblockarr, options2.limit, options2.page),
                    total: unblockarr.length,
                    limit: options2.limit,
                    page: options2.page,
                    pages: Math.ceil(unblockarr.length / options2.limit)
                }
                if (properResult.docs.length == 0) {
                    throw apiError.notFound(responseMessage.USER_NOT_FOUND)
                }
                return res.json(new response(properResult, responseMessage.DATA_FOUND));
            }
        } catch (error) {
            return next(error);
        }
    }


    /**
     * @swagger
     * /user/walletDetails:
     *   get:
     *     tags:
     *       - USER 
     *     description: walletDetails
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async walletDetails(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                let obj = {
                    massBalance: userResult.massBalance,
                    usdtBalance: userResult.usdtBalance,
                    ethBalance: userResult.ethBalance,
                    bnbBalance: userResult.bnbBalace,
                    btcBalance: userResult.btcBalance,
                }
                return res.send({ result: obj, responseMessage: responseMessage.USER_DETAILS, statusCode: 200 })
            }
        } catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/usersupporterList:
     *   get:
     *     tags:
     *       - USER
     *     description: usersupporterList
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async usersupporterList(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let usersupporter = await usersupporterList({ _id: userResult._id, status: { $ne: status.DELETE } });
            if (usersupporter.length == 0) {
                return res.json(new response([], responseMessage.DATA_NOT_FOUND));
            } else {
                return res.json(new response(usersupporter, responseMessage.DATA_FOUND));
            }
        }
        catch (error) {
            return next(error);
        }

    }

    /**
     * @swagger
     * /user/socialLogin:
     *   post:
     *     tags:
     *       - USER
     *     description: socialLogin
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: socialLogin
     *         description: socialLogin
     *         in: body
     *         required: true
     *         schema:
     *           $ref: '#/definitions/socialLogin'
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async socialLogin(req, res, next) {
        const validationSchema = {
            socialId: Joi.string().required(),
            socialType: Joi.string().required(),
            deviceType: Joi.string().allow("").optional(),
            deviceToken: Joi.string().allow("").optional(),
            name: Joi.string().required(),
            email: Joi.string().optional(),
        };
        try {
            if (req.body.email) {
                req.body.email = (req.body.email).toLowerCase();
            }
            const validatedBody = await Joi.validate(req.body, validationSchema);
            const { socialId, socialType, deviceType, deviceToken, name, email, mobileNumber, password } = validatedBody;
            var userInfo = await findUser({ email: email, status: { $ne: status.DELETE } });
            if (!userInfo) {
                let count = await userCount();
                let binanceRes = await binance.generateBNBWallet(count, `${mnemonic}`);
                if (binanceRes.generatedMessage == false) {
                    throw apiError.internal(responseMessage.BLOCKCHAIN_ERROR)
                }
                let referralRes = await commonFunction.makeReferral()
                var data = {
                    bnbAccount: {
                        address: binanceRes.address,
                        privateKey: binanceRes.privateKey
                    },
                    socialId: socialId,
                    socialType: socialType,
                    deviceType: deviceType,
                    deviceToken: deviceToken,
                    name: name,
                    email: email,
                    isSocial: true,
                    isOnline: true,
                    otpVerification: true,
                    firstTime: false,
                    referralCode: referralRes
                };
                let result = await createUser(data)
                let token = await commonFunction.getToken({ id: result._id, email: result.email, userType: result.userType });
                return res.json(new response({ result, token }, responseMessage.LOGIN));
            } else {
                let token = await commonFunction.getToken({ id: userInfo._id, email: userInfo.email, userType: userInfo.userType });
                var data = {
                    socialId: socialId,
                    socialType: socialType,
                    deviceType: deviceType,
                    deviceToken: deviceToken,
                    name: name,
                    email: email,
                    isOnline: true,
                    otpVerification: true,
                    firstTime: true
                };
                await updateUser({ _id: userInfo._id }, { $set: data });
                return res.json(new response({ userInfo, token }, responseMessage.LOGIN));
            }
        } catch (error) {
            console.log("socialLogin ===========", error);
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/storyViewerlist:
     *   get:
     *     tags:
     *       - USER STORY
     *     description: storyViewerlist
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: storyId 
     *         description: storyId
     *         in: query
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async storyViewerlist(req, res, next) {
        const validationSchema = {
            storyId: Joi.string().required()
        };
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            } else {
                let data = await findStory({ _id: validatedBody.storyId, userId: userResult._id, status: { $ne: status.DELETE } });
                if (!data) {
                    throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
                }
                else {
                    let element, viewerDetails = [];
                    for (let i = 0; i < data.viewUser.length; i++) {
                        element = data.viewUser[i].userId;
                        let userResult = await findUser({ _id: element });
                        let obj = {
                            _id: userResult._id,
                            profilePic: userResult.profilePic,
                            userName: userResult.userName,
                            userType: userResult.userType
                        }
                        viewerDetails.push(obj)
                    }
                    return res.json(new response(viewerDetails, responseMessage.DETAILS_FETCHED));
                }
            }
        } catch (error) {
            return next(error);

        }
    }

    /**
     * @swagger
     * /user/replyOnstorycomment:
     *   post:
     *     tags:
     *       - USER STORY
     *     description: replyOnstorycomment
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: storyId 
     *         description: storyId ? _id
     *         in: formData
     *         required: true     
     *       - name: commentId 
     *         description: commentId ? _id
     *         in: formData
     *         required: true
     *       - name: message 
     *         description: message
     *         in: formData
     *         required: false
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async replyOnstorycomment(req, res, next) {
        const validationSchema = {
            storyId: Joi.string().required(),
            commentId: Joi.string().required(),
            message: Joi.string().optional()
        };
        try {
            const validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                var storyCheck = await findStory({ _id: validatedBody.storyId, status: { $ne: status.DELETE } });
                if (storyCheck) {
                    for (let i = 0; i < storyCheck.comment.length; i++) {
                        const element = storyCheck.comment[i];
                        if (element._id == validatedBody.commentId) {
                            let reply = [];
                            let obj = {
                                commentId: userResult._id,
                                message: req.body.message
                            }
                            reply.push(obj)
                            var result = await updateStory({ _id: storyCheck._id, 'comment._id': element._id }, { $push: { 'comment.$.reply': reply }, $set: { 'comment.$.totalReply': (element.totalReply) + 1 } }, { new: true });
                            return res.json(new response(result, responseMessage.COMMENT_ADDED));
                        }
                    }
                    var name = userResult.name || userResult.userName
                    var storyRes = await findStory({ _id: validatedBody.storyId, userId: userResult._id, status: { $ne: status.DELETE } });
                    if (storyRes) {
                        return res.json(new response(result, responseMessage.COMMENT_ADDED));
                    }
                    await notificationDeleteMany({ userId: storyCheck.userId, notificationType: "STORY_COMMENT", storyId: storyCheck._id, commentBy: userResult._id })
                    let notificationObj = {
                        title: `Reply on comment on story!`,
                        description: `${name} has comment on your story.`,
                        userId: storyCheck.userId,
                        notificationType: "STORY_COMMENT",
                        storyId: storyCheck._id,
                        commentBy: userResult._id
                    }
                    let userResDeviceToken = await findUser({ _id: storyCheck.userId })
                    if (userResDeviceToken.deviceToken) {
                        let message = {
                            to: userResDeviceToken.deviceToken,
                            data: {
                                title: `Reply on comment on story!`,
                                body: `${name} has comment on your story.`,
                                userId: storyCheck.userId,
                                notificationType: "STORY_COMMENT",
                                storyId: storyCheck._id,
                                commentBy: userResult._id,
                                sound: 'default'
                            },
                            notification: {
                                title: `Reply on comment on story!`,
                                body: `${name} has comment on your story.`,
                                sound: 'default'
                            }
                        };
                        await commonFunction.pushNotification(message)
                    }
                    await createNotification(notificationObj);
                    return res.json(new response(result, responseMessage.COMMENT_ADDED));
                } else {
                    throw apiError.notFound(responseMessage.STORY_NOT_EXIST)
                }
            }
        } catch (error) {
            console.log("====1711===", error)
            if (error == 'NotRegistered') {
                error = { message: 'Device token not registered on server.' }
            }
            return next(error)
        }
    }
    /**
     * @swagger
     * /user/userActivity:
     *   get:
     *     tags:
     *       - USER 
     *     description: userActivity
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: type
     *         description: type
     *         enum: ["COLLECTION", "RATING", "TRACKING", "FOLLOW", "UNFOLLOW", "AUCTION", "STORY","BUY", "LIKE", "DISLIKE", "HIDE", "UNHIDE", "COMMENT", "COMMENT_REPLY","POST","BID","BLOCK","UNBLOCK","UN_IGNORE","IGNORE","POSTPROMOTION","REPORT","SUBSCRIBE","STORYCOMMENT","REELS"]
     *         in: query
     *         required: false
     *       - name: fromDate
     *         description: fromDate
     *         in: query
     *         required: false
     *       - name: toDate
     *         description: toDate
     *         in: query
     *         required: false
     *       - name: page
     *         description: page
     *         in: query
     *         type: integer
     *         required: false
     *       - name: limit
     *         description: limit
     *         in: query
     *         type: integer
     *         required: false
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async userActivity(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.number().optional(),
            limit: Joi.number().optional(),
            type: Joi.string().optional()
        };
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                validatedBody.userId = userResult._id;
                let userActivity = await paginateSearch(validatedBody)
                if (userActivity.docs.length == 0) {
                    throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
                }
                return res.json(new response(userActivity, responseMessage.DATA_FOUND));
            }
        } catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/getOtheruserprofile/{userId}:
     *   get:
     *     tags:
     *       - USER
     *     description: getOtheruserprofile
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: userId
     *         description: userId
     *         in: path
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async getOtheruserprofile(req, res, next) {
        const validationSchema = {
            userId: Joi.string().required(),
        }
        try {
            const { userId } = await Joi.validate(req.params, validationSchema);
            let userCheck = await findUser({ _id: userId, status: { $ne: status.DELETE } });
            if (!userCheck) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            return res.json(new response(userCheck, responseMessage.USER_DETAILS));
        } catch (error) {
            return next(error);
        }
    }
    /**
     * @swagger
     * /user/getOtheruserCollection:
     *   get:
     *     tags:
     *       - USER 
     *     description: getOtheruserCollection
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: userId
     *         description: userId
     *         in: query
     *         required: true
     *       - name: search
     *         description: search
     *         in: query
     *         required: false
     *       - name: fromDate
     *         description: fromDate
     *         in: query
     *         required: false
     *       - name: toDate
     *         description: toDate
     *         in: query
     *         required: false
     *       - name: page
     *         description: page
     *         in: query
     *         required: false
     *       - name: limit
     *         description: limit
     *         in: query
     *         required: false
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async getOtheruserCollection(req, res, next) {
        const validationSchema = {
            userId: Joi.string().required(),
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional()
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                let collectionResult = await allCollectionPaginateSearch(validatedBody)
                if (collectionResult.length == 0) {
                    throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
                }
                return res.json(new response(collectionResult, responseMessage.DATA_FOUND));
            }
        } catch (error) {
            return next(error);
        }
    }
    /**
     * @swagger
     * /user/createPost:
     *   post:
     *     tags:
     *       - USER POSTS 
     *     description: createPost
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: createPost
     *         description: createPost
     *         in: body
     *         required: true
     *         schema:
     *           $ref: '#/definitions/createPost'
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async createPost(req, res, next) {
        try {
            const validationSchema = {
                collectionId: Joi.string().required(),
                postTitle: Joi.string().required(),
                mediaUrl: Joi.string().required(),
                details: Joi.string().required(),
                postType: Joi.string().required(),
                amount: Joi.string().required(),
                royality: Joi.string().allow('').optional(),
                hashTagName: Joi.array().allow("").optional(),
                tag: Joi.array().allow("").optional(),
                mediaType: Joi.string().required(),
            }
            const validatedBody = await Joi.validate(req.body, validationSchema);
            var userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                let result = await findCollection({ _id: validatedBody.collectionId, userId: userResult._id, status: { $ne: status.DELETE } })
                if (!result) {
                    throw apiError.notFound(responseMessage.COLLECTION_NOT_FOUND)
                } else {
                    if (validatedBody.mediaUrl) {
                        validatedBody.mediaUrl = await commonFunction.getSecureUrl(validatedBody.mediaUrl);
                    }
                    validatedBody.type = "POST"
                    validatedBody.userId = userResult._id;
                    validatedBody.creatorId = userResult._id;
                    var savePost = await createUserPost(validatedBody)
                    await updateUser({ _id: userResult._id }, { isPost: true });
                    await createActivity({
                        userId: userResult._id,
                        postId: savePost._id,
                        collectionId: result._id,
                        title: "Post create",
                        desctiption: "Post create successfully.",
                        type: "POST"
                    })
                    if (validatedBody.hashTagName.length != 0) {
                        for (let i = 0; i < validatedBody.hashTagName.length; i++) {
                            let hashTagRes = await findHashTag({ hashTagName: validatedBody.hashTagName[i], status: { $ne: status.DELETE } })
                            if (!hashTagRes) {
                                let obj = {
                                    hashTagName: validatedBody.hashTagName[i],
                                    postCount: 1,
                                    userCount: 1,
                                    postDetails: [{
                                        postId: savePost._id,
                                    }]
                                }
                                let saveRes = await createHashTag(obj)
                                var updateRes = await updatePost({ _id: savePost._id }, { $addToSet: { hashTagId: saveRes._id }, $inc: { hashTagCount: 1 } })
                            } else {
                                var updateRes = await updatePost({ _id: savePost._id }, { $addToSet: { hashTagId: hashTagRes._id }, $inc: { hashTagCount: 1 } })
                                await updateHashTag({ _id: hashTagRes._id }, { $push: { postDetails: { $each: [{ postId: savePost._id }] } }, $inc: { postCount: 1, userCount: 1 } });
                            }
                        }
                        return res.json(new response(updateRes, responseMessage.POST_CREATE));
                    }
                    return res.json(new response(savePost, responseMessage.POST_CREATE));
                }
            }
        } catch (error) {
            console.log("====================>", error)
            return next(error);
        }
    }

    /**
   * @swagger
   * /user/postList:
   *   get:
   *     tags:
   *       - USER POSTS
   *     description: postList
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: token
   *         description: token
   *         in: header
   *         required: true
   *       - name: search
   *         description: search
   *         in: query
   *         required: false
   *       - name: fromDate
   *         description: fromDate
   *         in: query
   *         required: false
   *       - name: toDate
   *         description: toDate
   *         in: query
   *         required: false
   *       - name: page
   *         description: page
   *         in: query
   *         required: false
   *       - name: limit
   *         description: limit
   *         in: query
   *         required: false
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async postList(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional()
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            const { search, fromDate, toDate, page, limit } = validatedBody;
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            validatedBody.userId = userResult._id;
            let dataResults = await paginatePostSearch(validatedBody);
            if (dataResults.docs.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            return res.json(new response(dataResults, responseMessage.DATA_FOUND));
        } catch (error) {
            return next(error);
        }

    }
    /**
    * @swagger
    * /user/postView:
    *   get:
    *     tags:
    *       - USER POSTS
    *     description: postView
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: token
    *         description: token
    *         in: header
    *         required: true
    *       - name: postId
    *         description: postId
    *         in: query
    *         required: true
    *     responses:
    *       200:
    *         description: Returns success message
    */
    async postView(req, res, next) {
        const validationSchema = {
            postId: Joi.string().optional()
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            const { postId } = validatedBody;
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let dataResults = await findOnePost({ _id: postId, status: { $ne: status.DELETE } });
            let commentReportList = await findAllReport({ userId: userResult._id, postId: postId });
            let [userCollection, collectionIdList] = await Promise.all([await userCollectionListAll({ userId: userResult._id, status: { $ne: status.DELETE } }), await collectionSubscriptionUserList({ userId: userResult._id, status: { $ne: status.DELETE } })]);
            if (!dataResults) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            for (let cObj of collectionIdList) {
                if (cObj['collectionId'].toString() == dataResults.collectionId) {
                    dataResults['isSubscribed'] = true;
                }
            }
            for (let uObj of userCollection) {
                if (uObj['_id'].toString() == dataResults.collectionId) {
                    dataResults['isSubscribed'] = true;
                }
            }
            for (let commentObject of commentReportList) {
                dataResults['comment'] = dataResults['comment'].filter(item => !item['reportedId'].includes(commentObject._id))
            }
            return res.json(new response(dataResults, responseMessage.DATA_FOUND));
        } catch (error) {
            return next(error);
        }
    }
    /**
    * @swagger
    * /user/allPostList:
    *   get:
    *     tags:
    *       - USER POSTS
    *     description: allPostList
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: token
    *         description: token
    *         in: header
    *         required: true
    *       - name: search
    *         description: search
    *         in: query
    *         required: false
    *       - name: fromDate
    *         description: fromDate
    *         in: query
    *         required: false
    *       - name: toDate
    *         description: toDate
    *         in: query
    *         required: false
    *       - name: page
    *         description: page
    *         in: query
    *         required: false
    *       - name: limit
    *         description: limit
    *         in: query
    *         required: false
    *     responses:
    *       200:
    *         description: Returns success message
    */
    async allPostList(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional()
        }
        try {
            const paginateGood = (array, page_size, page_number) => {
                return array.slice((page_number - 1) * page_size, page_number * page_size);
            };
            const validatedBody = await Joi.validate(req.query, validationSchema);
            const { search, fromDate, toDate, page, limit } = validatedBody;
            var userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            // let postPromotionResult = await postPromotionList({ status: status.ACTIVE })
            validatedBody['status'] = status.ACTIVE;
            validatedBody['postType'] = { $in: ['PRIVATE', 'PUBLIC'] };
            validatedBody['isSold'] = false;
            validatedBody['isBuy'] = false;
            let newDoc = [];
            // let data = await paginateAllPostSearchPrivatePublicFind(validatedBody);
            let [data, postPromotionResult, userCollection, collectionIdList] = await Promise.all([
                paginateAllPostSearchPrivatePublicFind(validatedBody),
                postPromotionList({ status: status.ACTIVE }),
                userCollectionListAll({ userId: userResult._id, status: { $ne: status.DELETE } }),
                collectionSubscriptionUserList({ userId: userResult._id, status: { $ne: status.DELETE } })]);

            let postPromotionRes = []
            for (let i = 0; i < postPromotionResult.length; i++) {
                if (!userResult.blockedUser.includes(postPromotionResult[i].userId._id)) {
                    postPromotionRes.push(postPromotionResult[i])
                }
            }

            let blockUserRes = []
            for (let i = 0; i < data.length; i++) {
                if (!userResult.blockedUser.includes(data[i].userId._id)) {
                    blockUserRes.push(data[i])
                }
            }

            let dataResults = []
            for (let i = 0; i < blockUserRes.length; i++) {
                if (!userResult.hidePost.includes(blockUserRes[i]._id)) {
                    dataResults.push(blockUserRes[i])
                }
            }
            for (let i in dataResults) {
                for (let cObj of collectionIdList) {
                    if (cObj['collectionId']['_id'].toString() == dataResults[i].collectionId) {
                        dataResults[i]['isSubscribed'] = true;
                    }
                }
                for (let uObj of userCollection) {
                    if (uObj['_id'].toString() == dataResults[i].collectionId) {
                        dataResults[i]['isSubscribed'] = true;
                    }
                }
                if (userResult['myWatchlist'].includes(dataResults[i]._id) == true) {
                    dataResults[i]['isWatchList'] = true;
                }
                dataResults[i].reactOnPost = await dataResults[i].reactOnPost.find(o => { return o.userId.toString() == userResult._id.toString() });

            }
            var finaldataRes = []
            for (let obj of dataResults) {
                let findReportRes = await findAllReport({ userId: userResult._id, postId: obj._id });
                if (findReportRes.length == 0) {
                    finaldataRes.push(obj)
                }
                else {
                    for (let commentObject of findReportRes) {
                        obj['comment'] = obj['comment'].filter(item => !item['reportedId'].includes(commentObject._id))
                    }
                    if (!obj.reportedId.includes(findReportRes[0]._id)) {
                        finaldataRes.push(obj);
                    }
                }
            }
            let resultRes = [];
            let count = 0;
            var userDob = new Date(userResult.dob);
            var currentDate = new Date();
            var diffDays = currentDate.getYear() - userDob.getYear();
            var postPromotionfinalResult = [];
            for (let i = 0; i < postPromotionRes.length; i++) {
                for (let j = 0; j < userResult.interest.length; j++) {
                    for (let x = 0; x < postPromotionRes[i].interest.length; x++) {
                        if (postPromotionRes[i].interest[x] == userResult.interest[j] && postPromotionRes[i].minAge <= diffDays && postPromotionRes[i].maxAge >= diffDays && (userResult._id).toString() != (postPromotionRes[i].userId._id).toString()) {
                            postPromotionfinalResult.push(postPromotionRes[i])
                        } else if ((userResult._id).toString() == (postPromotionRes[i].userId._id).toString()) {
                            postPromotionfinalResult.push(postPromotionRes[i])
                        }
                    }
                }
            }
            if (finaldataRes.length == 0) {
                for (let i = 0; i < postPromotionfinalResult.length; i++) {
                    resultRes.push(postPromotionfinalResult[i])
                }
            }
            for (let i = 0; i < finaldataRes.length; i++) {
                count++;
                resultRes.push(finaldataRes[i]);
                if (count % 2 == 0 && postPromotionfinalResult[count / 2 - 1] && resultRes.includes(postPromotionfinalResult[count / 2 - 1]) == false) {
                    resultRes.push(postPromotionfinalResult[count / 2 - 1]);
                }
            }
            let options2 = {
                page: parseInt(req.query.page) || 1,
                limit: parseInt(req.query.limit) || 10,
            }
            let properResult = {
                docs: paginateGood(resultRes, options2.limit, options2.page),
                total: resultRes.length,
                limit: options2.limit,
                page: options2.page,
                pages: Math.ceil(resultRes.length / options2.limit)
            }
            if (properResult.docs.length == 0) {
                throw apiError.notFound(responseMessage.POST_NOT_FOUND)
            }
            return res.json(new response(properResult, responseMessage.DATA_FOUND));
        } catch (error) {
            console.log('Catch error ==>', error)
            return next(error);
        }
    }



    /**
  * @swagger
  * /user/likeDislikeCollection/{collectionId}:
  *   get:
  *     tags:
  *       - USER
  *     description: likeDislikeCollection
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: token
  *         description: token
  *         in: header
  *         required: true
  *       - name: collectionId
  *         description: collectionId
  *         in: path
  *         required: true
  *     responses:
  *       200:
  *         description: Returns success message
  */
    async likeDislikeCollection(req, res, next) {
        const validationSchema = {
            collectionId: Joi.string().required(),
        }
        var updated;
        try {
            const { collectionId } = await Joi.validate(req.params, validationSchema);
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let collectionRes = await findCollection({ _id: collectionId, status: { $ne: status.DELETE } });
            if (!collectionRes) {
                throw apiError.notFound(responseMessage.COLLECTION_NOT_FOUND);
            }
            if (collectionRes.likesUsers.includes(userResult._id)) {
                updated = await updateCollection({ _id: collectionRes._id }, { $pull: { likesUsers: userResult._id }, $inc: { likesCount: -1 } });
                await updateUser({ _id: userResult._id }, { $pull: { likesCollection: collectionRes._id } });
                await createActivity({
                    userId: userResult._id,
                    collectionId: collectionRes._id,
                    title: "Dislike collection",
                    desctiption: "Bad choice, I disliked it.",
                    type: "DISLIKE"
                })
                return res.json(new response(updated, responseMessage.DISLIKES));
            } else {
                await createActivity({
                    userId: userResult._id,
                    collectionId: collectionRes._id,
                    title: "Like collection",
                    desctiption: "Nice choice, I liked it.",
                    type: "LIKE"
                })
                var name = userResult.name || userResult.userName
                let collectionResult = await findCollection({ _id: collectionId, userId: userResult._id })
                if (collectionResult) {
                    updated = await updateCollection({ _id: collectionRes._id }, { $addToSet: { likesUsers: userResult._id }, $inc: { likesCount: 1 } });
                    await updateUser({ _id: userResult._id }, { $addToSet: { likesCollection: collectionRes._id } });
                    return res.json(new response(updated, responseMessage.LIKES));
                }
                await notificationDeleteMany({ userId: collectionRes.userId, notificationType: "COLLECTION_LIKE", likeBy: userResult._id, collectionId: collectionRes._id })
                await createNotification({
                    title: `Like collection!`,
                    description: `${name} likes your collection.`,
                    userId: collectionRes.userId,
                    notificationType: "COLLECTION_LIKE",
                    likeBy: userResult._id,
                    collectionId: collectionRes._id
                });
                let userResDeviceToken = await findUser({ _id: collectionRes.userId })
                if (userResDeviceToken.deviceToken) {
                    let message = {
                        to: userResDeviceToken.deviceToken,
                        data: {
                            title: `Like collection!`,
                            body: `${name} likes your collection.`,
                            userId: collectionRes.userId,
                            notificationType: "COLLECTION_LIKE",
                            likeBy: userResult._id,
                            collectionId: collectionRes._id,
                            sound: 'default'
                        },
                        notification: {
                            title: `Like collection!`,
                            body: `${name} likes your collection.`,
                            sound: 'default'
                        }
                    };
                    await commonFunction.pushNotification(message)
                }
                updated = await updateCollection({ _id: collectionRes._id }, { $addToSet: { likesUsers: userResult._id }, $inc: { likesCount: 1 } });
                await updateUser({ _id: userResult._id }, { $addToSet: { likesCollection: collectionRes._id } });
                return res.json(new response(updated, responseMessage.LIKES));
            }
        }
        catch (error) {
            if (error == 'NotRegistered') {
                error = { message: 'Device token not registered on server.' }
            }
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/collectionSubscription:
     *   post:
     *     tags:
     *       - USER SUBSCRIPTION 
     *     description: collectionSubscription
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: collectionId
     *         description: collectionId
     *         in: formData
     *         required: false
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async collectionSubscription(req, res, next) {
        const validationSchema = {
            collectionId: Joi.string().required(),
        }
        try {
            const { collectionId } = await Joi.validate(req.body, validationSchema);
            var userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                let result = await findCollection({ _id: collectionId, userId: { $ne: userResult._id }, status: { $ne: status.DELETE } })
                if (!result) {
                    throw apiError.notFound(responseMessage.COLLECTION_NOT_FOUND)
                } else {
                    if (parseFloat(result.amount) >= parseFloat(userResult.bnbBalace)) {
                        throw apiError.badRequest(responseMessage.LOW_BALANCE)
                    } else {
                        let obj = {
                            userId: userResult._id,
                            collectionId: result._id,
                            duration: result.duration,
                            amount: result.amount,
                            subscriptionStatus: "SUBSCRIBE"
                        }
                        await updateCollection({ _id: result._id }, { $addToSet: { subscriptionUsers: userResult._id }, $inc: { subscriptionCount: 1 } });
                        let saveRes = await createCollectionSubscription(obj)
                        await createActivity({
                            userId: userResult._id,
                            collectionSubscriptionId: saveRes._id,
                            collectionId: result._id,
                            title: "Subscribe collection",
                            desctiption: "Thank for collection subscribe.",
                            type: "SUBSCRIBE"
                        })
                        await createActivity({
                            userId: result.userId,
                            collectionSubscriptionId: saveRes._id,
                            collectionSubscriptionUserId: userResult._id,
                            collectionId: result._id,
                            title: "Subscribe collection ",
                            desctiption: "Your collection Subscribe by user.",
                            type: "SUBSCRIBE"
                        })
                        let adminRes = await findUser({ userType: userType.ADMIN, status: { $ne: status.DELETE } })
                        let feeRes = await findFee({ type: "SUBCRIPTION", status: { $ne: status.DELETE } })
                        await updateUser({ _id: adminRes._id }, { bnbBalace: adminRes.bnbBalace + (parseFloat(feeRes.amount) * Number(result.amount)) / 100 })
                        let finalAmount = parseFloat(result.amount) - (parseFloat(feeRes.amount) * Number(result.amount)) / 100
                        await updateUser({ _id: userResult._id }, { bnbBalace: userResult.bnbBalace - Number(result.amount), subscriberCount: userResult.subscriberCount + 1 })
                        await updateUser({ _id: result.userId }, { $inc: { bnbBalace: + Number(finalAmount) } })
                        await createTransaction({
                            userId: result.userId,
                            subscriptionId: saveRes._id,
                            commission: (parseFloat(feeRes.amount) * Number(result.amount)) / 100,
                            amount: finalAmount,
                            transactionType: "COLLECTION_SUBSCRIBE_RECEIVE",
                        })
                        await createTransaction({
                            userId: userResult._id,
                            subscriptionId: saveRes._id,
                            amount: result.amount,
                            transactionType: "COLLECTION_SUBSCRIBE_SHARE",
                        })
                        await createTransaction({
                            userId: adminRes._id,
                            subscriptionId: saveRes._id,
                            amount: (parseFloat(feeRes.amount) * Number(result.amount)) / 100,
                            transactionType: "COLLECTION_SUBSCRIBE_RECEIVE_COMMISSION",
                        })
                        return res.json(new response(saveRes, responseMessage.SUBSCRIPTION_ADDED));
                    }
                }
            }
        } catch (error) {
            console.log(error)
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/collectionSubscriptionList:
     *   get:
     *     tags:
     *       - USER SUBSCRIPTION 
     *     description: collectionSubscriptionList
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async collectionSubscriptionList(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                let result = await collectionSubscriptionList({ userId: userResult._id, status: { $ne: status.DELETE } })
                if (result.length == 0) {
                    throw apiError.notFound(responseMessage.SUBSCRIPTION_NOT_FOUND)
                } else {
                    return res.json(new response(result, responseMessage.VIEW_PLAN));
                }
            }
        } catch (error) {
            return next(error);
        }
    }

    /**
    * @swagger
    * /user/collectionSubscriptionView:
    *   get:
    *     tags:
    *       - USER SUBSCRIPTION 
    *     description: collectionSubscriptionView
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: token
    *         description: token
    *         in: header
    *         required: true
    *       - name: subscriptionId
    *         description: subscriptionId
    *         in: query
    *         required: true
    *     responses:
    *       200:
    *         description: Returns success message
    */
    async collectionSubscriptionView(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                let result = await findCollectionSubscription({ _id: req.query.subscriptionId, userId: userResult._id, status: { $ne: status.DELETE } })
                if (!result) {
                    throw apiError.notFound(responseMessage.SUBSCRIPTION_NOT_FOUND)
                } else {
                    return res.json(new response(result, responseMessage.VIEW_PLAN));
                }
            }
        } catch (error) {
            return next(error);
        }
    }


    /**
  * @swagger
  * /user/likeDislikeSubscription/{subscriptionId}:
  *   get:
  *     tags:
  *       - USER SUBSCRIPTION
  *     description: likeDislikeSubscription
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: token
  *         description: token
  *         in: header
  *         required: true
  *       - name: subscriptionId
  *         description: subscriptionId
  *         in: path
  *         required: true
  *     responses:
  *       200:
  *         description: Returns success message
  */
    async likeDislikeSubscription(req, res, next) {
        const validationSchema = {
            subscriptionId: Joi.string().required(),
        }
        var updated;
        try {
            const { subscriptionId } = await Joi.validate(req.params, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let subscriptionRes = await findCollectionSubscription({ _id: subscriptionId, status: { $ne: status.DELETE } });
            if (!subscriptionRes) {
                throw apiError.notFound(responseMessage.SUBSCRIPTION_NOT_FOUND);
            }
            if (subscriptionRes.likesUsers.includes(userResult._id)) {
                updated = await updateCollectionSubscription({ _id: subscriptionRes._id }, { $pull: { likesUsers: userResult._id }, $inc: { likesCount: -1 } });
                await updateUser({ _id: userResult._id }, { $pull: { likesSubscription: subscriptionRes._id } });
                await createActivity({
                    userId: userResult._id,
                    collectionSubscriptionId: subscriptionRes._id,
                    title: "Dislike collection subscribe ",
                    desctiption: "Bad choice, I disliked it.",
                    type: "DISLIKE"
                })
                return res.json(new response(updated, responseMessage.DISLIKES));
            } else {
                await createActivity({
                    userId: userResult._id,
                    collectionSubscriptionId: subscriptionRes._id,
                    title: "Like collection subscribe",
                    desctiption: "Nice choice, I liked it.",
                    type: "LIKE"
                })
                var name = userResult.name || userResult.userName
                let subscriptionResult = await findCollectionSubscription({ _id: subscriptionId, userResult: userResult._id, status: { $ne: status.DELETE } });
                if (subscriptionResult) {
                    updated = await updateCollectionSubscription({ _id: subscriptionRes._id }, { $addToSet: { likesUsers: userResult._id }, $inc: { likesCount: 1 } });
                    await updateUser({ _id: userResult._id }, { $addToSet: { likesSubscription: subscriptionRes._id } });
                    return res.json(new response(updated, responseMessage.LIKES));
                }
                await notificationDeleteMany({ userId: subscriptionRes.userId, notificationType: "SUBCRIPTION_LIKE", likeBy: userResult._id, subscriptionId: subscriptionRes._id })
                await createNotification({
                    title: `Like collection subscribe!`,
                    description: `${name} likes your collection subscribe.`,
                    userId: subscriptionRes.userId,
                    notificationType: "SUBCRIPTION_LIKE",
                    likeBy: userResult._id,
                    subscriptionId: subscriptionRes._id
                });
                let userResDeviceToken = await findUser({ _id: subscriptionRes.userId })
                if (userResDeviceToken.deviceToken) {
                    let message = {
                        to: userResDeviceToken.deviceToken,
                        data: {
                            title: `Like collection subscribe!`,
                            body: `${name} likes your collection subscribe.`,
                            userId: subscriptionRes.userId,
                            notificationType: "SUBCRIPTION_LIKE",
                            likeBy: userResult._id,
                            subscriptionId: subscriptionRes._id,
                            sound: 'default'
                        },
                        notification: {
                            title: `Like collection subscribe!`,
                            body: `${name} likes your collection subscribe.`,
                            sound: 'default'
                        }
                    };
                    await commonFunction.pushNotification(message)
                }
                updated = await updateCollectionSubscription({ _id: subscriptionRes._id }, { $addToSet: { likesUsers: userResult._id }, $inc: { likesCount: 1 } });
                await updateUser({ _id: userResult._id }, { $addToSet: { likesSubscription: subscriptionRes._id } });
                return res.json(new response(updated, responseMessage.LIKES));
            }
        }
        catch (error) {
            if (error == 'NotRegistered') {
                error = { message: 'Device token not registered on server.' }
            }
            return next(error);
        }
    }

    /**
  * @swagger
  * /user/likeDislikePost/{postId}:
  *   get:
  *     tags:
  *       - USER POSTS
  *     description: likeDislikePost
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: token
  *         description: token
  *         in: header
  *         required: true
  *       - name: postId
  *         description: postId
  *         in: path
  *         required: true
  *     responses:
  *       200:
  *         description: Returns success message
  */
    async likeDislikePost(req, res, next) {
        const validationSchema = {
            postId: Joi.string().required(),
        }
        var updated;
        try {
            const { postId } = await Joi.validate(req.params, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                collectionPostId
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let postRes = await findOnePost({ _id: postId, status: { $ne: status.DELETE } });
            if (!postRes) {
                throw apiError.notFound(responseMessage.POST_NOT_EXIST);
            }
            if (postRes.likesUsers.includes(userResult._id)) {
                updated = await updatePost({ _id: postRes._id }, { $pull: { likesUsers: userResult._id }, $inc: { likesCount: -1 } });
                await updateUser({ _id: userResult._id }, { $pull: { likesPost: postRes._id } });
                await createActivity({
                    userId: userResult._id,
                    postId: postRes._id,
                    title: "Dislike post",
                    desctiption: "Bad choice, I disliked it.",
                    type: "DISLIKE"
                })
                return res.json(new response(updated, responseMessage.DISLIKES));
            } else {
                await createActivity({
                    userId: userResult._id,
                    postId: postRes._id,
                    title: "Like post",
                    desctiption: "Nice choice, I liked it.",
                    type: "LIKE"
                })
                var name = userResult.name || userResult.userName
                let postResult = await findOnePost({ _id: postId, $or: [{ userId: userResult._id }, { buyerId: userResult._id }], status: { $ne: status.DELETE } });
                if (postResult) {
                    updated = await updatePost({ _id: postRes._id }, { $addToSet: { likesUsers: userResult._id }, $inc: { likesCount: 1 } });
                    await updateUser({ _id: userResult._id }, { $addToSet: { likesPost: postRes._id } });
                    return res.json(new response(updated, responseMessage.LIKES));
                }
                await notificationDeleteMany({ userId: postRes.userId, notificationType: "POST_LIKE", likeBy: userResult._id, postId: postRes._id })
                await createNotification({
                    title: `Like post`,
                    description: `${name} likes your post.`,
                    userId: postRes.userId,
                    notificationType: "POST_LIKE",
                    likeBy: userResult._id,
                    postId: postRes._id
                });
                let userResDeviceToken = await findUser({ _id: postRes.userId })
                if (userResDeviceToken.deviceToken) {
                    let message = {
                        to: userResDeviceToken.deviceToken,
                        data: {
                            title: `Like post`,
                            body: `${name} likes your post.`,
                            userId: postRes.userId,
                            notificationType: "POST_LIKE",
                            likeBy: userResult._id,
                            postId: postRes._id,
                            sound: 'default'
                        },
                        notification: {
                            title: `Like post`,
                            body: `${name} likes your post.`,
                            sound: 'default'
                        }
                    };
                    await commonFunction.pushNotification(message)
                }
                updated = await updatePost({ _id: postRes._id }, { $addToSet: { likesUsers: userResult._id }, $inc: { likesCount: 1 } });
                await updateUser({ _id: userResult._id }, { $addToSet: { likesPost: postRes._id } });
                return res.json(new response(updated, responseMessage.LIKES));
            }
        }
        catch (error) {
            if (error == 'NotRegistered') {
                error = { message: 'Device token not registered on server.' }
            }
            return next(error);
        }
    }

    /**
    * @swagger
    * /user/reactOnPost/{postId}:
    *   get:
    *     tags:
    *       - USER POSTS
    *     description: reactOnPost
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: token
    *         description: token
    *         in: header
    *         required: true
    *       - name: postId
    *         description: postId
    *         in: path
    *         required: true
    *       - name: emoji
    *         description: emoji
    *         in: query
    *         required: true
    *     responses:
    *       200:
    *         description: Returns success message
    */
    async reactOnPost(req, res, next) {
        const validationSchema = {
            postId: Joi.string().required()
        }
        var updated;
        try {
            const { postId } = await Joi.validate(req.params, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                collectionPostId
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let postRes = await findOnePost({ _id: postId, status: { $ne: status.DELETE } });
            if (!postRes) {
                throw apiError.notFound(responseMessage.POST_NOT_EXIST);
            }
            if (postRes.reactOnPost.some(o => { return o.userId == userResult._id.toString() }) == true) {
                let update = await updatePost({ _id: postRes._id, 'reactOnPost.userId': userResult._id }, { 'reactOnPost.$.emoji': req.query.emoji });
                await createActivity({
                    userId: userResult._id,
                    postId: postRes._id,
                    title: "React On post",
                    desctiption: `React ${req.query.emoji} on post.`,
                    type: "LIKE"
                })
                return res.json(new response(update, responseMessage.EMOJI_REACT));
            }
            else {
                let add = await updatePost({ _id: postRes._id }, {
                    $addToSet: {
                        reactOnPost: {
                            userId: userResult._id,
                            emoji: req.query.emoji
                        }
                    }, $inc: { reactOnPostCount: +1 }
                });
                await createActivity({
                    userId: userResult._id,
                    postId: postRes._id,
                    title: "React On post",
                    desctiption: `React ${req.query.emoji} on post.`,
                    type: "LIKE"
                })
                return res.json(new response(add, responseMessage.EMOJI_REACT));
            }
        }
        catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/commentOnPost:
     *   post:
     *     tags:
     *       - USER POSTS
     *     description: commentOnPost
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: postId
     *         description: postId
     *         in: formData
     *         required: true
     *       - name: message
     *         description: message
     *         in: formData
     *         required: false
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async commentOnPost(req, res, next) {
        const validationSchema = {
            postId: Joi.string().required(),
            message: Joi.string().optional(),
        }
        try {
            let update;
            const validatedBody = await Joi.validate(req.body, validationSchema);
            const { postId, message } = validatedBody;
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let postCheck = await findOnePost({ _id: postId, status: { $ne: status.DELETE } })
            if (!postCheck) {
                throw apiError.notFound(responseMessage.POST_NOT_EXIST);
            } else {
                update = await updatePost({ _id: postCheck._id }, { $push: { comment: { userId: userResult._id, message: message, time: new Date().toISOString(), } } })
                update = await updatePost({ _id: postCheck._id }, { $inc: { totalComment: 1 } })
                await createActivity({
                    userId: userResult._id,
                    postId: postCheck._id,
                    title: "Post comment",
                    desctiption: `${userResult.userName} comment on this Post.`,
                    type: "COMMENT"
                })
                var name = userResult.name || userResult.userName
                let postResult = await findOnePost({ _id: postId, $or: [{ userId: userResult._id }, { buyerId: userResult._id }], status: { $ne: status.DELETE } });
                if (postResult) {
                    return res.json(new response(update, responseMessage.COMMENT_ADDED));
                }
                await notificationDeleteMany({ userId: postCheck.userId, notificationType: "POST_COMMENT", postId: postCheck._id, commentBy: userResult._id })
                let notificationObj = {
                    title: `Comment on post!`,
                    description: `${name} has comment on your post.`,
                    userId: postCheck.userId,
                    notificationType: "POST_COMMENT",
                    postId: postCheck._id,
                    commentBy: userResult._id
                }
                let userResDeviceToken = await findUser({ _id: postCheck.userId })
                if (userResDeviceToken.deviceToken) {
                    let message = {
                        to: userResDeviceToken.deviceToken,
                        data: {
                            title: `Comment on post!`,
                            body: `${name} has comment on your post.`,
                            userId: postCheck.userId,
                            notificationType: "POST_COMMENT",
                            postId: postCheck._id,
                            commentBy: userResult._id,
                            sound: 'default'
                        },
                        notification: {
                            title: `Comment on post!`,
                            body: `${name} has comment on your post.`,
                            sound: 'default'
                        }
                    };
                    await commonFunction.pushNotification(message)
                }
                await createNotification(notificationObj);
                return res.json(new response(update, responseMessage.COMMENT_ADDED));
            }


        } catch (error) {
            if (error == 'NotRegistered') {
                error = { message: 'Device token not registered on server.' }
            }
            return next(error);
        }

    }

    /**
     * @swagger
     * /user/deleteCommentOnPost:
     *   delete:
     *     tags:
     *       - USER POSTS
     *     description: commentOnPost
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: postId
     *         description: postId
     *         in: formData
     *         required: true
     *       - name: commentId
     *         description: commentId
     *         in: formData
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async deleteCommentOnPost(req, res, next) {
        const validationSchema = {
            postId: Joi.string().required(),
            commentId: Joi.string().required(),
        }
        try {
            let update;
            const validatedBody = await Joi.validate(req.body, validationSchema);
            const { postId, commentId } = validatedBody;
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let postCheck = await findOnePost({ _id: postId, 'comment._id': commentId, status: { $ne: status.DELETE } });
            if (!postCheck) {
                throw apiError.notFound(responseMessage.COMMENT_NOT_EXIST);
            } else {
                let deleteComment = await deletePostComment(validatedBody);
                return res.json(new response(deleteComment, responseMessage.COMMENT_DELETE_SUCCESS));
            }
        } catch (error) {
            return next(error);
        }
    }


    /**
     * @swagger
     * /user/commentReplyOnPost:
     *   post:
     *     tags:
     *       - USER POSTS
     *     description: commentReplyOnPost
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: postId
     *         description: postId
     *         in: formData
     *         required: true
     *       - name: commentId
     *         description: commentId
     *         in: formData
     *         required: true
     *       - name: message
     *         description: message
     *         in: formData
     *         required: false
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async commentReplyOnPost(req, res, next) {
        const validationSchema = {
            postId: Joi.string().required(),
            message: Joi.string().optional(),
            commentId: Joi.string().optional(),
        }
        try {
            let update;
            const validatedBody = await Joi.validate(req.body, validationSchema);
            const { postId, message, commentId } = validatedBody;
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let postCheck = await findOnePost({ _id: postId, status: { $ne: status.DELETE } })
            if (!postCheck) {
                throw apiError.notFound(responseMessage.POST_NOT_EXIST);
            } else {
                var name = userResult.name || userResult.userName
                let postResult = await findOnePost({ _id: postId, $or: [{ userId: userResult._id }, { buyerId: userResult._id }], status: { $ne: status.DELETE } });
                if (postResult) {
                    let obj = {
                        userId: userResult._id,
                        commentId: commentId,
                        message: message,
                        time: new Date().toISOString(),
                    }
                    update = await updatePost({ _id: postCheck._id, "comment._id": commentId }, { $push: { 'comment.$.reply': obj } })
                    update = await updatePost({ _id: postCheck._id, "comment._id": commentId }, { $inc: { "comment.$.totalReply": 1 } })
                    return res.json(new response(update, responseMessage.REPLY_COMMENT));
                }
                await notificationDeleteMany({ userId: postCheck.userId, notificationType: "POST_COMMENT", postId: postCheck._id, commentBy: userResult._id })
                let notificationObj = {
                    title: `Comment on post reply!`,
                    description: `${name} has comment on your post .`,
                    userId: postCheck.userId,
                    notificationType: "POST_COMMENT",
                    postId: postCheck._id,
                    commentBy: userResult._id
                }
                let userResDeviceToken = await findUser({ _id: postCheck.userId })
                if (userResDeviceToken.deviceToken) {
                    let message = {
                        to: userResDeviceToken.deviceToken,
                        data: {
                            title: `Comment reply on comment!`,
                            body: `${name} has comment on your comment.`,
                            userId: postCheck.userId,
                            notificationType: "POST_COMMENT",
                            postId: postCheck._id,
                            commentBy: userResult._id,
                            sound: 'default'
                        },
                        notification: {
                            title: `Comment reply on comment!`,
                            body: `${name} has comment on your comment.`,
                            sound: 'default'
                        }
                    };
                    await commonFunction.pushNotification(message);
                }
                await createNotification(notificationObj);
                let obj = {
                    userId: userResult._id,
                    commentId: commentId,
                    message: message,
                    time: new Date().toISOString(),
                }
                update = await updatePost({ _id: postCheck._id, "comment._id": commentId }, { $push: { 'comment.$.reply': obj } })
                update = await updatePost({ _id: postCheck._id, "comment._id": commentId }, { $inc: { "comment.$.totalReply": 1 } })
                await createActivity({
                    userId: userResult._id,
                    postId: postCheck._id,
                    title: "Post comment reply",
                    desctiption: `${userResult.userName} reply on your comment on this Post.`,
                    type: "COMMENT_REPLY"
                })

                return res.json(new response(update, responseMessage.REPLY_COMMENT));
            }
        } catch (error) {
            if (error == 'NotRegistered') {
                error = { message: 'Device token not registered on server.' }
            }
            return next(error);
        }
    }

    /**
         * @swagger
         * /user/deleteCommentReplyOnPost:
         *   delete:
         *     tags:
         *       - USER POSTS
         *     description: commentOnPost
         *     produces:
         *       - application/json
         *     parameters:
         *       - name: token
         *         description: token
         *         in: header
         *         required: true
         *       - name: postId
         *         description: postId
         *         in: formData
         *         required: true
         *       - name: commentId
         *         description: commentId
         *         in: formData
         *         required: true
         *       - name: commentReplyId
         *         description: commentReplyId
         *         in: formData
         *         required: true
         *     responses:
         *       200:
         *         description: Returns success message
         */
    async deleteCommentReplyOnPost(req, res, next) {
        const validationSchema = {
            postId: Joi.string().required(),
            commentId: Joi.string().required(),
            commentReplyId: Joi.string().required(),
        }
        try {
            let update;
            const validatedBody = await Joi.validate(req.body, validationSchema);
            const { postId, commentId, commentReplyId } = validatedBody;
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let postCheck = await findOnePost({ _id: postId, 'comment._id': commentId, 'comment.reply._id': commentReplyId, status: { $ne: status.DELETE } });
            if (!postCheck) {
                throw apiError.notFound(responseMessage.COMMENT_NOT_EXIST);
            } else {
                let deleteComment = await deletePostCommentReply(validatedBody);
                return res.json(new response(deleteComment, responseMessage.COMMENT_DELETE_SUCCESS));
            }
        } catch (error) {
            return next(error);
        }
    }



    /**
     * @swagger
     * /user/buyPost:
     *   post:
     *     tags:
     *       - USER POSTS
     *     description: buyPost
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token is required.
     *         in: header
     *         required: true
     *       - in: body
     *         name: buyPost 
     *         description: buyPost.
     *         schema:
     *           type: object
     *           required:
     *             - postId
     *           properties:
     *             postId:
     *               type: string
     *             description:
     *               type: string
     *     responses:
     *       200:
     *         description: Returns success message
     */

    async buyPost(req, res, next) {
        let validationSchema = {
            postId: Joi.string().required(),
            description: Joi.string().optional(),

        }
        try {
            let validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let orderRes = await findOnePost({ _id: validatedBody.postId, userId: { $ne: userResult._id }, isSold: false, status: { $ne: status.DELETE } })
            if (!orderRes) {
                throw apiError.notFound(responseMessage.POST_NOT_FOUND);
            } else {
                if (parseFloat(orderRes.amount) >= parseFloat(userResult.bnbBalace)) {
                    throw apiError.notFound(responseMessage.LOW_BALANCE)
                }
                validatedBody.buyerId = userResult._id;
                validatedBody.amount = orderRes.amount;
                validatedBody.creatorId = orderRes.userId;
                validatedBody.previousCreatorId = orderRes.userId;
                validatedBody.collectionId = orderRes.collectionId;
                validatedBody.mediaUrl = orderRes.mediaUrl;
                validatedBody.postTitle = orderRes.postTitle;
                validatedBody.details = orderRes.details;
                validatedBody.royality = orderRes.royality;
                validatedBody.isBuy = true;
                validatedBody.type = "POST";
                var buyResult = await createUserPost(validatedBody);
                let activityResult = {
                    buyerId: userResult._id,
                    postId: orderRes._id,
                    title: "Post buy",
                    desctiption: "Post buy successfully.",
                    type: "BUY"
                }
                await createActivity(activityResult)
            }
            let adminRes = await findUser({ userType: userType.ADMIN, status: { $ne: status.DELETE } })
            let feeRes = await findFee({ type: "POST", status: { $ne: status.DELETE } })
            await updateUser({ _id: adminRes._id }, { bnbBalace: adminRes.bnbBalace + (parseFloat(feeRes.amount) * Number(orderRes.amount)) / 100 })
            let finalAmount = parseFloat(orderRes.amount) - (parseFloat(feeRes.amount) * Number(orderRes.amount)) / 100
            await updatePost({ _id: orderRes._id }, { isSold: true })
            await updateUser({ _id: userResult._id }, { bnbBalace: userResult.bnbBalace - Number(orderRes.amount) })
            await updateUser({ _id: orderRes.userId }, { $inc: { bnbBalace: + Number(finalAmount) } })
            await createTransaction({
                userId: adminRes._id,
                postId: orderRes._id,
                amount: (parseFloat(feeRes.amount) * Number(orderRes.amount)) / 100,
                transactionType: "BUY_POST_RECEIVE_COMMISSION",
            })
            await createTransaction({
                userId: userResult._id,
                postId: orderRes._id,
                amount: orderRes.amount,
                transactionType: "BUY_POST",
            })
            await createTransaction({
                userId: orderRes.userId,
                postId: orderRes._id,
                commission: (parseFloat(feeRes.amount) * Number(orderRes.amount)) / 100,
                amount: finalAmount,
                transactionType: "SOLD_POST",
            })
            var name = userResult.name || userResult.userName
            await createNotification({
                title: `Buy post!`,
                description: `${name} buy your post.`,
                userId: orderRes.userId,
                notificationType: "BUY_POST",
                buyId: userResult._id,
                postId: orderRes._id
            });
            return res.json(new response(buyResult, responseMessage.BUY_SUCCESS));
        } catch (error) {

            return next(error)
        }
    }


    /**
   * @swagger
   * /user/transactionList:
   *   get:
   *     tags:
   *       - USER POSTS
   *     description: transactionList
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: token
   *         description: token
   *         in: header
   *         required: true
   *       - name: search
   *         description: search
   *         in: query
   *         required: false
   *       - name: fromDate
   *         description: fromDate
   *         in: query
   *         required: false
   *       - name: toDate
   *         description: toDate
   *         in: query
   *         required: false
   *       - name: page
   *         description: page
   *         in: query
   *         required: false
   *       - name: limit
   *         description: limit
   *         in: query
   *         required: false
   *       - name: transactionType
   *         description: transactionType
   *         enum: ["BUY_AUCTION","SOLD_AUCTION","BUY_POST","SOLD_POST","COLLECTION_SHARE_AMOUNT","COLLECTION_RECEIVE_AMOUNT","COLLECTION_SUBSCRIBE_RECEIVE_COMMISSION","COLLECTION_SUBSCRIBE_SHARE","COLLECTION_SUBSCRIBE_RECEIVE","DEPOSIT_FOR_ADMIN","DEPOSIT_FOR_USER","WITHDRAW_FOR_ADMIN","WITHDRAW_FOR_USER","AMOUNT_RECEIVED"]
   *         in: query
   *         required: false
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async transactionList(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional(),
            transactionType: Joi.string().optional(),
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            const { search, fromDate, toDate, page, limit } = validatedBody;
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            validatedBody.userId = userResult._id;
            let dataResults = await paginateTransactionSearch(validatedBody);
            if (dataResults.docs.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            return res.json(new response(dataResults, responseMessage.DATA_FOUND));
        } catch (error) {
            return next(error);
        }

    }

    /**
   * @swagger
   * /user/transactionView:
   *   get:
   *     tags:
   *       - USER POSTS
   *     description: transactionView
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: token
   *         description: token
   *         in: header
   *         required: true
   *       - name: transactionId
   *         description: transactionId
   *         in: query
   *         required: true
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async transactionView(req, res, next) {
        const validationSchema = {
            transactionId: Joi.string().required(),
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let dataResults = await findTransaction({ _id: validatedBody.transactionId, userId: userResult._id, status: { $ne: status.DELETE } });
            if (!dataResults) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            return res.json(new response(dataResults, responseMessage.DATA_FOUND));
        } catch (error) {
            return next(error);
        }

    }

    /**
    * @swagger
    * /user/listPostWithCollection:
    *   get:
    *     tags:
    *       - USER POSTS
    *     description: listPostWithCollection
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: token
    *         description: token
    *         in: header
    *         required: true
    *       - name: collectionId
    *         description: _id of collection
    *         in: query
    *         required: true
    *       - name: search
    *         description: search
    *         in: query
    *         required: false
    *       - name: fromDate
    *         description: fromDate
    *         in: query
    *         required: false
    *       - name: toDate
    *         description: toDate
    *         in: query
    *         required: false
    *       - name: page
    *         description: page
    *         in: query
    *         required: false
    *       - name: limit
    *         description: limit
    *         in: query
    *         required: false
    *     responses:
    *       200:
    *         description: Returns success message
    */
    async listPostWithCollection(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional(),
            collectionId: Joi.string().required(),
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            const { search, fromDate, toDate, page, limit, collectionId } = validatedBody;
            const paginateGood = (array, page_size, page_number) => {
                return array.slice((page_number - 1) * page_size, page_number * page_size);
            };
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            validatedBody['postType'] = { $in: ['PUBLIC', 'PRIVATE'] };
            validatedBody['status'] = status.ACTIVE;
            validatedBody['collectionId'] = mongoose.Types.ObjectId(collectionId);
            validatedBody['isSold'] = false;
            validatedBody['isBuy'] = false;
            let userCollectionCheck = await findCollection({ _id: collectionId, userId: userResult._id, status: { $ne: status.DELETE } })
            let subscribeCheck = await findCollectionSubscription({ collectionId: collectionId, userId: userResult._id, status: { $ne: status.DELETE } });
            let dataResults = await paginateAllPostSearchPrivatePublicFind(validatedBody);
            if (dataResults.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            for (let i in dataResults) {
                if (userCollectionCheck || subscribeCheck) {
                    dataResults[i]['isSubscribed'] = true;
                }
            }
            let finalData = []
            for (let i = 0; i < dataResults.length; i++) {
                if (!userResult.hidePost.includes(dataResults[i]._id)) {
                    finalData.push(dataResults[i])
                }
            }
            if (finalData.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            var finaldataRes = []
            for (let obj of finalData) {
                let findReportRes = await findAllReport({ userId: userResult._id, postId: obj._id });
                if (findReportRes.length == 0) {
                    finaldataRes.push(obj)
                }
                else {
                    for (let commentObject of findReportRes) {
                        obj['comment'] = obj['comment'].filter(item => !item['reportedId'].includes(commentObject._id))
                    }
                    if (!obj.reportedId.includes(findReportRes[0]._id)) {
                        finaldataRes.push(obj);
                    }
                }
            }
            if (finaldataRes.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            let options2 = {
                page: parseInt(req.query.page) || 1,
                limit: parseInt(req.query.limit) || 10,
            }
            let properResult = {
                docs: paginateGood(finaldataRes, options2.limit, options2.page),
                total: finaldataRes.length,
                limit: options2.limit,
                page: options2.page,
                pages: Math.ceil(finaldataRes.length / options2.limit)
            }
            if (properResult.docs.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            return res.json(new response(properResult, responseMessage.DATA_FOUND));
        } catch (error) {
            console.log('Catch error ==>', error)
            return next(error);
        }
    }

    /**
   * @swagger
   * /user/deletePost:
   *   delete:
   *     tags:
   *       - USER POSTS
   *     description: deletePost
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: token
   *         description: token
   *         in: header
   *         required: true
   *       - name: postId
   *         description: postId
   *         in: formData
   *         required: true
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async deletePost(req, res, next) {
        const validationSchema = {
            postId: Joi.string().required(),
        }
        try {
            let update;
            const { postId } = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let postRes = await findOnePost({ _id: postId, userId: userResult._id, status: { $ne: status.DELETE } });
            if (!postRes) {
                throw apiError.notFound(responseMessage.POST_NOT_EXIST);
            } else {
                update = await updatePost({ _id: postRes._id }, { $set: { status: status.DELETE } })
                return res.json(new response(update, responseMessage.POST_DELETE))

            }

        } catch (error) {
            return next(error);
        }
    }

    /**
   * @swagger
   * /user/buypostList:
   *   get:
   *     tags:
   *       - USER POSTS
   *     description: buypostList
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: token
   *         description: token
   *         in: header
   *         required: true
   *       - name: search
   *         description: search
   *         in: query
   *         required: false
   *       - name: fromDate
   *         description: fromDate
   *         in: query
   *         required: false
   *       - name: toDate
   *         description: toDate
   *         in: query
   *         required: false
   *       - name: page
   *         description: page
   *         in: query
   *         required: false
   *       - name: limit
   *         description: limit
   *         in: query
   *         required: false
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async buypostList(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional()
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            const { search, fromDate, toDate, page, limit } = validatedBody;
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            validatedBody.userId = userResult._id
            let dataResults = await paginatePostSearchBuy(validatedBody);
            if (dataResults.docs.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            return res.json(new response(dataResults, responseMessage.DATA_FOUND));
        } catch (error) {
            return next(error);
        }
    }


    /**
       * @swagger
       * /user/reCreatePost:
       *   post:
       *     tags:
       *       - USER POSTS 
       *     description: reCreatePost
       *     produces:
       *       - application/json
       *     parameters:
       *       - name: token
       *         description: token
       *         in: header
       *         required: true
       *       - name: postId
       *         description: _id of post
       *         in: formData
       *         required: true
       *       - name: postTitle
       *         description: postTitle
       *         in: formData
       *         required: true
       *       - name: mediaUrl
       *         description: mediaUrl
       *         in: formData
       *         required: true
       *       - name: details
       *         description: details
       *         in: formData
       *         required: true
       *       - name: amount
       *         description: amount
       *         in: formData
       *         required: true
       *       - name: postType
       *         description: postType
       *         enum: [PRIVATE,PUBLIC]
       *         in: formData
       *         required: true
       *     responses:
       *       200:
       *         description: Returns success message
       */
    async reCreatePost(req, res, next) {
        try {
            const validationSchema = {
                postId: Joi.string().required(),
                postTitle: Joi.string().required(),
                mediaUrl: Joi.string().required(),
                details: Joi.string().required(),
                postType: Joi.string().required(),
                amount: Joi.string().required(),
            }
            const validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                let result = await findOnePost({ _id: validatedBody.postId, buyerId: userResult._id, isBuy: true, status: { $ne: status.DELETE } })
                if (!result) {
                    throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
                } else {
                    if (validatedBody.mediaUrl) {
                        validatedBody.mediaUrl = await commonFunction.getSecureUrl(validatedBody.mediaUrl);
                    }
                    validatedBody.type = "POST"
                    validatedBody.userId = userResult._id;
                    validatedBody.collectionId = result.collectionId;
                    let savePost = await createUserPost(validatedBody)
                    await createActivity({
                        userId: userResult._id,
                        postId: savePost._id,
                        title: "Recreate post",
                        desctiption: "Thanks for reCreate post.",
                        type: "POST"
                    })
                    await createActivity({
                        userId: result.userId,
                        postId: savePost._id,
                        collectionPostUserId: userResult._id,
                        title: "Recreate post",
                        desctiption: "Your post by user.",
                        type: "POST"
                    })
                    return res.json(new response(savePost, responseMessage.POST_CREATE));
                }
            }
        } catch (error) {
            console.log("====================>", error)
            return next(error);
        }
    }

    /**
    * @swagger
    * /user/collectionUnsubscription:
    *   put:
    *     tags:
    *       - USER SUBSCRIPTION 
    *     description: collectionUnsubscription
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: token
    *         description: token
    *         in: header
    *         required: true
    *       - name: subscriptionId
    *         description: subscriptionId
    *         in: query
    *         required: true
    *     responses:
    *       200:
    *         description: Returns success message
    */
    async collectionUnsubscription(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                let result = await findCollectionSubscription({ _id: req.query.subscriptionId, userId: userResult._id, status: { $ne: status.DELETE } })
                if (!result) {
                    throw apiError.notFound(responseMessage.SUBSCRIPTION_NOT_FOUND)
                } else {
                    let updateRes = await updateCollectionSubscription({ _id: result._id }, { subscriptionStatus: "UNSUBSCRIBE" })
                    return res.json(new response(updateRes, responseMessage.UNSUBSCRIBED));
                }
            }
        } catch (error) {
            return next(error);
        }
    }



    /**
     * @swagger
     * /user/addAuction:
     *   post:
     *     tags:
     *       - AUCTIONS 
     *     description: addAuction
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: postId
     *         description: _id of postId
     *         in: formData
     *         required: true
     *       - name: title
     *         description: title
     *         in: formData
     *         required: true
     *       - name: mediaUrl
     *         description: mediaUrl
     *         in: formData
     *         required: true
     *       - name: details
     *         description: details
     *         in: formData
     *         required: true
     *       - name: amount
     *         description: amount
     *         in: formData
     *         required: true
     *       - name: time
     *         description: time
     *         in: formData
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async addAuction(req, res, next) {
        try {
            const validationSchema = {
                postId: Joi.string().required(),
                title: Joi.string().required(),
                mediaUrl: Joi.string().required(),
                details: Joi.string().required(),
                amount: Joi.string().required(),
                time: Joi.string().required(),
            }
            const validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                let result = await findOnePost({ _id: validatedBody.postId, $or: [{ userId: userResult._id }, { buyerId: userResult._id }], status: { $ne: status.DELETE } })
                if (!result) {
                    throw apiError.notFound(responseMessage.POST_NOT_FOUND)
                } else {
                    if (validatedBody.mediaUrl) {
                        validatedBody.mediaUrl = await commonFunction.getSecureUrl(validatedBody.mediaUrl);
                    }
                    validatedBody.userId = userResult._id;
                    let savePost = await createAuctionNft(validatedBody)
                    await createActivity({
                        userId: userResult._id,
                        auctionNftId: savePost._id,
                        title: "Auction post",
                        desctiption: "Auction created successfully.",
                        type: "AUCTION"
                    })
                    await updatePost({ _id: result._id }, { isauction: true })
                    return res.json(new response(savePost, responseMessage.AUCTION_CREATE));
                }
            }
        } catch (error) {
            console.log("====================>", error)
            return next(error);
        }
    }

    /**
   * @swagger
   * /user/listAuction:
   *   get:
   *     tags:
   *       - AUCTIONS
   *     description: listAuction
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: token
   *         description: token
   *         in: header
   *         required: true
   *       - name: search
   *         description: search
   *         in: query
   *         required: false
   *       - name: fromDate
   *         description: fromDate
   *         in: query
   *         required: false
   *       - name: toDate
   *         description: toDate
   *         in: query
   *         required: false
   *       - name: page
   *         description: page
   *         in: query
   *         required: false
   *       - name: limit
   *         description: limit
   *         in: query
   *         required: false
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async listAuction(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional()
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            const { search, fromDate, toDate, page, limit } = validatedBody;
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let dataResults = await allNftAuctionList(validatedBody);
            if (dataResults.docs.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            return res.json(new response(dataResults, responseMessage.DATA_FOUND));
        } catch (error) {
            return next(error);
        }
    }

    /**
   * @swagger
   * /user/viewAuction:
   *   get:
   *     tags:
   *       - AUCTIONS
   *     description: viewAuction
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: token
   *         description: token
   *         in: header
   *         required: true
   *       - name: auctionId
   *         description: auctionId
   *         in: query
   *         required: true
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async viewAuction(req, res, next) {
        const validationSchema = {
            auctionId: Joi.string().required(),
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let dataResults = await findAuctionNft({ _id: validatedBody.auctionId, status: { $ne: status.DELETE } });
            if (!dataResults) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            return res.json(new response(dataResults, responseMessage.DATA_FOUND));
        } catch (error) {
            return next(error);
        }
    }


    /**
 * @swagger
 * /user/deleteAuction:
 *   delete:
 *     tags:
 *       - AUCTIONS
 *     description: deleteAuction
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: token
 *         description: token
 *         in: header
 *         required: true
 *       - name: auctionId
 *         description: auctionId
 *         in: query
 *         required: true
 *     responses:
 *       200:
 *         description: Returns success message
 */
    async deleteAuction(req, res, next) {
        const validationSchema = {
            auctionId: Joi.string().required(),
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let dataResults = await findAuctionNft({ _id: validatedBody.auctionId, status: { $ne: status.DELETE } });
            if (!dataResults) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            await updatePost({ _id: dataResults.postId }, { isauction: false })
            let updateRes = await updateAuctionNft({ _id: dataResults._id }, { status: status.DELETE })
            return res.json(new response(updateRes, responseMessage.AUCTION_DELETE_SUCCESS));
        } catch (error) {
            return next(error);
        }
    }

    /**
 * @swagger
 * /user/cancelAuction:
 *   delete:
 *     tags:
 *       - AUCTIONS
 *     description: cancelAuction
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: token
 *         description: token
 *         in: header
 *         required: true
 *       - name: auctionId
 *         description: auctionId
 *         in: query
 *         required: true
 *     responses:
 *       200:
 *         description: Returns success message
 */
    async cancelAuction(req, res, next) {
        const validationSchema = {
            auctionId: Joi.string().required(),
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let dataResults = await findAuctionNft({ _id: validatedBody.auctionId, status: { $ne: status.DELETE } });
            if (!dataResults) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            await updatePost({ _id: dataResults.postId }, { isauction: false })
            let updateRes = await updateAuctionNft({ _id: dataResults._id }, { auctionStatus: "STOPPED" })
            return res.json(new response(updateRes, responseMessage.AUCTION_CANCEL));
        } catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/updateAuction:
     *   put:
     *     tags:
     *       - AUCTIONS 
     *     description: updateAuction
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: auctionId
     *         description: _id of auctionId
     *         in: formData
     *         required: true
     *       - name: title
     *         description: title
     *         in: formData
     *         required: false
     *       - name: mediaUrl
     *         description: mediaUrl
     *         in: formData
     *         required: false
     *       - name: details
     *         description: details
     *         in: formData
     *         required: false
     *       - name: amount
     *         description: amount
     *         in: formData
     *         required: false
     *       - name: time
     *         description: time
     *         in: formData
     *         required: false
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async updateAuction(req, res, next) {
        try {
            const validationSchema = {
                auctionId: Joi.string().required(),
                title: Joi.string().optional(),
                mediaUrl: Joi.string().optional(),
                details: Joi.string().optional(),
                amount: Joi.string().optional(),
                time: Joi.string().optional(),
            }
            const validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                let result = await findAuctionNft({ _id: validatedBody.auctionId, userId: userResult._id, status: { $ne: status.DELETE } })
                if (!result) {
                    throw apiError.notFound(responseMessage.POST_NOT_FOUND)
                } else {
                    if (validatedBody.mediaUrl) {
                        validatedBody.mediaUrl = await commonFunction.getSecureUrl(validatedBody.mediaUrl);
                    }
                    let updateRes = await updateAuctionNft({ _id: result._id }, validatedBody)
                    return res.json(new response(updateRes, responseMessage.AUCTION_UPDATE));
                }
            }
        } catch (error) {
            console.log("====================>", error)
            return next(error);
        }
    }

    /**
   * @swagger
   * /user/mylistAuction:
   *   get:
   *     tags:
   *       - AUCTIONS
   *     description: mylistAuction
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: token
   *         description: token
   *         in: header
   *         required: true
   *       - name: search
   *         description: search
   *         in: query
   *         required: false
   *       - name: fromDate
   *         description: fromDate
   *         in: query
   *         required: false
   *       - name: toDate
   *         description: toDate
   *         in: query
   *         required: false
   *       - name: page
   *         description: page
   *         in: query
   *         required: false
   *       - name: limit
   *         description: limit
   *         in: query
   *         required: false
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async mylistAuction(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional()
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            const { search, fromDate, toDate, page, limit } = validatedBody;
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            validatedBody.userId = userResult._id;
            let dataResults = await allmyNftAuctionList(validatedBody);
            if (dataResults.docs.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            return res.json(new response(dataResults, responseMessage.DATA_FOUND));
        } catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/buyAuction:
     *   post:
     *     tags:
     *       - AUCTIONS
     *     description: buyAuction
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token is required.
     *         in: header
     *         required: true
     *       - in: body
     *         name: buyAuction 
     *         description: buyAuction.
     *         schema:
     *           type: object
     *           required:
     *             - auctionId
     *           properties:
     *             auctionId:
     *               type: string
     *     responses:
     *       200:
     *         description: Returns success message
     */

    async buyAuction(req, res, next) {
        let validationSchema = {
            auctionId: Joi.string().required(),
        }
        try {
            let validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound([], responseMessage.USER_NOT_FOUND);
            }
            let auctionRes = await findAuctionNft({ _id: validatedBody.auctionId, userId: { $ne: userResult._id }, isSold: false, status: { $ne: status.DELETE } })
            if (!auctionRes) {
                throw apiError.notFound([], responseMessage.DATA_NOT_FOUND);
            } else {
                let postRes = await findOnePost({ _id: auctionRes.postId })
                if (parseFloat(auctionRes.amount) >= parseFloat(userResult.bnbBalace)) {
                    throw apiError.notFound(responseMessage.LOW_BALANCE)
                }
                // console.log("======postRes===",postRes.royality)
                let postObj = {
                    buyerId: userResult._id,
                    amount: auctionRes.amount,
                    creatorId: postRes.creatorId,
                    previousCreatorId: postRes.buyerId,
                    collectionId: postRes.collectionId,
                    mediaUrl: postRes.mediaUrl,
                    postTitle: postRes.postTitle,
                    details: postRes.details,
                    royality: postRes.royality,
                    isBuy: true,
                    type: "POST"
                }
                var savePost = await createUserPost(postObj)
                validatedBody.buyerId = userResult._id;
                validatedBody.amount = auctionRes.amount;
                validatedBody.creatorId = auctionRes.userId;
                validatedBody.postId = savePost._id;
                validatedBody.mediaUrl = auctionRes.mediaUrl;
                validatedBody.title = auctionRes.title;
                validatedBody.details = auctionRes.details;
                validatedBody.isBuy = true;
                var buyResult = await createAuctionNft(validatedBody);
                let activityResult = {
                    buyerId: userResult._id,
                    auctionNftId: auctionRes._id,
                    title: "Auction buy",
                    desctiption: "Auction buy successfully.",
                    type: "BUY"
                }
                await createActivity(activityResult)
                let adminRes = await findUser({ userType: userType.ADMIN, status: { $ne: status.DELETE } })
                let feeRes = await findFee({ type: "AUCTION", status: { $ne: status.DELETE } })
                await updateUser({ _id: adminRes._id }, { bnbBalace: adminRes.bnbBalace + (parseFloat(feeRes.amount) * Number(auctionRes.amount)) / 100 })
                let finalAmount = parseFloat(auctionRes.amount) - (parseFloat(feeRes.amount) * Number(auctionRes.amount)) / 100

                let royalityResult = (parseFloat(postRes.royality) * Number(finalAmount)) / 100
                let secondCreatorAmount = parseFloat(finalAmount) - parseFloat(royalityResult)


                await updateAuctionNft({ _id: auctionRes._id }, { isSold: true })
                await updatePost({ _id: auctionRes.postId }, { isSold: true })
                await updateUser({ _id: userResult._id }, { bnbBalace: userResult.bnbBalace - Number(auctionRes.amount) })
                await updateUser({ _id: auctionRes.userId }, { $inc: { bnbBalace: + Number(secondCreatorAmount) } })  // resale owner

                await updateUser({ _id: postRes.creatorId }, { $inc: { bnbBalace: +Number(royalityResult) } }) //first creator

                await createTransaction({
                    userId: adminRes._id,
                    acutionId: auctionRes._id,
                    amount: (parseFloat(feeRes.amount) * Number(auctionRes.amount)) / 100,
                    transactionType: "BUY_AUCTION_RECEIVE_COMMISSION",
                })
                await createTransaction({
                    userId: userResult._id,
                    acutionId: auctionRes._id,
                    amount: auctionRes.amount,
                    transactionType: "BUY_AUCTION",
                })
                await createTransaction({
                    userId: auctionRes.userId,
                    acutionId: auctionRes._id,
                    commission: (parseFloat(feeRes.amount) * Number(auctionRes.amount)) / 100,
                    amount: finalAmount,
                    transactionType: "SOLD_AUCTION",
                })
                var name = userResult.name || userResult.userName
                await createNotification({
                    title: `Buy auction!`,
                    description: `${name} buy your auction.`,
                    userId: auctionRes.userId,
                    notificationType: "BUY_AUCTION",
                    buyId: userResult._id,
                    auctionId: auctionRes._id
                });
                return res.json(new response(buyResult, responseMessage.BUY_SUCCESS));
            }
        } catch (error) {
            console.log(error)
            return next(error)
        }
    }

    /**
   * @swagger
   * /user/notificationUpdate:
   *   put:
   *     tags:
   *       - USER
   *     description: notificationUpdate
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: token
   *         description: token
   *         in: header
   *         required: true
   *       - name: like
   *         description: like
   *         in: formData
   *         type: boolean
   *         default: true
   *         required: false
   *       - name: comment
   *         description: comment
   *         in: formData
   *         type: boolean
   *         default: true
   *         required: false
   *       - name: mention
   *         description: mention
   *         in: formData
   *         type: boolean
   *         default: true
   *         required: false
   *       - name: post
   *         description: post
   *         in: formData
   *         type: boolean
   *         default: true
   *         required: false
   *       - name: share
   *         description: share
   *         in: formData
   *         type: boolean
   *         default: true
   *         required: false
   *       - name: follow
   *         description: follow
   *         in: formData
   *         type: boolean
   *         default: true
   *         required: false
   *       - name: event
   *         description: event
   *         in: formData
   *         type: boolean
   *         default: true
   *         required: false
   *       - name: collection
   *         description: collection
   *         in: formData
   *         type: boolean
   *         default: true
   *         required: false
   *       - name: subscribe
   *         description: subscribe
   *         in: formData
   *         type: boolean
   *         default: true
   *         required: false
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async notificationUpdate(req, res, next) {
        const validationSchema = {
            like: Joi.string().optional(),
            comment: Joi.string().optional(),
            mention: Joi.string().optional(),
            post: Joi.string().optional(),
            share: Joi.string().optional(),
            follow: Joi.string().optional(),
            event: Joi.string().optional(),
            collection: Joi.string().optional(),
            subscribe: Joi.string().optional(),
        }
        try {
            const validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let obj = {
                notifications: {
                    like: validatedBody.like,
                    comment: validatedBody.comment,
                    mention: validatedBody.mention,
                    post: validatedBody.post,
                    share: validatedBody.share,
                    follow: validatedBody.follow,
                    event: validatedBody.event,
                    collection: validatedBody.collection,
                    subscribe: validatedBody.subscribe,
                }
            }
            let updateRes = await updateUser({ _id: userResult._id }, obj)
            return res.json(new response(updateRes, responseMessage.NOTIFICATION_SET));
        } catch (error) {
            return next(error);
        }
    }


    /**
   * @swagger
   * /user/buyAuctionList:
   *   get:
   *     tags:
   *       - AUCTIONS
   *     description: buyAuctionList
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: token
   *         description: token
   *         in: header
   *         required: true
   *       - name: search
   *         description: search
   *         in: query
   *         required: false
   *       - name: fromDate
   *         description: fromDate
   *         in: query
   *         required: false
   *       - name: toDate
   *         description: toDate
   *         in: query
   *         required: false
   *       - name: page
   *         description: page
   *         in: query
   *         required: false
   *       - name: limit
   *         description: limit
   *         in: query
   *         required: false
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async buyAuctionList(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional()
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: status.ACTIVE });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            validatedBody.userId = userResult._id
            let dataResults = await allmyNftAuctionListBuy(validatedBody);
            if (dataResults.docs.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            return res.json(new response(dataResults, responseMessage.DATA_FOUND));
        } catch (error) {
            return next(error);
        }
    }



    /**
  * @swagger
  * /user/likeDislikeAuction/{auctionId}:
  *   get:
  *     tags:
  *       - AUCTIONS
  *     description: likeDislikeAuction
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: token
  *         description: token
  *         in: header
  *         required: true
  *       - name: auctionId
  *         description: auctionId
  *         in: path
  *         required: true
  *     responses:
  *       200:
  *         description: Returns success message
  */
    async likeDislikeAuction(req, res, next) {
        const validationSchema = {
            auctionId: Joi.string().required(),
        }
        var updated;
        try {
            const { auctionId } = await Joi.validate(req.params, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let postRes = await findAuctionNft({ _id: auctionId, status: { $ne: status.DELETE } });
            if (!postRes) {
                throw apiError.notFound(responseMessage.ACUTION_NOT_FOUND);
            }
            if (postRes.likesUsers.includes(userResult._id)) {
                updated = await updateAuctionNft({ _id: postRes._id }, { $pull: { likesUsers: userResult._id }, $inc: { likesCount: -1 } });
                await updateUser({ _id: userResult._id }, { $pull: { likesAuction: postRes._id } });
                await createActivity({
                    userId: userResult._id,
                    auctionId: postRes._id,
                    title: "Dislike auction",
                    desctiption: "Bad choice, I disliked it.",
                    type: "DISLIKE"
                })
                return res.json(new response(updated, responseMessage.DISLIKES));
            } else {
                await createActivity({
                    userId: userResult._id,
                    auctionId: postRes._id,
                    title: "Like auction",
                    desctiption: "Nice choice, I liked it.",
                    type: "LIKE"
                })
                var name = userResult.name || userResult.userName
                let postResult = await findAuctionNft({ _id: auctionId, $or: [{ userId: userResult._id }, { buyerId: userResult._id }], status: { $ne: status.DELETE } });
                if (postResult) {
                    updated = await updateAuctionNft({ _id: postRes._id }, { $addToSet: { likesUsers: userResult._id }, $inc: { likesCount: 1 } });
                    await updateUser({ _id: userResult._id }, { $addToSet: { likesAuction: postRes._id } });
                    return res.json(new response(updated, responseMessage.LIKES));
                }
                await notificationDeleteMany({ userId: postRes.userId, notificationType: "LIKE_AUCTION", likeBy: userResult._id, auctionId: postRes._id })
                await createNotification({
                    title: `Like auction!`,
                    description: `${name} likes your auction.`,
                    userId: postRes.userId,
                    notificationType: "LIKE_AUCTION",
                    likeBy: userResult._id,
                    auctionId: postRes._id
                });
                let userResDeviceToken = await findUser({ _id: postRes.userId })
                if (userResDeviceToken.deviceToken) {
                    let message = {
                        to: userResDeviceToken.deviceToken,
                        data: {
                            title: `Like auction!`,
                            body: `${name} likes your auction.`,
                            userId: postRes.userId,
                            notificationType: "LIKE_AUCTION",
                            likeBy: userResult._id,
                            auctionId: postRes._id,
                            sound: 'default'
                        },
                        notification: {
                            title: `Like auction!`,
                            body: `${name} likes your auction.`,
                            sound: 'default'
                        }
                    };
                    await commonFunction.pushNotification(message)
                }
                updated = await updateAuctionNft({ _id: postRes._id }, { $addToSet: { likesUsers: userResult._id }, $inc: { likesCount: 1 } });
                await updateUser({ _id: userResult._id }, { $addToSet: { likesAuction: postRes._id } });
                return res.json(new response(updated, responseMessage.LIKES));
            }
        }
        catch (error) {
            if (error == 'NotRegistered') {
                error = { message: 'Device token not registered on server.' }
            }
            return next(error);
        }
    }


    /**
   * @swagger
   * /user/hide_unhideAuction:
   *   put:
   *     tags:
   *       - AUCTIONS
   *     description: hide_unhideAuction
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: token
   *         description: token
   *         in: header
   *         required: true
   *       - name: auctionId
   *         description: auctionId
   *         in: formData
   *         required: true
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async hide_unhideAuction(req, res, next) {
        const validationSchema = {
            auctionId: Joi.string().required(),
        }
        try {
            let update;
            const { auctionId } = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let auctionRes = await findAuctionNft({ _id: auctionId, userId: userResult._id, status: { $ne: status.DELETE } });
            if (!auctionRes) {
                throw apiError.notFound(responseMessage.POST_NOT_EXIST);
            } else {
                if (auctionRes.status == "ACTIVE") {
                    update = await updateAuctionNft({ _id: auctionRes._id }, { $set: { status: status.BLOCK } })
                    await createActivity({
                        userId: userResult._id,
                        postId: auctionRes._id,
                        title: "Auction hide",
                        desctiption: "User change his auction status.",
                        type: "HIDE"
                    })
                } else {
                    update = await updateAuctionNft({ _id: auctionRes._id }, { $set: { status: status.ACTIVE } })
                    await createActivity({
                        userId: userResult._id,
                        postId: auctionRes._id,
                        title: "Auction unhide",
                        desctiption: "User change his auction status.",
                        type: "UNHIDE"
                    })

                }
                return res.json(new response(update, responseMessage.STAUS_CHANGED));

            }

        } catch (error) {
            return next(error);
        }
    }


    /**
  * @swagger
  * /user/likeDislikeCommentOnPost:
  *   get:
  *     tags:
  *       - USER POSTS
  *     description: likeDislikeCommentOnPost
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: token
  *         description: token
  *         in: header
  *         required: true
  *       - name: postId
  *         description: postId
  *         in: query
  *         required: true
  *       - name: commentId 
  *         description: commentId ? _id
  *         in: query
  *         required: true
  *     responses:
  *       200:
  *         description: Returns success message
  */
    async likeDislikeCommentOnPost(req, res, next) {
        const validationSchema = {
            commentId: Joi.string().required(),
            postId: Joi.string().required(),
        }
        var updated;
        try {
            const { commentId, postId } = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let postRes = await findOnePost({ _id: postId, "comment._id": commentId, status: { $ne: status.DELETE } });
            if (!postRes) {
                throw apiError.notFound(responseMessage.POST_NOT_FOUND);
            }
            for (let i in postRes.comment) {
                if (postRes.comment[i]._id == commentId) {
                    if (postRes.comment[i].likesUsers.includes(userResult._id) == true) {
                        updated = await updatePost({ _id: postRes._id, "comment._id": commentId }, { $pull: { 'comment.$.likesUsers': userResult._id }, $inc: { 'comment.$.likesCount': -1 } });
                        await updateUser({ _id: userResult._id }, { $pull: { likesCommentOnPostId: commentId } });
                        return res.json(new response(updated, responseMessage.DISLIKES));
                    } else {
                        var name = userResult.name || userResult.userName
                        let postResult = await findOnePost({ _id: postId, $or: [{ userId: userResult._id }, { buyerId: userResult._id }] })
                        if (postResult) {
                            updated = await updatePost({ _id: postRes._id, "comment._id": commentId }, { $addToSet: { 'comment.$.likesUsers': userResult._id }, $inc: { 'comment.$.likesCount': 1 } });
                            await updateUser({ _id: userResult._id }, { $addToSet: { likesCommentOnPostId: commentId } });
                            return res.json(new response(updated, responseMessage.LIKES));
                        }
                        await notificationDeleteMany({ userId: postRes.userId, notificationType: "POST_LIKE", likeBy: userResult._id, postId: postRes._id })
                        await createNotification({
                            title: `Like comment on post! `,
                            description: `${name} likes your post.`,
                            userId: postRes.userId,
                            notificationType: "POST_LIKE",
                            likeBy: userResult._id,
                            postId: postRes._id
                        });
                        let userResDeviceToken = await findUser({ _id: postRes.userId })
                        if (userResDeviceToken.deviceToken) {
                            let message = {
                                to: userResDeviceToken.deviceToken,
                                data: {
                                    title: `Like comment on post! `,
                                    body: `${name} likes your post.`,
                                    userId: postRes.userId,
                                    notificationType: "POST_LIKE",
                                    likeBy: userResult._id,
                                    postId: postRes._id,
                                    sound: 'default'
                                },
                                notification: {
                                    title: `Like comment on post! `,
                                    body: `${name} likes your post.`,
                                    sound: 'default'
                                }
                            };
                            await commonFunction.pushNotification(message)
                        }
                        updated = await updatePost({ _id: postRes._id, "comment._id": commentId }, { $addToSet: { 'comment.$.likesUsers': userResult._id }, $inc: { 'comment.$.likesCount': 1 } });
                        await updateUser({ _id: userResult._id }, { $addToSet: { likesCommentOnPostId: commentId } });
                        return res.json(new response(updated, responseMessage.LIKES));
                    }
                }
            }

        }
        catch (error) {
            console.log(error)
            if (error == 'NotRegistered') {
                error = { message: 'Device token not registered on server.' }
            }
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/globalSearch:
     *   get:
     *     tags:
     *       - USER
     *     description: globalSearch
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: search
     *         description: search
     *         in: query
     *         required: false
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async globalSearch(req, res, next) {
        try {
            if (req.query.search == 'null') {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            }
            let [userList, collectionList, nftAuctionDataList, postList, hashtagList] = await Promise.all([await userFindList(req.query), await collectionSearchList(req.query), await nftAuctionList(req.query), await allPostList(req.query), await paginateHashTagSearch(req.query)]);
            let searchresult = {
                user: userList,
                collection: collectionList,
                post: postList,
                auctions: nftAuctionDataList,
                hashTagWithPost: hashtagList,
            };
            return res.json(new response(searchresult, responseMessage.DATA_FOUND));
        } catch (error) {
            return next(error)
        }
    }


    /**
    * @swagger
    * /user/listUserWithpost:
    *   get:
    *     tags:
    *       - USER POSTS
    *     description: listUserWithpost
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: token
    *         description: token
    *         in: header
    *         required: true
    *       - name: userId
    *         description: _id of userId
    *         in: query
    *         required: true
    *       - name: search
    *         description: search
    *         in: query
    *         required: false
    *       - name: fromDate
    *         description: fromDate
    *         in: query
    *         required: false
    *       - name: toDate
    *         description: toDate
    *         in: query
    *         required: false
    *       - name: page
    *         description: page
    *         in: query
    *         required: false
    *       - name: limit
    *         description: limit
    *         in: query
    *         required: false
    *     responses:
    *       200:
    *         description: Returns success message
    */
    async listUserWithpost(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional(),
            userId: Joi.string().required(),
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            const { search, fromDate, toDate, page, limit, userId } = validatedBody;
            const paginateGood = (array, page_size, page_number) => {
                return array.slice((page_number - 1) * page_size, page_number * page_size);
            };
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            validatedBody['status'] = status.ACTIVE;
            validatedBody['postType'] = { $in: ['PRIVATE', 'PUBLIC'] };
            validatedBody['isSold'] = false;
            validatedBody['isBuy'] = false;
            let [userCollection, collectionIdList] = await Promise.all([await userCollectionListAll({ userId: userResult._id, status: { $ne: status.DELETE } }), await collectionSubscriptionUserList({ userId: userResult._id, status: { $ne: status.DELETE } })]);
            let newDoc = [];
            let dataResults = await paginateAllPostSearchPrivatePublicFind(validatedBody);
            if (dataResults.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            for (let i in dataResults) {
                for (let cObj of collectionIdList) {
                    if (cObj['collectionId'].toString() == dataResults[i].collectionId) {
                        dataResults[i]['isSubscribed'] = true;
                    }
                }
                for (let uObj of userCollection) {
                    if (uObj['_id'].toString() == dataResults[i].collectionId) {
                        dataResults[i]['isSubscribed'] = true;
                    }
                }
            }
            let finalData = []
            for (let i = 0; i < dataResults.length; i++) {
                if (!userResult.hidePost.includes(dataResults[i]._id)) {
                    finalData.push(dataResults[i])
                }
            }
            if (finalData.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            var finaldataRes = []
            for (let obj of finalData) {
                let findReportRes = await findAllReport({ userId: userResult._id, postId: obj._id });
                if (findReportRes.length == 0) {
                    finaldataRes.push(obj)
                }
                else {
                    for (let commentObject of findReportRes) {
                        obj['comment'] = obj['comment'].filter(item => !item['reportedId'].includes(commentObject._id))
                    }
                    if (!obj.reportedId.includes(findReportRes[0]._id)) {
                        finaldataRes.push(obj);
                    }
                }
            }
            if (finaldataRes.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            let options2 = {
                page: parseInt(req.query.page) || 1,
                limit: parseInt(req.query.limit) || 10,
            }
            let properResult = {
                docs: paginateGood(finaldataRes, options2.limit, options2.page),
                total: finaldataRes.length,
                limit: options2.limit,
                page: options2.page,
                pages: Math.ceil(finaldataRes.length / options2.limit)
            }
            if (properResult.docs.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            return res.json(new response(properResult, responseMessage.DATA_FOUND));
        } catch (error) {
            console.log('Catch error ==>', error)
            return next(error);
        }
    }


    /**
    * @swagger
    * /user/trendingPostlist:
    *   get:
    *     tags:
    *       - USER POSTS
    *     description: trendingPostlist
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: token
    *         description: token
    *         in: header
    *         required: true
    *       - name: search
    *         description: search
    *         in: query
    *         required: false
    *       - name: fromDate
    *         description: fromDate
    *         in: query
    *         required: false
    *       - name: toDate
    *         description: toDate
    *         in: query
    *         required: false
    *       - name: page
    *         description: page
    *         in: query
    *         required: false
    *       - name: limit
    *         description: limit
    *         in: query
    *         required: false
    *     responses:
    *       200:
    *         description: Returns success message
    */
    async trendingPostlist(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional()
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            const { search, fromDate, toDate, page, limit } = validatedBody;
            const paginateGood = (array, page_size, page_number) => {
                return array.slice((page_number - 1) * page_size, page_number * page_size);
            };
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            validatedBody['status'] = status.ACTIVE;
            validatedBody['postType'] = { $in: ['PRIVATE', 'PUBLIC'] };
            validatedBody['isSold'] = false;
            validatedBody['isBuy'] = false;
            let [userCollection, collectionIdList] = await Promise.all([await userCollectionListAll({ userId: userResult._id }), await collectionSubscriptionUserList({ userId: userResult._id })]);
            let newDoc = [];
            let dataResults = await paginateAllPostSearchPrivatePublicTrending(validatedBody);
            if (dataResults.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            for (let i in dataResults) {
                for (let cObj of collectionIdList) {
                    if (cObj['collectionId'].toString() == dataResults[i].collectionId) {
                        dataResults[i]['isSubscribed'] = true;
                    }
                }
                for (let uObj of userCollection) {
                    if (uObj['_id'].toString() == dataResults[i].collectionId) {
                        dataResults[i]['isSubscribed'] = true;
                    }
                }
                if (userResult['myWatchlist'].includes(dataResults[i]._id) == true) {
                    dataResults[i]['isWatchList'] = true;
                }
                dataResults[i].reactOnPost = await dataResults[i].reactOnPost.find(o => { return o.userId.toString() == userResult._id.toString() });
            }
            let blockUserRes = []
            for (let i = 0; i < dataResults.length; i++) {
                if (!userResult.blockedUser.includes(dataResults[i].userId._id)) {
                    blockUserRes.push(dataResults[i])
                }
            }
            let finalData = []
            for (let i = 0; i < blockUserRes.length; i++) {
                if (!userResult.hidePost.includes(blockUserRes[i]._id)) {
                    finalData.push(blockUserRes[i])
                }
            }
            let options2 = {
                page: parseInt(req.query.page) || 1,
                limit: parseInt(req.query.limit) || 10,
            }
            let properResult = {
                docs: paginateGood(finalData, options2.limit, options2.page),
                total: finalData.length,
                limit: options2.limit,
                page: options2.page,
                pages: Math.ceil(finalData.length / options2.limit)
            }
            if (properResult.docs.length == 0) {
                throw apiError.notFound(responseMessage.POST_NOT_FOUND)
            }
            return res.json(new response(properResult, responseMessage.POST_FOUND));
        } catch (error) {
            console.log('Catch error ==>', error)
            return next(error);
        }
    }


    /**
    * @swagger
    * /user/activityByPost:
    *   get:
    *     tags:
    *       - USER POSTS
    *     description: activityByPost
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: token
    *         description: token
    *         in: header
    *         required: true
    *       - name: postId
    *         description: _id of post
    *         in: query
    *         required: true
    *     responses:
    *       200:
    *         description: Returns success message
    */
    async activityByPost(req, res, next) {
        const validationSchema = {
            postId: Joi.string().required()
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            validatedBody.userId = userResult._id;
            let dataResults = await findAllActivity(validatedBody);
            if (dataResults.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            return res.json(new response(dataResults, responseMessage.DATA_FOUND));
        } catch (error) {
            console.log('Catch error ==>', error)
            return next(error);
        }
    }


    /**
     * @swagger
     * /user/trendingUserlist:
     *   get:
     *     tags:
     *       - USER 
     *     description: trendingUserlist
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: search
     *         description: search
     *         in: query
     *         required: false
     *       - name: fromDate
     *         description: fromDate
     *         in: query
     *         required: false
     *       - name: toDate
     *         description: toDate
     *         in: query
     *         required: false
     *       - name: page
     *         description: page
     *         in: query
     *         required: false
     *       - name: limit
     *         description: limit
     *         in: query
     *         required: false
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async trendingUserlist(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional()
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            const paginateGood = (array, page_size, page_number) => {
                return array.slice((page_number - 1) * page_size, page_number * page_size);
            };
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let data = await trendingUser(validatedBody)
            if (data.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            } else {
                let blockUserRes = []
                for (let i = 0; i < data.length; i++) {
                    if (!userResult.blockedUser.includes(data[i]._id)) {
                        blockUserRes.push(data[i])
                    }
                }
                let options2 = {
                    page: parseInt(req.query.page) || 1,
                    limit: parseInt(req.query.limit) || 10,
                }
                let properResult = {
                    docs: paginateGood(blockUserRes, options2.limit, options2.page),
                    total: blockUserRes.length,
                    limit: options2.limit,
                    page: options2.page,
                    pages: Math.ceil(blockUserRes.length / options2.limit)
                }
                if (properResult.docs.length == 0) {
                    throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
                }
                return res.json(new response(properResult, responseMessage.DATA_FOUND));
            }
        } catch (error) {
            return next(error);
        }
    }


    /**
     * @swagger
     * /user/expiredAuction:
     *   get:
     *     tags:
     *       - AUCTIONS
     *     description: expiredAuction
     *     produces:
     *       - application/json
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async expiredAuction(req, res, next) {
        try {
            // var updateRes = await updateManyAction({ time: { $lte: new Date().toISOString() }, status: { $ne: status.DELETE } }, { status: status.DELETE })
            let findAuctionResult = await auctionNftList({ isBuy:false,isSold:false,time: { $lte: new Date().toISOString() }, status: { $ne: status.DELETE } })
            if (findAuctionResult.length == 0) {
                return res.json(new response({}, responseMessage.DELETE_SUCCESS));
            }
            for (let i = 0; i < findAuctionResult.length; i++) {
                await updatePost({ _id: findAuctionResult[i].postId }, { isauction: false })
                await updateAuctionNft({ _id: findAuctionResult[i]._id }, { status: status.DELETE })
            }

            return res.json(new response({}, responseMessage.DELETE_SUCCESS));
        }
        catch (error) {
            return next(error);
        }
    }


    /**
     * @swagger
     * /user/storyListWithFollowing:
     *   get:
     *     tags:
     *       - USER STORY
     *     description: storyListWithFollowing
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: userId
     *         description: userId
     *         in: query
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async storyListWithFollowing(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                let data = await storyList({ userId: req.query.userId, visible: false, status: status.ACTIVE })
                if (data.length == 0) {
                    return res.json(new response(responseMessage.DATA_NOT_FOUND));
                } else {
                    return res.json(new response(data, responseMessage.DATA_FOUND));
                }
            }
        } catch (error) {
            return next(error);
        }
    }


    /**
     * @swagger
     * /user/addInterest:
     *   put:
     *     tags:
     *       - USER
     *     description: addInterest
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - in: body
     *         name: interest 
     *         description: interest.
     *         schema:
     *           type: object
     *           required:
     *             - interest
     *           properties:
     *             interest:
     *               type: array
     *               items:
     *                 type: string 
     *     responses:
     *       200:
     *         description: Returns success message.
     */
    async addInterest(req, res, next) {
        const validationSchema = {
            interest: Joi.array().items(Joi.string()).allow('').required(),
        };
        try {
            const { interest } = await Joi.validate(req.body, validationSchema);
            var userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            else {
                let result = await updateUser({ _id: userResult._id }, { $set: { interest: interest } });
                return res.json(new response(result, responseMessage.INTEREST_ADD));
            }
        }
        catch (error) {
            console.log(error);
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/listFollowingUserStoryVisible:
     *   get:
     *     tags:
     *       - USER STORY
     *     description: listFollowingUserStoryVisible
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async listFollowingUserStoryVisible(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let following = [];
            if (userResult.isStory == true) {
                following.push(userResult)
            }
            for (let i = 0; i < userResult.following.length; i++) {
                const element = userResult.following[i];
                let userResult1 = await findUser({ _id: element, isStory: true });
                following.push(userResult1)
            }
            let obj = {
                following: following,
                count: userResult.following.length
            }
            return res.json(new response(obj, responseMessage.DATA_FOUND));
        }
        catch (error) {
            return next(error);
        }

    }


    /**
    * @swagger
    * /user/activityByPost:
    *   get:
    *     tags:
    *       - USER POSTS
    *     description: activityByPost
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: token
    *         description: token
    *         in: header
    *         required: true
    *       - name: postId
    *         description: _id of post
    *         in: query
    *         required: true
    *     responses:
    *       200:
    *         description: Returns success message
    */
    async activityByPost(req, res, next) {
        const validationSchema = {
            postId: Joi.string().required()
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            validatedBody.userId = userResult._id;
            let dataResults = await findAllActivity(validatedBody);
            if (dataResults.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            return res.json(new response(dataResults, responseMessage.DATA_FOUND));
        } catch (error) {
            console.log('Catch error ==>', error)
            return next(error);
        }
    }

    /**
    * @swagger
    * /user/tagPostlist:
    *   get:
    *     tags:
    *       - USER POSTS
    *     description: tagPostlist
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: token
    *         description: token
    *         in: header
    *         required: true
    *       - name: search
    *         description: search
    *         in: query
    *         required: false
    *       - name: fromDate
    *         description: fromDate
    *         in: query
    *         required: false
    *       - name: toDate
    *         description: toDate
    *         in: query
    *         required: false
    *       - name: page
    *         description: page
    *         in: query
    *         required: false
    *       - name: limit
    *         description: limit
    *         in: query
    *         required: false
    *     responses:
    *       200:
    *         description: Returns success message
    */
    async tagPostlist(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional()
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            const { search, fromDate, toDate, page, limit } = validatedBody;
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            validatedBody['status'] = { $ne: status.DELETE };
            validatedBody['postType'] = { $in: ['PRIVATE', 'PUBLIC'] };
            validatedBody['isSold'] = false;
            validatedBody['isBuy'] = false;
            validatedBody['tag'] = userResult._id;
            let [userCollection, collectionIdList] = await Promise.all([await userCollectionListAll({ userId: userResult._id, status: { $ne: status.DELETE } }), await collectionSubscriptionUserList({ userId: userResult._id, status: { $ne: status.DELETE } })]);
            let newDoc = [];
            let dataResults = await tagPostbyuserlist(validatedBody);
            if (dataResults.docs.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            for (let i in dataResults.docs) {
                for (let cObj of collectionIdList) {
                    if (cObj['collectionId'].toString() == dataResults.docs[i].collectionId) {
                        dataResults.docs[i]['isSubscribed'] = true;
                    }
                }
                for (let uObj of userCollection) {
                    if (uObj['_id'].toString() == dataResults.docs[i].collectionId) {
                        dataResults.docs[i]['isSubscribed'] = true;
                    }
                }
                if (userResult['myWatchlist'].includes(dataResults.docs[i]._id) == true) {
                    dataResults.docs[i]['isWatchList'] = true;
                }
                dataResults.docs[i].reactOnPost = await dataResults.docs[i].reactOnPost.find(o => { return o.userId.toString() == userResult._id.toString() });
            }
            return res.json(new response(dataResults, responseMessage.DATA_FOUND));
        } catch (error) {
            console.log('Catch error ==>', error)
            return next(error);
        }
    }


    /**
     * @swagger
     * /user/migthtList:
     *   get:
     *     tags:
     *       - USER
     *     description: migthtList
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async migthtList(req, res, next) {
        try {
            var userResult = await findUserData({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            for (let i = 0; i < userResult.mightUser.length; i++) {
                if (userResult.blockedUser.includes(userResult.mightUser[i]._id)) {
                    userResult.mightUser.pull(userResult.mightUser[i])
                }
            }
            return res.json(new response(userResult, responseMessage.USER_DETAILS));
        } catch (error) {
            return next(error);
        }
    }


    /**
   * @swagger
   * /user/trendingAuction:
   *   get:
   *     tags:
   *       - AUCTIONS
   *     description: trendingAuction
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: token
   *         description: token
   *         in: header
   *         required: true
   *       - name: search
   *         description: search
   *         in: query
   *         required: false
   *       - name: fromDate
   *         description: fromDate
   *         in: query
   *         required: false
   *       - name: toDate
   *         description: toDate
   *         in: query
   *         required: false
   *       - name: page
   *         description: page
   *         in: query
   *         required: false
   *       - name: limit
   *         description: limit
   *         in: query
   *         required: false
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async trendingAuction(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional()
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            const { search, fromDate, toDate, page, limit } = validatedBody;
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let dataResults = await trendingAuctionList(validatedBody);
            if (dataResults.docs.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            return res.json(new response(dataResults, responseMessage.DATA_FOUND));
        } catch (error) {
            return next(error);
        }
    }


    /**
      * @swagger
      * /user/requestAdminByuser:
      *   post:
      *     tags:
      *       - USER
      *     description: requestAdminByuser
      *     produces:
      *       - application/json
      *     parameters:
      *       - name: email
      *         description: email / mobileNumber
      *         in: formData
      *         required: true
      *       - name: message
      *         description: message
      *         in: formData
      *         required: true
      *     responses:
      *       200:
      *         description: Returns success message
      */
    async requestAdminByuser(req, res, next) {
        const validationSchema = {
            message: Joi.string().required(),
            email: Joi.string().required(),
        }
        try {
            const validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ $and: [{ status: { $ne: status.DELETE }, userType: userType.USER }, { $or: [{ mobileNumber: validatedBody.email }, { email: validatedBody.email }] }] });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);;
            } else {
                let resultRes = await findRequest({ userId: userResult._id, status: { $ne: status.DELETE } })
                if (resultRes) {
                    throw apiError.conflict(responseMessage.REQUEST_EXIST);
                } else {
                    let obj = {
                        message: validatedBody.message,
                        userId: userResult._id
                    }
                    let saveRes = await createRequest(obj)
                    return res.json(new response(saveRes, responseMessage.REQUEST_SENT));
                }
            }
        } catch (error) {
            return next(error);
        }
    }

    /**
      * @swagger
      * /user/userIgnore_Unignore:
      *   post:
      *     tags:
      *       -  USER 
      *     description: userIgnore_Unignore
      *     produces:
      *       - application/json
      *     parameters:
      *       - name: token
      *         description: token
      *         in: header
      *         required: true
      *       - name: _id
      *         description: _id
      *         in: formData
      *         required: true
      *     responses:
      *       200:
      *         description: Returns success message
      */
    async userIgnore_Unignore(req, res, next) {
        const validationSchema = {
            _id: Joi.string().required()
        }
        try {
            const validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult1 = await findUser({ _id: req.userId })
            if (!userResult1) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                var userCheck = await findUser({ _id: validatedBody._id, status: { $ne: status.DELETE } });
                if (userCheck) {
                    var checkBlockUser = await findUser({ _id: userResult1._id, ignoreUser: userCheck._id });
                    if (checkBlockUser) {
                        var updateResult = await updateUserById({ _id: userResult1._id }, { $pull: { ignoreUser: userCheck._id } });
                        let obj = {
                            title: "Un_ignore a user.",
                            desctiption: `Your have un_ignore a ${userCheck.userName} profile.`,
                            type: "UN_IGNORE",
                            userId: userResult1._id,
                        }
                        await createActivity(obj);
                        return res.json(new response(updateResult, responseMessage.UN_IGNORE_BY_USER));
                    } else {
                        var updateResult = await updateUserById({ _id: userResult1._id }, { $push: { ignoreUser: userCheck._id } });
                        let obj = {
                            title: "Ignore a user.",
                            desctiption: `Your have ignore a ${userCheck.userName} profile.`,
                            type: "IGNORE",
                            userId: userResult1._id,
                        }
                        await createActivity(obj);
                        return res.json(new response(updateResult, responseMessage.IGNORE_BY_USER));
                    }
                } else {
                    throw apiError.notFound(responseMessage.USER_NOT_FOUND)
                }
            }
        } catch (error) {
            console.log(error)
            return next(error)
        }
    }
    /**
      * @swagger
      * /user/disappearView:
      *   get:
      *     tags:
      *       - USER
      *     description: disappearView
      *     produces:
      *       - application/json
      *     parameters:
      *       - name: token
      *         description: token
      *         in: header
      *         required: true
      *     responses:
      *       200:
      *         description: Returns success message
      */
    async disappearView(req, res, next) {
        try {
            let userResult1 = await findUser({ _id: req.userId, status: { $ne: status.DELETE } })
            if (!userResult1) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            }
            let resultRes = await findDisappear({ senderId: userResult1._id, status: { $ne: status.DELETE } })
            if (!resultRes) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            } else {
                return res.json(new response(resultRes, responseMessage.DATA_FOUND));
            }
        } catch (error) {
            return next(error);
        }
    }

    /**
      * @swagger
      * /user/disappearUpdate:
      *   put:
      *     tags:
      *       - USER
      *     description: disappearUpdate
      *     produces:
      *       - application/json
      *     parameters:
      *       - name: token
      *         description: token
      *         in: header
      *         required: true
      *       - name: receiverId
      *         description: receiverId
      *         in: formData
      *         required: true
      *       - name: time
      *         description: time
      *         in: formData
      *         required: true
      *       - name: disappear
      *         description: disappear true , false
      *         in: formData
      *         required: true
      *     responses:
      *       200:
      *         description: Returns success message
      */
    async disappearUpdate(req, res, next) {
        try {
            let userResult1 = await findUser({ _id: req.userId, status: { $ne: status.DELETE } })
            if (!userResult1) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            }
            var senderId = userResult1._id
            var receiverId = req.body.receiverId
            var query = { $and: [{ $or: [{ senderId: senderId }, { senderId: receiverId }] }, { $or: [{ receiverId: receiverId }, { receiverId: senderId }] }] }
            let resultRes = await findDisappear(query)
            if (!resultRes) {
                let obj = {
                    senderId: senderId,
                    receiverId: receiverId,
                    time: req.body.time,
                    disappear: req.body.disappear
                }
                let saveRes = await createDisappear(obj)
                return res.json(new response(saveRes, responseMessage.DISAPPEARING_ON));
            } else {
                if ("true" == req.body.disappear) {
                    let dataRes = await updateDisappear({ _id: resultRes._id }, { disappear: req.body.disappear, time: req.body.time })
                    return res.json(new response(dataRes, responseMessage.DISAPPEARING_ON));
                } else {
                    let dataRes = await updateDisappear({ _id: resultRes._id }, { disappear: req.body.disappear, time: req.body.time })
                    return res.json(new response(dataRes, responseMessage.DISAPPEARING_OFF));
                }
            }
        } catch (error) {
            console.log(error)
            return next(error);
        }
    }


    /**
     * @swagger
     * /user/createPostPromotion:
     *   post:
     *     tags:
     *       - POST PROMOTION 
     *     description: createPostPromotion
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: createPostPromotion
     *         description: createPostPromotion
     *         in: body
     *         required: true
     *         schema:
     *           $ref: '#/definitions/createPostPromotion'
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async createPostPromotion(req, res, next) {
        try {
            const validationSchema = {
                postTitle: Joi.string().optional(),
                mediaUrl: Joi.string().optional(),
                details: Joi.string().optional(),
                dateTime: Joi.string().optional(),
                minAge: Joi.string().optional(),
                maxAge: Joi.string().optional(),
                postId: Joi.string().optional(),
                tag: Joi.array().optional(),
                amount: Joi.string().optional(),
                interest: Joi.array().optional(),
                url: Joi.string().optional(),
            }
            const validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                if (validatedBody.postId) {
                    let postRes = await findOnePost({ _id: validatedBody.postId, userId: userResult._id, status: { $ne: status.DELETE } })
                    if (!postRes) {
                        throw apiError.notFound(responseMessage.POST_NOT_FOUND)
                    }
                    await updatePost({ _id: postRes._id }, { status: status.DELETE })
                }
                let adminRes = await findUserData({ userType: userType.ADMIN, status: { $ne: status.DELETE } })
                if (parseFloat(validatedBody.amount) >= parseFloat(userResult.bnbBalace)) {
                    throw apiError.badRequest(responseMessage.LOW_MASS);
                }
                if (validatedBody.mediaUrl) {
                    validatedBody.mediaUrl = await commonFunction.getSecureUrl(validatedBody.mediaUrl);
                }
                validatedBody.type = "PROMOTION"
                validatedBody.userId = userResult._id;
                let savePost = await createPostPromotion(validatedBody)
                await createActivity({
                    userId: userResult._id,
                    postPromotionId: savePost._id,
                    title: "Post promotion",
                    desctiption: "Promotion create successfully.",
                    type: "POSTPROMOTION"
                })
                await updateUser({ _id: adminRes._id }, { bnbBalace: adminRes.bnbBalace + parseFloat(validatedBody.amount) })
                await updateUser({ _id: userResult._id }, { bnbBalace: userResult.bnbBalace - parseFloat(validatedBody.amount) })
                await createTransaction({
                    userId: adminRes._id,
                    promotionId: savePost._id,
                    amount: validatedBody.amount,
                    transactionType: "POST_PROMOTION_RECEIVE",
                })
                await createTransaction({
                    userId: userResult._id,
                    promotionId: savePost._id,
                    commission: validatedBody.amount,
                    transactionType: "POST_PROMOTION_SHARE",
                })
                return res.json(new response(savePost, responseMessage.CREATE_POST_PROMOTION));
            }
        } catch (error) {
            console.log("6185 ====================>", error)
            return next(error);
        }
    }


    /**
   * @swagger
   * /user/myPostPromotionList:
   *   get:
   *     tags:
   *       - POST PROMOTION 
   *     description: myPostPromotionList
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: token
   *         description: token
   *         in: header
   *         required: true
   *       - name: search
   *         description: search
   *         in: query
   *         required: false
   *       - name: fromDate
   *         description: fromDate
   *         in: query
   *         required: false
   *       - name: toDate
   *         description: toDate
   *         in: query
   *         required: false
   *       - name: page
   *         description: page
   *         in: query
   *         required: false
   *       - name: limit
   *         description: limit
   *         in: query
   *         required: false
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async myPostPromotionList(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional()
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            validatedBody.userId = userResult._id;
            let dataResults = await paginatePostPromotionSearch(validatedBody);
            if (dataResults.docs.length == 0) {
                throw apiError.notFound(responseMessage.POST_NOT_PROMOTION)
            }
            return res.json(new response(dataResults, responseMessage.POST_PROMOTION));
        } catch (error) {
            return next(error);
        }

    }

    /**
   * @swagger
   * /user/myPostPromotionView:
   *   get:
   *     tags:
   *       - POST PROMOTION 
   *     description: myPostPromotionView
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: token
   *         description: token
   *         in: header
   *         required: true
   *       - name: _id
   *         description: post promotion _id
   *         in: query
   *         required: true
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async myPostPromotionView(req, res, next) {
        const validationSchema = {
            _id: Joi.string().optional(),
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let dataResults = await findPostPromotion({ _id: validatedBody._id, status: { $ne: status.DELETE } });
            if (!dataResults) {
                throw apiError.notFound(responseMessage.POST_NOT_PROMOTION)
            }
            return res.json(new response(dataResults, responseMessage.POST_PROMOTION));
        } catch (error) {
            return next(error);
        }

    }

    /**
   * @swagger
   * /user/postPromotionDelete:
   *   delete:
   *     tags:
   *       - POST PROMOTION 
   *     description: postPromotionDelete
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: token
   *         description: token
   *         in: header
   *         required: true
   *       - name: _id
   *         description: post promotion _id
   *         in: query
   *         required: true
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async postPromotionDelete(req, res, next) {
        const validationSchema = {
            _id: Joi.string().optional(),
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let dataResults = await findPostPromotion({ _id: validatedBody._id, userId: userResult._id, status: { $ne: status.DELETE } });
            if (!dataResults) {
                throw apiError.notFound(responseMessage.POST_NOT_PROMOTION)
            }
            let updateRes = await updatePostPromotion({ _id: dataResults._id }, { status: status.DELETE })
            return res.json(new response(updateRes, responseMessage.POST_PROMOTION_DELETE));
        } catch (error) {
            return next(error);
        }

    }


    /**
  * @swagger
  * /user/likeDislikePostPromotion/{postPromotionId}:
  *   get:
  *     tags:
  *       - POST PROMOTION
  *     description: likeDislikePostPromotion
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: token
  *         description: token
  *         in: header
  *         required: true
  *       - name: postPromotionId
  *         description: postPromotionId
  *         in: path
  *         required: true
  *     responses:
  *       200:
  *         description: Returns success message
  */
    async likeDislikePostPromotion(req, res, next) {
        const validationSchema = {
            postPromotionId: Joi.string().required(),
        }
        var updated;
        try {
            const { postPromotionId } = await Joi.validate(req.params, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let postPromotionRes = await findPostPromotion({ _id: postPromotionId, status: { $ne: status.DELETE } });
            if (!postPromotionRes) {
                throw apiError.notFound(responseMessage.POST_NOT_PROMOTION);
            }
            if (postPromotionRes.likesUsers.includes(userResult._id)) {
                updated = await updatePostPromotion({ _id: postPromotionRes._id }, { $pull: { likesUsers: userResult._id }, $inc: { likesCount: -1 } });
                await updateUser({ _id: userResult._id }, { $pull: { likesPostPromotion: postPromotionRes._id } });
                await createActivity({
                    userId: userResult._id,
                    postPromotionId: postPromotionRes._id,
                    title: "Dislike post promotion",
                    desctiption: "Bad choice, I disliked it.",
                    type: "DISLIKE"
                })
                return res.json(new response(updated, responseMessage.DISLIKES));
            } else {
                await createActivity({
                    userId: userResult._id,
                    postPromotionId: postPromotionRes._id,
                    title: "Like post promotion",
                    desctiption: "Nice choice, I liked it.",
                    type: "LIKE"
                })
                var name = userResult.name || userResult.userName
                let postPromotionResult = await findPostPromotion({ _id: postPromotionId, userId: userResult._id, status: { $ne: status.DELETE } });
                if (postPromotionResult) {
                    updated = await updatePostPromotion({ _id: postPromotionRes._id }, { $addToSet: { likesUsers: userResult._id }, $inc: { likesCount: 1 } });
                    await updateUser({ _id: userResult._id }, { $addToSet: { likesPostPromotion: postPromotionRes._id } });
                    return res.json(new response(updated, responseMessage.LIKES));
                }
                await notificationDeleteMany({ userId: postPromotionRes.userId, notificationType: "POST_PROMOTION_LIKE", likeBy: userResult._id, promotionId: postPromotionRes._id })
                await createNotification({
                    title: `Like post promotion`,
                    description: `${name} likes your promotion.`,
                    userId: postPromotionRes.userId,
                    notificationType: "POST_PROMOTION_LIKE",
                    likeBy: userResult._id,
                    promotionId: postPromotionRes._id
                });
                let userResDeviceToken = await findUser({ _id: postPromotionRes.userId })
                if (userResDeviceToken.deviceToken) {
                    let message = {
                        to: userResDeviceToken.deviceToken,
                        data: {
                            title: `Like post promotion`,
                            body: `${name} likes your promotion.`,
                            userId: postPromotionRes.userId,
                            notificationType: "POST_PROMOTION_LIKE",
                            likeBy: userResult._id,
                            promotionId: postPromotionRes._id,
                            sound: 'default'
                        },
                        notification: {
                            title: `Like post promotion`,
                            body: `${name} likes your promotion.`,
                            sound: 'default'
                        }
                    };
                    await commonFunction.pushNotification(message)
                }
                updated = await updatePostPromotion({ _id: postPromotionRes._id }, { $addToSet: { likesUsers: userResult._id }, $inc: { likesCount: 1 } });
                await updateUser({ _id: userResult._id }, { $addToSet: { likesPostPromotion: postPromotionRes._id } });
                return res.json(new response(updated, responseMessage.LIKES));
            }
        }
        catch (error) {
            if (error == 'NotRegistered') {
                error = { message: 'Device token not registered on server.' }
            }
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/commentOnPostPromotion:
     *   post:
     *     tags:
     *       - POST PROMOTION
     *     description: commentOnPostPromotion
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: postPromotionId
     *         description: postPromotionId
     *         in: formData
     *         required: true
     *       - name: message
     *         description: message
     *         in: formData
     *         required: false
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async commentOnPostPromotion(req, res, next) {
        const validationSchema = {
            postPromotionId: Joi.string().required(),
            message: Joi.string().optional(),
        }
        try {
            let update;
            const validatedBody = await Joi.validate(req.body, validationSchema);
            const { postPromotionId, message } = validatedBody;
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let postPromotionRes = await findPostPromotion({ _id: postPromotionId, status: { $ne: status.DELETE } })
            if (!postPromotionRes) {
                throw apiError.notFound(responseMessage.POST_NOT_PROMOTION);
            } else {
                update = await updatePostPromotion({ _id: postPromotionRes._id }, { $push: { comment: { userId: userResult._id, message: message, time: new Date().toISOString(), } }, $inc: { totalComment: 1 } })
                var name = userResult.name || userResult.userName
                await createActivity({
                    userId: userResult._id,
                    postPromotionId: postPromotionRes._id,
                    title: "Post promotion comment",
                    desctiption: `${name} comment on this Post promotion.`,
                    type: "COMMENT"
                })
                let postPromotionResult = await findPostPromotion({ _id: postPromotionId, userId: userResult._id, status: { $ne: status.DELETE } })
                if (postPromotionResult) {
                    return res.json(new response(update, responseMessage.COMMENT_ADDED));
                }
                await notificationDeleteMany({ userId: postPromotionRes.userId, promotionId: postPromotionRes._id, commentBy: userResult._id, notificationType: "POST_PROMOTION_COMMENT" })
                let notificationObj = {
                    title: `Comment on post promotion! `,
                    description: `${name} has comment on your post promotion.`,
                    userId: postPromotionRes.userId,
                    notificationType: "POST_PROMOTION_COMMENT",
                    promotionId: postPromotionRes._id,
                    commentBy: userResult._id
                }
                await createNotification(notificationObj);
                return res.json(new response(update, responseMessage.COMMENT_ADDED));
            }
        } catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/commentReplyOnPostPromotion:
     *   post:
     *     tags:
     *       - POST PROMOTION
     *     description: commentReplyOnPostPromotion
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: postPromotionId
     *         description: postPromotionId
     *         in: formData
     *         required: true
     *       - name: commentId
     *         description: commentId
     *         in: formData
     *         required: true
     *       - name: message
     *         description: message
     *         in: formData
     *         required: false
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async commentReplyOnPostPromotion(req, res, next) {
        const validationSchema = {
            postPromotionId: Joi.string().required(),
            message: Joi.string().optional(),
            commentId: Joi.string().optional(),
        }
        try {
            let update;
            const validatedBody = await Joi.validate(req.body, validationSchema);
            const { postPromotionId, message, commentId } = validatedBody;
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let postPromotionRes = await findPostPromotion({ _id: postPromotionId, status: { $ne: status.DELETE } })
            if (!postPromotionRes) {
                throw apiError.notFound(responseMessage.POST_NOT_PROMOTION);
            } else {
                let obj = {
                    userId: userResult._id,
                    commentId: commentId,
                    message: message,
                    time: new Date().toISOString(),
                }
                update = await updatePostPromotion({ _id: postPromotionRes._id, "comment._id": commentId }, { $push: { 'comment.$.reply': obj }, $inc: { "comment.$.totalReply": 1 } })
                var name = userResult.name || userResult.userName
                await createActivity({
                    userId: userResult._id,
                    postPromotionId: postPromotionRes._id,
                    title: "Post promotion comment reply",
                    desctiption: `${name} reply on your comment on this Post promotion.`,
                    type: "COMMENT_REPLY"
                })
                let postPromotionResult = await findPostPromotion({ _id: postPromotionId, userId: userResult._id, status: { $ne: status.DELETE } })
                if (postPromotionResult) {
                    return res.json(new response(update, responseMessage.REPLY_COMMENT));
                }
                await notificationDeleteMany({ userId: postPromotionRes.userId, notificationType: "POST_PROMOTION_COMMENT", promotionId: postPromotionRes._id, commentBy: userResult._id })
                let notificationObj = {
                    title: `Reply on comment on promotion!`,
                    description: `${name} has comment on your promotion.`,
                    userId: postPromotionRes.userId,
                    notificationType: "POST_PROMOTION_COMMENT",
                    promotionId: postPromotionRes._id,
                    commentBy: userResult._id
                }
                await createNotification(notificationObj);
                return res.json(new response(update, responseMessage.REPLY_COMMENT));
            }
        } catch (error) {
            return next(error);
        }
    }


    /**
   * @swagger
   * /user/allPostPromotionList:
   *   get:
   *     tags:
   *       - POST PROMOTION 
   *     description: allPostPromotionList
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: search
   *         description: search
   *         in: query
   *         required: false
   *       - name: fromDate
   *         description: fromDate
   *         in: query
   *         required: false
   *       - name: toDate
   *         description: toDate
   *         in: query
   *         required: false
   *       - name: page
   *         description: page
   *         in: query
   *         required: false
   *       - name: limit
   *         description: limit
   *         in: query
   *         required: false
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async allPostPromotionList(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional()
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let dataResults = await allPaginatePostPromotionSearch(validatedBody);
            if (dataResults.docs.length == 0) {
                throw apiError.notFound(responseMessage.POST_NOT_PROMOTION)
            }
            return res.json(new response(dataResults, responseMessage.POST_PROMOTION));
        } catch (error) {
            return next(error);
        }

    }


    /**
  * @swagger
  * /user/likeDislikeCommentOnPostPromotion:
  *   get:
  *     tags:
  *       - POST PROMOTION
  *     description: likeDislikeCommentOnPostPromotion
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: token
  *         description: token
  *         in: header
  *         required: true
  *       - name: postPromotionId
  *         description: postPromotionId
  *         in: query
  *         required: true
  *       - name: commentId 
  *         description: commentId ? _id
  *         in: query
  *         required: true
  *     responses:
  *       200:
  *         description: Returns success message
  */
    async likeDislikeCommentOnPostPromotion(req, res, next) {
        const validationSchema = {
            commentId: Joi.string().required(),
            postPromotionId: Joi.string().required(),
        }
        var updated;
        try {
            const { commentId, postPromotionId } = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let postPromotionRes = await findPostPromotion({ _id: postPromotionId, "comment._id": commentId, status: { $ne: status.DELETE } });
            if (!postPromotionRes) {
                throw apiError.notFound(responseMessage.POST_NOT_FOUND);
            }
            for (let i in postPromotionRes.comment) {
                if (postPromotionRes.comment[i]._id == commentId) {
                    if (postPromotionRes.comment[i].likesUsers.includes(userResult._id) == true) {
                        updated = await updatePostPromotion({ _id: postPromotionRes._id, "comment._id": commentId }, { $pull: { 'comment.$.likesUsers': userResult._id }, $inc: { 'comment.$.likesCount': -1 } });
                        await updateUser({ _id: userResult._id }, { $pull: { likesCommentOnPostPromotionId: commentId } });
                        return res.json(new response(updated, responseMessage.DISLIKES));
                    } else {
                        var name = userResult.name || userResult.userName
                        let postPromotionResult = await findPostPromotion({ _id: postPromotionId, userId: userResult._id, status: { $ne: status.DELETE } });
                        if (postPromotionResult) {
                            updated = await updatePostPromotion({ _id: postPromotionRes._id, "comment._id": commentId }, { $addToSet: { 'comment.$.likesUsers': userResult._id }, $inc: { 'comment.$.likesCount': 1 } });
                            await updateUser({ _id: userResult._id }, { $addToSet: { likesCommentOnPostPromotionId: commentId } });
                            return res.json(new response(updated, responseMessage.LIKES));
                        }
                        await notificationDeleteMany({ userId: postPromotionRes.userId, notificationType: "POST_PROMOTION_LIKE", likeBy: userResult._id, promotionId: postPromotionRes._id })
                        await createNotification({
                            title: `Like comment on post promotion!`,
                            description: `${name} likes your promotion.`,
                            userId: postPromotionRes.userId,
                            notificationType: "POST_PROMOTION_LIKE",
                            likeBy: userResult._id,
                            promotionId: postPromotionRes._id
                        });
                        let userResDeviceToken = await findUser({ _id: postPromotionRes.userId })
                        if (userResDeviceToken.deviceToken) {
                            let message = {
                                to: userResDeviceToken.deviceToken,
                                data: {
                                    title: `Like comment on post promotion!`,
                                    body: `${name} likes your promotion.`,
                                    userId: postPromotionRes.userId,
                                    notificationType: "POST_PROMOTION_LIKE",
                                    likeBy: userResult._id,
                                    promotionId: postPromotionRes._id,
                                    sound: 'default'
                                },
                                notification: {
                                    title: `Like comment on post promotion!`,
                                    body: `${name} likes your promotion.`,
                                    sound: 'default'
                                }
                            };
                            await commonFunction.pushNotification(message)
                        }
                        updated = await updatePostPromotion({ _id: postPromotionRes._id, "comment._id": commentId }, { $addToSet: { 'comment.$.likesUsers': userResult._id }, $inc: { 'comment.$.likesCount': 1 } });
                        await updateUser({ _id: userResult._id }, { $addToSet: { likesCommentOnPostPromotionId: commentId } });
                        return res.json(new response(updated, responseMessage.LIKES));
                    }
                }
            }

        }
        catch (error) {
            console.log(error);
            if (error == 'NotRegistered') {
                error = { message: 'Device token not registered on server.' }
            }
            return next(error);
        }
    }


    /**
     * @swagger
     * /user/deposit:
     *   post:
     *     tags:
     *       - USER
     *     description: deposit
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: walletAddress
     *         description: walletAddress
     *         in: formData
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async deposit(req, res, next) {
        try {
            let userResult = await findUserData({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let adminRes = await findUserData({ userType: userType.ADMIN, status: { $ne: status.DELETE } })
            if (parseFloat(userResult.bnbBalace) <= 100) {
                throw apiError.badRequest(responseMessage.LOW_MASS);
            } else {
                let transferRes = await binance.transfer(adminRes.bnbAccount.address, adminRes.bnbAccount.privateKey, userResult.bnbAccount.address, 0.001);
                if (transferRes.Hash) {
                    await updateUser({ _id: adminRes._id }, { bnbBalace: adminRes.bnbBalace - parseFloat(0.001) })
                    let updateRes = await updateUser({ _id: userResult._id }, { bnbBalace: userResult.bnbBalace + parseFloat(0.001) })
                    let obj = {
                        bnbBalace: updateRes.bnbBalace,
                        address: updateRes.bnbAccount.address
                    }
                    let userTransaction = await createTransaction({
                        userId: userResult._id,
                        amount: 0.001,
                        transactionType: "DEPOSIT_FOR_ADMIN",
                    })
                    await createTransaction({
                        userId: adminRes._id,
                        amount: 0.001,
                        transactionType: "DEPOSIT_FOR_USER",
                    })
                    let notificationObj = {
                        title: `Amount Deposit!`,
                        description: `${req.body.amount} deposit from your account successfully.`,
                        userId: userResult._id,
                        notificationType: "AMOUNT_DEPOSIT",
                        transactionId: userTransaction._id
                    }
                    if (userResult.deviceToken) {
                        let message = {
                            to: userResult.deviceToken,
                            data: {
                                title: `Amount Deposit!`,
                                body: `${req.body.amount} deposit from your account successfully.`,
                                userId: userResult._id,
                                notificationType: "AMOUNT_DEPOSIT",
                                transactionId: userTransaction._id,
                                sound: 'default'
                            },
                            notification: {
                                title: `Amount Deposit!`,
                                body: `${req.body.amount} deposit from your account successfully.`,
                                sound: 'default'
                            }
                        };
                        await commonFunction.pushNotification(message)
                    }
                    await createNotification(notificationObj);
                    return res.json(new response(obj, responseMessage.DEPOSIT));
                } else {
                    throw apiError.internal(responseMessage.BLOCKCHAIN_ERROR)
                }
            }

        } catch (error) {
            return next(error);
        }
    }

    /**
   * @swagger
   * /user/createInterest:
   *   post:
   *     tags:
   *       - INTEREST 
   *     description: createInterest
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: token
   *         description: token
   *         in: header
   *         required: true
   *       - name: name
   *         description: name
   *         in: formData
   *         required: true
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async createInterest(req, res, next) {
        const validationSchema = {
            name: Joi.string().required(),
        }
        try {
            const validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId, userType: userType.ADMIN, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let interestRes = await findInterest({ name: req.body.name, status: { $ne: status.DELETE } })
            if (interestRes) {
                throw apiError.conflict(responseMessage.INTEREST_EXIST);
            }
            validatedBody.userId = userResult._id;
            let saveRes = await createInterest(validatedBody)
            return res.json(new response(saveRes, responseMessage.CREATE_INTEREST));
        } catch (error) {
            return next(error);
        }

    }

    /**
  * @swagger
  * /user/viewInterest:
  *   get:
  *     tags:
  *       - INTEREST 
  *     description: viewInterest
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: interestId
  *         description: interestId
  *         in: query
  *         required: true
  *     responses:
  *       200:
  *         description: Returns success message
  */
    async viewInterest(req, res, next) {
        const validationSchema = {
            interestId: Joi.string().required(),
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let resultRes = await findInterest({ _id: validatedBody.interestId, status: { $ne: status.DELETE } });
            if (!resultRes) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            }
            return res.json(new response(resultRes, responseMessage.DATA_FOUND));
        } catch (error) {
            return next(error);
        }

    }

    /**
  * @swagger
  * /user/deleteInterest:
  *   delete:
  *     tags:
  *       - INTEREST 
  *     description: deleteInterest
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: token
  *         description: token
  *         in: header
  *         required: true
  *       - name: interestId
  *         description: interestId
  *         in: query
  *         required: true
  *     responses:
  *       200:
  *         description: Returns success message
  */
    async deleteInterest(req, res, next) {
        const validationSchema = {
            interestId: Joi.string().required(),
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let resultRes = await findInterest({ _id: validatedBody.interestId, status: { $ne: status.DELETE } });
            if (!resultRes) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            }
            let updateRes = await updateInterest({ _id: resultRes._id }, { status: status.DELETE })
            return res.json(new response(updateRes, responseMessage.INTEREST_DELETE));
        } catch (error) {
            return next(error);
        }

    }

    /**
  * @swagger
  * /user/listInterest:
  *   get:
  *     tags:
  *       - INTEREST 
  *     description: listInterest
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: fromDate
  *         description: fromDate
  *         in: query
  *         required: false
  *       - name: toDate
  *         description: toDate
  *         in: query
  *         required: false
  *       - name: page
  *         description: page
  *         in: query
  *         required: false
  *       - name: limit
  *         description: limit
  *         in: query
  *         required: false
  *     responses:
  *       200:
  *         description: Returns success message
  */
    async listInterest(req, res, next) {
        const validationSchema = {
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional()
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let resultRes = await paginateSearchInterest(validatedBody);
            if (resultRes.docs.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            }
            return res.json(new response(resultRes, responseMessage.DATA_FOUND));
        } catch (error) {
            return next(error);
        }

    }

    /**
    * @swagger
    * /user/withdraw:
    *   post:
    *     tags:
    *       - USER
    *     description: withdraw
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: token
    *         description: token
    *         in: header
    *         required: true
    *       - name: walletAddress
    *         description: walletAddress
    *         in: formData
    *         required: true
    *       - name: amount
    *         description: amount
    *         in: formData
    *         required: true
    *     responses:
    *       200:
    *         description: Returns success message
    */
    async withdraw(req, res, next) {
        try {
            let userResult = await findUserData({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let adminRes = await findUserData({ userType: userType.ADMIN, status: { $ne: status.DELETE } });
            let coinFees = await findFee({ type: "COIN-FEE", status: { $ne: status.DELETE } });
            let bnbFee = coinFees['coins'].find(o => o.coinName == 'BNB')['fee'] * req.body.amount;
            if (parseFloat(req.body.amount) <= 99.9) {
                throw apiError.badRequest(responseMessage.MIN_AMOUNT);
            }
            if (parseFloat(userResult.bnbBalace) <= parseFloat(req.body.amount)) {
                throw apiError.badRequest(responseMessage.LOW_BALANCE);
            } else {
                let transferResult = await binance.tokenWithdraw(adminRes.bnbAccount.address, adminRes.bnbAccount.privateKey, req.body.walletAddress, web3.utils.toWei(req.body.amount));
                if (transferResult.Success == true) {
                    await updateUser({ _id: adminRes._id }, { adminTotalToken: adminRes.adminTotalToken - parseFloat(req.body.amount) })
                    let updateRes = await updateUser({ _id: userResult._id }, { bnbBalace: userResult.bnbBalace - (parseFloat(req.body.amount) - Number(bnbFee)) })
                    let obj = {
                        bnbBalace: updateRes.bnbBalace,
                        address: updateRes.bnbAccount.address
                    }
                    await createTransaction({
                        userId: userResult._id,
                        amount: req.body.amount,
                        fromAddress: adminRes.bnbAccount.address,
                        toAddress: req.body.walletAddress,
                        commission: bnbFee,
                        transactionType: "WITHDRAW_FOR_ADMIN",
                    })
                    let userTransaction = await createTransaction({
                        userId: adminRes._id,
                        amount: req.body.amount,
                        fromAddress: adminRes.bnbAccount.address,
                        toAddress: req.body.walletAddress,
                        commission: bnbFee,
                        transactionType: "WITHDRAW_FOR_USER",
                    })
                    let notificationObj = {
                        title: `Amount Withdraw!`,
                        description: `${req.body.amount} withdrawed from your account successfully.`,
                        userId: userResult._id,
                        notificationType: "AMOUNT_WITHDRAW",
                        transactionId: userTransaction._id
                    }
                    if (userResult.deviceToken) {
                        let message = {
                            to: userResult.deviceToken,
                            data: {
                                title: `Amount Withdraw!`,
                                body: `${req.body.amount} withdrawed from your account successfully.`,
                                userId: userResult._id,
                                notificationType: "AMOUNT_WITHDRAW",
                                transactionId: userTransaction._id,
                                sound: 'default'
                            },
                            notification: {
                                title: `Amount Withdraw!`,
                                body: `${req.body.amount} withdrawed from your account successfully.`,
                                sound: 'default'
                            }
                        };
                        await commonFunction.pushNotification(message)
                    }
                    await createNotification(notificationObj);
                    return res.json(new response(obj, responseMessage.WITHDRAW));
                }
                throw apiError.internal(responseMessage.BLOCKCHAIN_ERROR)
            }

        } catch (error) {
            console.log(error)
            return next(error);
        }
    }

    /**
   * @swagger
   * /user/HashTagSearchWithList:
   *   get:
   *     tags:
   *       - HASH TAG 
   *     description: HashTagSearchWithList
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: search
   *         description: search
   *         in: query
   *         required: false
   *       - name: fromDate
   *         description: fromDate
   *         in: query
   *         required: false
   *       - name: toDate
   *         description: toDate
   *         in: query
   *         required: false
   *       - name: page
   *         description: page
   *         in: query
   *         required: false
   *       - name: limit
   *         description: limit
   *         in: query
   *         required: false
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async HashTagSearchWithList(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional()
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let dataResults = await paginateHashTagSearch(validatedBody);
            if (dataResults.docs.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            return res.json(new response(dataResults, responseMessage.DATA_FOUND));
        } catch (error) {
            return next(error);
        }

    }


    /**
   * @swagger
   * /user/addHashTag:
   *   post:
   *     tags:
   *       - HASH TAG 
   *     description: addHashTag
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: token
   *         description: token
   *         in: header
   *         required: true
   *       - name: postId
   *         description: postId
   *         in: formData
   *         required: true
   *       - name: hashTagName
   *         description: hashTagName
   *         in: formData
   *         required: true
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async addHashTag(req, res, next) {
        const validationSchema = {
            postId: Joi.string().required(),
            hashTagName: Joi.string().required(),
        }
        try {
            const validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUserData({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let postRes = await findOnePost({ _id: validatedBody.postId, status: { $ne: status.DELETE } })
            if (!postRes) {
                throw apiError.notFound(responseMessage.POST_NOT_FOUND);
            }
            let hashTagRes = await findHashTag({ hashTagName: validatedBody.hashTagName, status: { $ne: status.DELETE } })
            if (!hashTagRes) {
                let obj = {
                    hashTagName: validatedBody.hashTagName,
                    postCount: 1,
                    userCount: 1,
                    postDetails: [{
                        postId: postRes._id,
                        userId: userResult._id
                    }]
                }
                let saveRes = await createHashTag(obj)
                await updatePost({ _id: postRes._id }, { $addToSet: { hashTagId: saveRes._id }, $inc: { hashTagCount: 1 } })
                return res.json(new response(saveRes, responseMessage.HASH_TAG));
            } else {
                await updatePost({ _id: postRes._id }, { $addToSet: { hashTagId: hashTagRes._id }, $inc: { hashTagCount: 1 } })
                let updatedRes = await updateHashTag({ _id: hashTagRes._id }, { $push: { postDetails: { $each: [{ postId: postRes._id, userId: userResult._id }] } }, $inc: { postCount: 1, userCount: 1 } });
                return res.json(new response(updatedRes, responseMessage.HASH_TAG));
            }
        } catch (error) {
            return next(error);
        }

    }


    /**
   * @swagger
   * /user/postListByHashTag:
   *   get:
   *     tags:
   *       - HASH TAG 
   *     description: postListByHashTag
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: token
   *         description: token
   *         in: header
   *         required: true
   *       - name: search
   *         description: search
   *         in: query
   *         required: false
   *       - name: page
   *         description: page
   *         in: query
   *         required: false
   *       - name: limit
   *         description: limit
   *         in: query
   *         required: false
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async postListByHashTag(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            limit: Joi.string().optional(),
            page: Joi.string().optional(),
        }
        try {
            let userResult = await findUserData({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            const paginateGood = (array, page_size, page_number) => {
                return array.slice((page_number - 1) * page_size, page_number * page_size);
            };
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let dataResults = await findHashTag({ hashTagName: validatedBody.search, status: { $ne: status.DELETE } });
            if (!dataResults) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            let options2 = {
                page: parseInt(req.query.page) || 1,
                limit: parseInt(req.query.limit) || 10,
            }
            let properResult = {
                docs: paginateGood(dataResults.postDetails, options2.limit, options2.page),
                total: dataResults.postDetails.length,
                limit: options2.limit,
                page: options2.page,
                pages: Math.ceil(dataResults.postDetails.length / options2.limit)
            }
            if (properResult.docs.length == 0) {
                throw apiError.notFound(responseMessage.POST_NOT_FOUND)
            }
            return res.json(new response(properResult, responseMessage.DATA_FOUND));
        } catch (error) {
            return next(error);
        }

    }

    /**
* @swagger
* /user/activityByCollection:
*   get:
*     tags:
*       - USER POSTS
*     description: activityByCollection
*     produces:
*       - application/json
*     parameters:
*       - name: token
*         description: token
*         in: header
*         required: true
*       - name: collectionId
*         description: _id of collection
*         in: query
*         required: true
*     responses:
*       200:
*         description: Returns success message
*/
    async activityByCollection(req, res, next) {
        const validationSchema = {
            collectionId: Joi.string().required()
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            validatedBody.userId = userResult._id;
            let dataResults = await findAllActivity(validatedBody);
            if (dataResults.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            return res.json(new response(dataResults, responseMessage.DATA_FOUND));
        } catch (error) {
            console.log('Catch error ==>', error)
            return next(error);
        }
    }


    /**
 * @swagger
 * /user/storyListWithFollowingReactNative:
 *   get:
 *     tags:
 *       - USER STORY
 *     description: storyListWithFollowingReactNative
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: token
 *         description: token
 *         in: header
 *         required: true
 *       - name: userId
 *         description: userId
 *         in: query
 *         required: true
 *     responses:
 *       200:
 *         description: Returns success message
 */
    async storyListWithFollowingReactNative(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId })
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                let data = await storyList({ userId: req.query.userId, visible: false, status: status.ACTIVE })
                if (data.length == 0) {
                    return res.json(new response(responseMessage.DATA_NOT_FOUND));
                } else {
                    let storyData = []
                    for (let i = 0; i < data.length; i++) {
                        storyData.push(data[i].story[0])
                    }
                    return res.json(new response(storyData, responseMessage.DATA_FOUND));
                }
            }
        } catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/addReels:
     *   post:
     *     tags:
     *       - USER REELS
     *     description: addReels
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: addReels
     *         description: addReels
     *         in: body
     *         required: true
     *         schema:
     *           $ref: '#/definitions/addReels'
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async addReels(req, res, next) {
        const validationSchema = {
            reelsurl: Joi.array().optional(),
            details: Joi.string().allow("").optional(),
            hashTagName: Joi.array().allow("").optional(),
        };
        try {
            const validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            } else {
                for (let i = 0; i < validatedBody.reelsurl.length; i++) {
                    validatedBody.reelsurl[i] = await commonFunction.getVideoUrl(validatedBody.reelsurl[i]);
                }
                validatedBody.userId = userResult._id;
                var saveResult = await createReels(validatedBody);
                let obj = {
                    title: "Add a new reels.",
                    desctiption: "You add a new reels on your profile.",
                    type: "REELS",
                    userId: userResult._id,
                    reelsId: saveResult._id,
                }
                await createActivity(obj);
                if (validatedBody.hashTagName.length != 0) {
                    for (let i = 0; i < validatedBody.hashTagName.length; i++) {
                        let hashTagRes = await findHashTag({ hashTagName: validatedBody.hashTagName[i], status: { $ne: status.DELETE } })
                        if (!hashTagRes) {
                            let obj = {
                                hashTagName: validatedBody.hashTagName[i],
                                reelsCount: 1,
                                userCount: 1,
                                reelsDetails: [{
                                    reelsId: saveResult._id,
                                }]
                            }
                            let saveRes = await createHashTag(obj)
                            var updateRes = await updateReels({ _id: saveResult._id }, { $addToSet: { hashTagId: saveRes._id }, $inc: { hashTagCount: 1 } })
                        } else {
                            var updateRes = await updateReels({ _id: saveResult._id }, { $addToSet: { hashTagId: hashTagRes._id }, $inc: { hashTagCount: 1 } })
                            await updateHashTag({ _id: hashTagRes._id }, { $push: { reelsDetails: { $each: [{ reelsId: saveResult._id }] } }, $inc: { postCount: 1, userCount: 1 } });
                        }
                    }
                    return res.json(new response(updateRes, responseMessage.REELS_ADDED));
                }
                return res.json(new response(saveResult, responseMessage.REELS_ADDED));
            }
        } catch (error) {
            console.log(error)
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/viewReels:
     *   get:
     *     tags:
     *       - USER REELS
     *     description: viewReels
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: reelsId
     *         description: reelsId
     *         in: query
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async viewReels(req, res, next) {
        const validationSchema = {
            reelsId: Joi.string().optional(),
        };
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            } else {
                let dataRes = await findReels({ _id: validatedBody.reelsId, status: { $ne: status.DELETE } })
                if (!dataRes) {
                    throw apiError.notFound(responseMessage.REELS_NOT_FOUND);
                }
                return res.json(new response(dataRes, responseMessage.REELS_FOUND));
            }
        } catch (error) {
            console.log(error)
            return next(error);
        }
    }
    /**
     * @swagger
     * /user/deleteReels:
     *   delete:
     *     tags:
     *       - USER REELS
     *     description: deleteReels
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: reelsId
     *         description: reelsId
     *         in: query
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async deleteReels(req, res, next) {
        const validationSchema = {
            reelsId: Joi.string().optional(),
        };
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            } else {
                let dataRes = await findReels({ _id: validatedBody.reelsId, userId: userResult._id, status: { $ne: status.DELETE } })
                if (!dataRes) {
                    throw apiError.notFound(responseMessage.REELS_NOT_FOUND);
                }
                let updateRes = await updateReels({ _id: dataRes._id }, { status: status.DELETE })
                return res.json(new response(updateRes, responseMessage.REELS_DELETE));
            }
        } catch (error) {
            console.log(error)
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/myReels:
     *   get:
     *     tags:
     *       - USER REELS
     *     description: myReels
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async myReels(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            } else {
                let dataRes = await reelsList({ userId: userResult._id, status: { $ne: status.DELETE } })
                if (dataRes.length == 0) {
                    throw apiError.notFound(responseMessage.REELS_NOT_FOUND);
                }
                return res.json(new response(dataRes, responseMessage.REELS_FOUND));
            }
        } catch (error) {
            console.log(error)
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/particularUserListReels:
     *   get:
     *     tags:
     *       - USER REELS
     *     description: particularUserListReels
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: userId
     *         description: userId
     *         in: query
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async particularUserListReels(req, res, next) {
        const validationSchema = {
            userId: Joi.string().optional(),
        };
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            } else {
                let dataRes = await reelsList({ userId: validatedBody.userId, status: { $ne: status.DELETE } })
                if (dataRes.length == 0) {
                    throw apiError.notFound(responseMessage.REELS_NOT_FOUND);
                }
                return res.json(new response(dataRes, responseMessage.REELS_FOUND));
            }
        } catch (error) {
            console.log(error)
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/createReportOnReels:
     *   post:
     *     tags:
     *       - USER REPORT
     *     description: createReportOnReels
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: createReportOnReels
     *         description: createReportOnReels
     *         in: body
     *         required: true
     *         schema:
     *           $ref: '#/definitions/createReportOnReels'
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async createReportOnReels(req, res, next) {
        const validationSchema = {
            reelsId: Joi.string().required(),
            message: Joi.string().required()
        }
        try {
            let validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            } else {
                let reelsRes = await findReels({ _id: validatedBody.reelsId, status: { $ne: status.DELETE } })
                if (!reelsRes) {
                    throw apiError.notFound(responseMessage.REELS_NOT_FOUND);
                }
                let reportCheck = await findReport({ userId: userResult._id, reelsId: reelsRes._id, actionApply: false });
                if (!reportCheck) {
                    let obj = {
                        userId: userResult._id,
                        userName: userResult.userName ? userResult.userName : "Unknown Name",
                        reelsId: reelsRes._id,
                        message: validatedBody.message,
                        type: "REELS"
                    }
                    let result = await createReport(obj);
                    let activityobj = {
                        title: "Reels report.",
                        reelsId: reelsRes._id,
                        desctiption: `Your reels are reported by user.`,
                        type: "REPORT",
                        userId: userResult._id,
                    }
                    await createActivity(activityobj);
                    await updateReels({ _id: reelsRes._id }, { $addToSet: { reportedId: result._id }, $inc: { reportCount: 1 } });
                    return res.json(new response(result, responseMessage.REPORTED));
                } else {
                    return res.json(new response([], responseMessage.ALREADY_REPORTED_REELS));
                }
            }
        } catch (error) {
            console.log("===error====", error)
            return next(error)

        }
    }

    /**
     * @swagger
     * /user/commentOnReels:
     *   post:
     *     tags:
     *       - USER REELS
     *     description: commentOnReels
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: reelsId
     *         description: reelsId
     *         in: formData
     *         required: true
     *       - name: message
     *         description: message
     *         in: formData
     *         required: false
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async commentOnReels(req, res, next) {
        const validationSchema = {
            reelsId: Joi.string().required(),
            message: Joi.string().optional(),
        }
        try {
            let update;
            const validatedBody = await Joi.validate(req.body, validationSchema);
            const { reelsId, message } = validatedBody;
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let reelsRes = await findReels({ _id: reelsId, status: { $ne: status.DELETE } })
            if (!reelsRes) {
                throw apiError.notFound(responseMessage.REELS_NOT_FOUND);
            } else {
                update = await updateReels({ _id: reelsRes._id }, { $push: { comment: { userId: userResult._id, message: message, time: new Date().toISOString(), } }, $inc: { totalComment: 1 } })
                var name = userResult.name || userResult.userName
                await createActivity({
                    userId: userResult._id,
                    reelsId: reelsRes._id,
                    title: "Reels comment",
                    desctiption: `${name} comment on this reels.`,
                    type: "COMMENT"
                })
                let reelsResult = await findReels({ _id: reelsId, userId: userResult._id, status: { $ne: status.DELETE } })
                if (reelsResult) {
                    return res.json(new response(update, responseMessage.COMMENT_ADDED));
                }
                await notificationDeleteMany({ userId: reelsRes.userId, notificationType: "REEL_COMMENT", reelsId: reelsRes._id, commentBy: userResult._id })
                let notificationObj = {
                    title: `Comment on reels! `,
                    description: `${name} has comment on your reels.`,
                    userId: reelsRes.userId,
                    notificationType: "REEL_COMMENT",
                    reelsId: reelsRes._id,
                    commentBy: userResult._id
                }
                await createNotification(notificationObj);
                return res.json(new response(update, responseMessage.COMMENT_ADDED));
            }
        } catch (error) {
            return next(error);
        }
    }


    /**
 * @swagger
 * /user/likeDislikeReels/{reelsId}:
 *   get:
 *     tags:
 *       - USER REELS
 *     description: likeDislikeReels
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: token
 *         description: token
 *         in: header
 *         required: true
 *       - name: reelsId
 *         description: reelsId
 *         in: path
 *         required: true
 *     responses:
 *       200:
 *         description: Returns success message
 */
    async likeDislikeReels(req, res, next) {
        const validationSchema = {
            reelsId: Joi.string().required(),
        }
        var updated;
        try {
            const { reelsId } = await Joi.validate(req.params, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let reelsRes = await findReels({ _id: reelsId, status: { $ne: status.DELETE } });
            if (!reelsRes) {
                throw apiError.notFound(responseMessage.REELS_NOT_FOUND);
            }
            if (reelsRes.likesUsers.includes(userResult._id)) {
                updated = await updateReels({ _id: reelsRes._id }, { $pull: { likesUsers: userResult._id }, $inc: { likesCount: -1 } });
                await updateUser({ _id: userResult._id }, { $pull: { likesReels: reelsRes._id } });
                await createActivity({
                    userId: userResult._id,
                    reelsId: reelsRes._id,
                    title: "Dislike reels",
                    desctiption: "Bad choice, I disliked it.",
                    type: "DISLIKE"
                })
                return res.json(new response(updated, responseMessage.DISLIKES));
            } else {
                await createActivity({
                    userId: userResult._id,
                    reelsId: reelsRes._id,
                    title: "Like reels",
                    desctiption: "Nice choice, I liked it.",
                    type: "LIKE"
                })
                var name = userResult.name || userResult.userName
                let reelsResult = await findReels({ _id: reelsId, userId: userResult._id, status: { $ne: status.DELETE } });
                if (reelsResult) {
                    updated = await updateReels({ _id: reelsRes._id }, { $addToSet: { likesUsers: userResult._id }, $inc: { likesCount: 1 } });
                    await updateUser({ _id: userResult._id }, { $addToSet: { likesReels: reelsRes._id } });
                    return res.json(new response(updated, responseMessage.LIKES));
                }
                await notificationDeleteMany({ userId: reelsRes.userId, notificationType: "REEL_LIKE", likeBy: userResult._id, reelsId: reelsRes._id })
                await createNotification({
                    title: `Like reels`,
                    description: `${name} likes your reels.`,
                    userId: reelsRes.userId,
                    notificationType: "REEL_LIKE",
                    likeBy: userResult._id,
                    reelsId: reelsRes._id
                });
                let userResDeviceToken = await findUser({ _id: reelsRes.userId })
                if (userResDeviceToken.deviceToken) {
                    let message = {
                        to: userResDeviceToken.deviceToken,
                        data: {
                            title: `Like reels`,
                            body: `${name} likes your reels.`,
                            userId: reelsRes.userId,
                            notificationType: "REEL_LIKE",
                            likeBy: userResult._id,
                            reelsId: reelsRes._id,
                            sound: 'default'
                        },
                        notification: {
                            title: `Like reels`,
                            body: `${name} likes your reels.`,
                            sound: 'default'
                        }
                    };
                    await commonFunction.pushNotification(message)
                }
                updated = await updateReels({ _id: reelsRes._id }, { $addToSet: { likesUsers: userResult._id }, $inc: { likesCount: 1 } });
                await updateUser({ _id: userResult._id }, { $addToSet: { likesReels: reelsRes._id } });
                return res.json(new response(updated, responseMessage.LIKES));
            }
        }
        catch (error) {
            console.log(error)
            if (error == 'NotRegistered') {
                error = { message: 'Device token not registered on server.' }
            }
            return next(error);
        }
    }

    /**
   * @swagger
   * /user/postReelsListByHashTag:
   *   get:
   *     tags:
   *       - USER REELS 
   *     description: postReelsListByHashTag
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: token
   *         description: token
   *         in: header
   *         required: true
   *       - name: search
   *         description: search
   *         in: query
   *         required: false
   *       - name: page
   *         description: page
   *         in: query
   *         required: false
   *       - name: limit
   *         description: limit
   *         in: query
   *         required: false
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async postReelsListByHashTag(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            limit: Joi.string().optional(),
            page: Joi.string().optional(),
        }
        try {
            let userResult = await findUserData({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            const paginateGood = (array, page_size, page_number) => {
                return array.slice((page_number - 1) * page_size, page_number * page_size);
            };
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let dataResults = await findHashTag({ hashTagName: validatedBody.search, status: { $ne: status.DELETE } });
            if (!dataResults) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            let options2 = {
                page: parseInt(req.query.page) || 1,
                limit: parseInt(req.query.limit) || 10,
            }
            Array.prototype.push.apply(dataResults.postDetails, dataResults.reelsDetails)
            let properResult = {
                docs: paginateGood(dataResults.postDetails, options2.limit, options2.page),
                total: dataResults.postDetails.length,
                limit: options2.limit,
                page: options2.page,
                pages: Math.ceil(dataResults.postDetails.length / options2.limit)
            }
            if (properResult.docs.length == 0) {
                throw apiError.notFound(responseMessage.POST_NOT_FOUND)
            }
            return res.json(new response(properResult, responseMessage.DATA_FOUND));
        } catch (error) {
            return next(error);
        }

    }

    /**
  * @swagger
  * /user/likeDislikeCommentOnReels:
  *   get:
  *     tags:
  *       - USER REELS
  *     description: likeDislikeCommentOnReels
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: token
  *         description: token
  *         in: header
  *         required: true
  *       - name: reelsId
  *         description: reelsId
  *         in: query
  *         required: true
  *       - name: commentId 
  *         description: commentId ? _id
  *         in: query
  *         required: true
  *     responses:
  *       200:
  *         description: Returns success message
  */
    async likeDislikeCommentOnReels(req, res, next) {
        const validationSchema = {
            commentId: Joi.string().required(),
            reelsId: Joi.string().required(),
        }
        var updated;
        try {
            const { commentId, reelsId } = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let reelsRes = await findReels({ _id: reelsId, "comment._id": commentId, status: { $ne: status.DELETE } });
            if (!reelsRes) {
                throw apiError.notFound(responseMessage.REELS_NOT_FOUND);
            }
            for (let i in reelsRes.comment) {
                if (reelsRes.comment[i]._id == commentId) {
                    if (reelsRes.comment[i].likesUsers.includes(userResult._id) == true) {
                        updated = await updateReels({ _id: reelsRes._id, "comment._id": commentId }, { $pull: { 'comment.$.likesUsers': userResult._id }, $inc: { 'comment.$.likesCount': -1 } });
                        await updateUser({ _id: userResult._id }, { $pull: { likesCommentOnReelsId: commentId } });
                        return res.json(new response(updated, responseMessage.DISLIKES));
                    } else {
                        var name = userResult.name || userResult.userName
                        let reelsResult = await findReels({ _id: reelsId, userId: userResult._id, status: { $ne: status.DELETE } });
                        if (reelsResult) {
                            updated = await updateReels({ _id: reelsRes._id, "comment._id": commentId }, { $addToSet: { 'comment.$.likesUsers': userResult._id }, $inc: { 'comment.$.likesCount': 1 } });
                            await updateUser({ _id: userResult._id }, { $addToSet: { likesCommentOnReelsId: commentId } });
                            return res.json(new response(updated, responseMessage.LIKES));
                        }
                        await notificationDeleteMany({ userId: reelsRes.userId, notificationType: "REEL_LIKE", likeBy: userResult._id, reelsId: reelsRes._id })
                        await createNotification({
                            title: `Like comment on reels!`,
                            description: `${name} likes your reels.`,
                            userId: reelsRes.userId,
                            notificationType: "REEL_LIKE",
                            likeBy: userResult._id,
                            reelsId: reelsRes._id
                        });
                        let userResDeviceToken = await findUser({ _id: reelsRes.userId })
                        if (userResDeviceToken.deviceToken) {
                            let message = {
                                to: userResDeviceToken.deviceToken,
                                data: {
                                    title: `Like comment on reels!`,
                                    body: `${name} likes your reels.`,
                                    userId: reelsRes.userId,
                                    notificationType: "REEL_LIKE",
                                    likeBy: userResult._id,
                                    reelsId: reelsRes._id,
                                    sound: 'default'
                                },
                                notification: {
                                    title: `Like comment on reels!`,
                                    body: `${name} likes your reels.`,
                                    sound: 'default'
                                }
                            };
                            await commonFunction.pushNotification(message)
                        }
                        updated = await updateReels({ _id: reelsRes._id, "comment._id": commentId }, { $addToSet: { 'comment.$.likesUsers': userResult._id }, $inc: { 'comment.$.likesCount': 1 } });
                        await updateUser({ _id: userResult._id }, { $addToSet: { likesCommentOnReelsId: commentId } });
                        return res.json(new response(updated, responseMessage.LIKES));
                    }
                }
            }

        }
        catch (error) {
            console.log(error)
            if (error == 'NotRegistered') {
                error = { message: 'Device token not registered on server.' }
            }
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/commentReplyOnReels:
     *   post:
     *     tags:
     *       - USER REELS
     *     description: commentReplyOnReels
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: reelsId
     *         description: reelsId
     *         in: formData
     *         required: true
     *       - name: commentId
     *         description: commentId
     *         in: formData
     *         required: true
     *       - name: message
     *         description: message
     *         in: formData
     *         required: false
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async commentReplyOnReels(req, res, next) {
        const validationSchema = {
            reelsId: Joi.string().required(),
            message: Joi.string().optional(),
            commentId: Joi.string().optional(),
        }
        try {
            let update;
            const validatedBody = await Joi.validate(req.body, validationSchema);
            const { reelsId, message, commentId } = validatedBody;
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let reelsRes = await findReels({ _id: reelsId, status: { $ne: status.DELETE } })
            if (!reelsRes) {
                throw apiError.notFound(responseMessage.REELS_NOT_FOUND);
            } else {
                let obj = {
                    userId: userResult._id,
                    commentId: commentId,
                    message: message,
                    time: new Date().toISOString(),
                }
                update = await updateReels({ _id: reelsRes._id, "comment._id": commentId }, { $push: { 'comment.$.reply': obj }, $inc: { "comment.$.totalReply": 1 } })
                var name = userResult.name || userResult.userName
                await createActivity({
                    userId: userResult._id,
                    reelsId: reelsRes._id,
                    title: "Reels comment reply",
                    desctiption: `${name} reply on your comment on this reels.`,
                    type: "COMMENT_REPLY"
                })
                let reelsResult = await findReels({ _id: reelsId, userId: userResult._id, status: { $ne: status.DELETE } })
                if (reelsResult) {
                    return res.json(new response(update, responseMessage.REPLY_COMMENT));
                }
                await notificationDeleteMany({ userId: reelsRes.userId, notificationType: "REEL_COMMENT", reelsId: reelsRes._id, commentBy: userResult._id })
                let notificationObj = {
                    title: `Reply on comment on reels!`,
                    description: `${name} has comment on your reels.`,
                    userId: reelsRes.userId,
                    notificationType: "REEL_COMMENT",
                    reelsId: reelsRes._id,
                    commentBy: userResult._id
                }
                await createNotification(notificationObj);
                return res.json(new response(update, responseMessage.REPLY_COMMENT));
            }
        } catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/reelsList:
     *   get:
     *     tags:
     *       - USER REELS
     *     description: reelsList
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: page
     *         description: page
     *         in: query
     *         required: false
     *       - name: limit
     *         description: limit
     *         in: query
     *         required: false
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async reelsList(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            } else {
                let dataRes = await paginateSearchReels(req.query)
                if (dataRes.docs.length == 0) {
                    throw apiError.notFound(responseMessage.REELS_NOT_FOUND);
                }
                return res.json(new response(dataRes, responseMessage.REELS_FOUND));
            }
        } catch (error) {
            console.log(error)
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/reelsShare:
     *   get:
     *     tags:
     *       - USER REELS
     *     description: reelsShare
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: reelsId
     *         description: reelsId
     *         in: query
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async reelsShare(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            } else {
                let dataRes = await findReels({ _id: req.query.reelsId, status: { $ne: status.DELETE } })
                if (!dataRes) {
                    throw apiError.notFound(responseMessage.REELS_NOT_FOUND);
                }
                let urlRes = `${baseUrl}/api/v1/user/getShareReels/${dataRes._id}`
                await updateReels({ _id: dataRes._id }, { $push: { reelsShareUserId: userResult._id } }, { $inc: { reelsShareCount: 1 } })
                return res.json(new response(urlRes, responseMessage.REELS_FOUND));
            }
        } catch (error) {
            console.log(error)
            return next(error);
        }
    }

    /**
 * @swagger
 * /user/getShareReels/{reelsId}:
 *   get: 
 *     tags:
 *       - USER REELS
 *     description: getShareReels
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: reelsId
 *         description: reelsId
 *         in: path
 *         required: true
 *     responses:
 *       200:
 *         description: Returns success message
 */
    async getShareReels(req, res, next) {
        const validationSchema = {
            reelsId: Joi.string().required(),
        }
        try {
            const { reelsId } = await Joi.validate(req.params, validationSchema);
            let reelsRes = await findReels({ _id: reelsId, status: { $ne: status.DELETE } });
            if (!reelsRes) {
                throw apiError.notFound(responseMessage.REELS_NOT_FOUND);
            }
            return res.json(new response(reelsRes, responseMessage.REELS_FOUND));
        }
        catch (error) {
            console.log(error)
            return next(error);
        }
    }

    /**
      * @swagger
      * /user/addRemoveToWatchList:
      *   post:
      *     tags:
      *       -  USER 
      *     description: addRemoveToWatchList
      *     produces:
      *       - application/json
      *     parameters:
      *       - name: token
      *         description: token
      *         in: header
      *         required: true
      *       - name: postId
      *         description: postId
      *         in: formData
      *         required: true
      *     responses:
      *       200:
      *         description: Returns success message
      */
    async addRemoveToWatchList(req, res, next) {
        const validationSchema = {
            postId: Joi.string().required()
        }
        try {
            const validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult1 = await findUser({ _id: req.userId })
            if (!userResult1) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                var postCheck = await findOnePost({ _id: validatedBody.postId, status: { $ne: status.DELETE } });
                if (postCheck) {
                    var userWatchRes = await findUser({ _id: userResult1._id, myWatchlist: postCheck._id });
                    if (userWatchRes) {
                        var updateResult = await updateUserById({ _id: userResult1._id }, { $pull: { myWatchlist: postCheck._id } });
                        return res.json(new response(updateResult, responseMessage.WATCHLIST_REMOVE));
                    } else {
                        var updateResult = await updateUserById({ _id: userResult1._id }, { $push: { myWatchlist: postCheck._id } });
                        return res.json(new response(updateResult, responseMessage.WATCHLIST_CREATE));
                    }
                } else {
                    throw apiError.notFound(responseMessage.POST_NOT_FOUND)
                }
            }
        } catch (error) {
            console.log(error)
            return next(error)
        }
    }

    /**
    * @swagger
    * /user/walletTransactionList:
    *   get:
    *     tags:
    *       - USER 
    *     description: walletTransactionList
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: token
    *         description: token
    *         in: header
    *         required: true
    *       - name: transactionType
    *         description: transactionType
    *         enum: ["DEPOSIT_FOR_ADMIN","WITHDRAW_FOR_ADMIN"]
    *         in: query
    *         required: false
    *       - name: fromDate
    *         description: fromDate
    *         in: query
    *         required: false
    *       - name: toDate
    *         description: toDate
    *         in: query
    *         required: false
    *       - name: page
    *         description: page
    *         in: query
    *         required: false
    *       - name: limit
    *         description: limit
    *         in: query
    *         required: false
    *     responses:
    *       200:
    *         description: Returns success message
    */
    async walletTransactionList(req, res, next) {
        const validationSchema = {
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.string().optional(),
            limit: Joi.string().optional(),
            transactionType: Joi.string().optional(),
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE }, userType: userType.USER });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            validatedBody.userId = userResult._id
            let data = await paginateWalletTransactionSearch(validatedBody)
            if (data.docs.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            } else {
                return res.json(new response(data, responseMessage.DATA_FOUND));
            }
        } catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/postShare:
     *   get:
     *     tags:
     *       - USER REELS
     *     description: reelsShare
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: postId
     *         description: postId
     *         in: query
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async postShare(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            } else {
                let dataRes = await findOnePost({ _id: req.query.postId, status: { $ne: status.DELETE } })
                if (!dataRes) {
                    throw apiError.notFound(responseMessage.REELS_NOT_FOUND);
                }
                await createActivity({
                    userId: userResult._id,
                    postId: dataRes._id,
                    title: "Post share.",
                    desctiption: 'Post shared successfully.',
                    type: "SHARE"
                })
                let urlRes = `https://social-platform.mobiloitte.org/comment?${dataRes._id}`
                await updateReels({ _id: dataRes._id }, { $push: { reelsShareUserId: userResult._id } }, { $inc: { reelsShareCount: 1 } })
                return res.json(new response(urlRes, responseMessage.POST_SHARE));
            }
        } catch (error) {
            console.log(error)
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/searchUserNameForsignUpTime:
     *   get:
     *     tags:
     *       - USER 
     *     description: searchUserNameForsignUpTime
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: search
     *         description: search
     *         in: query
     *         required: false
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async searchUserNameForsignUpTime(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
        }
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let data = await userNameSearchforsignuptime(validatedBody)
            if (data.docs.length == 0) {
                throw apiError.notFound(responseMessage.USERNAME_AVAILABLE);
            } else {
                return res.json(new response(data, responseMessage.USERNAME_ALREADY_EXITS));
            }
        } catch (error) {
            return next(error);
        }
    }

    /**
       * @swagger
       * /user/userSubscriberList:
       *   get:
       *     tags:
       *       - USER 
       *     description: userSubscriberList
       *     produces:
       *       - application/json
       *     parameters:
       *       - name: token
       *         description: token
       *         in: header
       *         required: true
       *     responses:
       *       200:
       *         description: Returns success message
       */
    async userSubscriberList(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            var collection_Res = await userCollectionListAll({ userId: userResult._id });
            collection_Res = collection_Res.map(i => i._id)
            let subscription_res = await userSubscribeCollectionList({ collectionId: { $in: collection_Res } });
            if (subscription_res.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            }
            return res.json(new response(subscription_res, responseMessage.DATA_FOUND));

        } catch (error) {
            console.log("=error==", error)
            return next(error);

        }
    }

    /**
         * @swagger
         * /user/userCollectionSubscriberLists:
         *   get:
         *     tags:
         *       - USER 
         *     description: userCollectionSubscriberLists
         *     produces:
         *       - application/json
         *     parameters:
         *       - name: token
         *         description: token
         *         in: header
         *         required: true
         *     responses:
         *       200:
         *         description: Returns success message
         */
    async userCollectionSubscriberLists(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            var collection_Res = await userCollectionListAll({ userId: userResult._id });
            collection_Res = collection_Res.map(i => i._id)
            let subscription_res = await userSubscribeCollectionList({ collectionId: { $in: collection_Res } });
            if (subscription_res.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            }
            var dataArr = subscription_res.map(item => {
                return [item.userId, item]
            });
            var maparr = new Map(dataArr);
            var result = [...maparr.values()];
            var finalData = []
            for (let i = 0; i < result.length; i++) {
                finalData.push(result[i].userId)
            }
            return res.json(new response(finalData, responseMessage.DATA_FOUND));

        } catch (error) {
            console.log("=error==", error)
            return next(error);

        }
    }


    /**
      * @swagger
      * /user/saveReels:
      *   post:
      *     tags:
      *       -  USER REELS 
      *     description: saveReels
      *     produces:
      *       - application/json
      *     parameters:
      *       - name: token
      *         description: token
      *         in: header
      *         required: true
      *       - name: reelsId
      *         description: reelsId
      *         in: formData
      *         required: true
      *     responses:
      *       200:
      *         description: Returns success message
      */
    async saveReels(req, res, next) {
        const validationSchema = {
            reelsId: Joi.string().required()
        }
        try {
            const validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult1 = await findUser({ _id: req.userId })
            if (!userResult1) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND)
            } else {
                var reelsCheck = await findReels({ _id: validatedBody.reelsId, status: { $ne: status.DELETE } });
                if (reelsCheck) {
                    var userReelsRes = await findUser({ _id: userResult1._id, saveReels: reelsCheck._id });
                    if (userReelsRes) {
                        var updateResult = await updateUserById({ _id: userResult1._id }, { $pull: { saveReels: reelsCheck._id } });
                        return res.json(new response(updateResult, responseMessage.REELS_REMOVE));
                    } else {
                        var updateResult = await updateUserById({ _id: userResult1._id }, { $push: { saveReels: reelsCheck._id } });
                        return res.json(new response(updateResult, responseMessage.REELS_SAVE));
                    }
                } else {
                    throw apiError.notFound(responseMessage.REELS_NOT_FOUND)
                }
            }
        } catch (error) {
            console.log(error)
            return next(error)
        }
    }

    /**
    * @swagger
    * /user/reactOnPostPromoted/{promotedId}:
    *   get:
    *     tags:
    *       - POST PROMOTION
    *     description: reactOnPostPromoted
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: token
    *         description: token
    *         in: header
    *         required: true
    *       - name: promotedId
    *         description: promotedId
    *         in: path
    *         required: true
    *       - name: emoji
    *         description: emoji
    *         in: query
    *         required: true
    *     responses:
    *       200:
    *         description: Returns success message
    */
    async reactOnPostPromoted(req, res, next) {
        const validationSchema = {
            promotedId: Joi.string().required()
        }
        var updated;
        try {
            const { promotedId } = await Joi.validate(req.params, validationSchema);
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                collectionPostId
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let promoteRes = await findPostPromotion({ _id: promotedId, status: { $ne: status.DELETE } });
            if (!promoteRes) {
                throw apiError.notFound(responseMessage.POST_NOT_PROMOTION);
            }
            if (promoteRes.reactOnPostPromoted.some(o => { return o.userId == userResult._id.toString() }) == true) {
                let update = await updatePostPromotion({ _id: promoteRes._id, 'reactOnPostPromoted.userId': userResult._id }, { 'reactOnPostPromoted.$.emoji': req.query.emoji });
                await createActivity({
                    userId: userResult._id,
                    postPromotionId: promoteRes._id,
                    title: "React On promoted.",
                    desctiption: `React ${req.query.emoji} on promoted.`,
                    type: "LIKE"
                })
                return res.json(new response(update, responseMessage.EMOJI_REACT));
            }
            else {
                let add = await updatePostPromotion({ _id: promoteRes._id }, {
                    $addToSet: {
                        reactOnPostPromoted: {
                            userId: userResult._id,
                            emoji: req.query.emoji
                        }
                    }, $inc: { reactOnPostPromotedCount: +1 }
                });
                await createActivity({
                    userId: userResult._id,
                    postPromotionId: promoteRes._id,
                    title: "React On promoted.",
                    desctiption: `React ${req.query.emoji} on promoted.`,
                    type: "LIKE"
                })
                return res.json(new response(add, responseMessage.EMOJI_REACT));
            }
        }
        catch (error) {
            return next(error);
        }
    }

    /**
   * @swagger
   * /user/hide_unhidePost:
   *   put:
   *     tags:
   *       - USER POSTS
   *     description: hide_unhidePost
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: token
   *         description: token
   *         in: header
   *         required: true
   *       - name: postId
   *         description: postId
   *         in: formData
   *         required: true
   *     responses:
   *       200:
   *         description: Returns success message
   */
    async hide_unhidePost(req, res, next) {
        const validationSchema = {
            postId: Joi.string().required(),
        }
        try {
            let update;
            const { postId } = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let postRes = await findOnePost({ _id: postId, status: { $ne: status.DELETE } });
            if (!postRes) {
                throw apiError.notFound(responseMessage.POST_NOT_EXIST);
            } else {
                if (userResult.hidePost.includes(postRes._id)) {
                    update = await updateUser({ _id: userResult._id }, { $pull: { hidePost: postRes._id } });
                    await createActivity({
                        userId: userResult._id,
                        postId: postRes._id,
                        title: "Post hide",
                        desctiption: "User change his post status.",
                        type: "HIDE"
                    })
                    return res.json(new response(update, responseMessage.UNHIDE_POST));
                } else {
                    update = await updateUser({ _id: userResult._id }, { $addToSet: { hidePost: postRes._id } })
                    await createActivity({
                        userId: userResult._id,
                        postId: postRes._id,
                        title: "Post unhide",
                        desctiption: "User change his post status.",
                        type: "UNHIDE"
                    })
                    return res.json(new response(update, responseMessage.HIDE_POST));
                }

            }

        } catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/deleteCommentReplyOnPostPromotion:
     *   delete:
     *     tags:
     *       - POST PROMOTION
     *     description: deleteCommentReplyOnPostPromotion
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: postPromotionId
     *         description: postPromotionId
     *         in: formData
     *         required: true
     *       - name: commentId
     *         description: commentId
     *         in: formData
     *         required: true
     *       - name: commentReplyId
     *         description: commentReplyId
     *         in: formData
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async deleteCommentReplyOnPostPromotion(req, res, next) {
        const validationSchema = {
            postPromotionId: Joi.string().required(),
            commentId: Joi.string().required(),
            commentReplyId: Joi.string().required(),
        }
        try {
            let update;
            const validatedBody = await Joi.validate(req.body, validationSchema);
            const { postPromotionId, commentId, commentReplyId } = validatedBody;
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let postPromotionCheck = await findPostPromotion({ _id: postPromotionId, 'comment._id': commentId, 'comment.reply._id': commentReplyId, status: { $ne: status.DELETE } });
            if (!postPromotionCheck) {
                throw apiError.notFound(responseMessage.COMMENT_NOT_EXIST);
            } else {
                let deleteComment = await updatePostPromotion({ _id: postPromotionCheck._id, 'comment._id': validatedBody.commentId }, { $pull: { "comment.$.reply": { _id: validatedBody.commentReplyId } }, $inc: { 'comment.$.totalReply': -1 } });
                return res.json(new response(deleteComment, responseMessage.COMMENT_DELETE_SUCCESS));
            }
        } catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/deleteCommentOnPostPromotion:
     *   delete:
     *     tags:
     *       - POST PROMOTION
     *     description: deleteCommentOnPostPromotion
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: postPromotionId
     *         description: postPromotionId
     *         in: formData
     *         required: true
     *       - name: commentId
     *         description: commentId
     *         in: formData
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async deleteCommentOnPostPromotion(req, res, next) {
        const validationSchema = {
            postPromotionId: Joi.string().required(),
            commentId: Joi.string().required(),
        }
        try {
            let update;
            const validatedBody = await Joi.validate(req.body, validationSchema);
            const { postPromotionId, commentId } = validatedBody;
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let postPromotionCheck = await findPostPromotion({ _id: postPromotionId, 'comment._id': commentId, status: { $ne: status.DELETE } });
            if (!postPromotionCheck) {
                throw apiError.notFound(responseMessage.COMMENT_NOT_EXIST);
            } else {
                let deleteComment = await deletePostPromotionComment(validatedBody);
                return res.json(new response(deleteComment, responseMessage.COMMENT_DELETE_SUCCESS));
            }
        } catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/offLineUser:
     *   get:
     *     tags:
     *       - USER
     *     description: offLineUser
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async offLineUser(req, res, next) {
        try {
            let userResult = await findUserData({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let updateRes = await updateUser({ _id: userResult._id }, { isOnline: false });
            return res.json(new response(updateRes, responseMessage.OFFLINE));
        } catch (error) {
            return next(error);
        }
    }

    /**
 * @swagger
 * /user/listFollowingUserStory:
 *   get:
 *     tags:
 *       - USER
 *     description: listFollowingUserStory
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: token
 *         description: token
 *         in: header
 *         required: true
 *     responses:
 *       200:
 *         description: Returns success message
 */
    async listFollowingUserStory(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let following = [];
            if (userResult.isStory == true) {
                following.push(userResult)
            }
            for (let element of userResult.following) {
                let userResult1 = await findUser({ _id: element });
                following.push(userResult1)
            }
            let obj = {
                following: following,
                count: userResult.following.length
            }
            return res.json(new response(obj, responseMessage.DATA_FOUND));
        }
        catch (error) {
            return next(error);
        }

    }
    /**
     * @swagger
     * /user/deleteCommentOnReels:
     *   delete:
     *     tags:
     *       - USER REELS
     *     description: deleteCommentOnReels
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: reelsId
     *         description: reelsId
     *         in: formData
     *         required: true
     *       - name: commentId
     *         description: commentId
     *         in: formData
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async deleteCommentOnReels(req, res, next) {
        const validationSchema = {
            reelsId: Joi.string().required(),
            commentId: Joi.string().required(),
        }
        try {
            let update;
            const validatedBody = await Joi.validate(req.body, validationSchema);
            const { reelsId, commentId } = validatedBody;
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let reelsCheck = await findReels({ _id: reelsId, 'comment._id': commentId, status: { $ne: status.DELETE } });
            if (!reelsCheck) {
                throw apiError.notFound(responseMessage.REELS_NOT_FOUND);
            } else {
                let deleteComment = await deleteReelsComment(validatedBody);
                return res.json(new response(deleteComment, responseMessage.COMMENT_DELETE_SUCCESS));
            }
        } catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/deleteCommentReplyOnReels:
     *   delete:
     *     tags:
     *       - USER REELS
     *     description: deleteCommentReplyOnReels
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: reelsId
     *         description: reelsId
     *         in: formData
     *         required: true
     *       - name: commentId
     *         description: commentId
     *         in: formData
     *         required: true
     *       - name: commentReplyId
     *         description: commentReplyId
     *         in: formData
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async deleteCommentReplyOnReels(req, res, next) {
        const validationSchema = {
            reelsId: Joi.string().required(),
            commentId: Joi.string().required(),
            commentReplyId: Joi.string().required(),
        }
        try {
            let update;
            const validatedBody = await Joi.validate(req.body, validationSchema);
            const { reelsId, commentId, commentReplyId } = validatedBody;
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let reelsCheck = await findReels({ _id: reelsId, 'comment._id': commentId, 'comment.reply._id': commentReplyId, status: { $ne: status.DELETE } });
            if (!reelsCheck) {
                throw apiError.notFound(responseMessage.COMMENT_NOT_EXIST);
            } else {
                let deleteComment = await updateReels({ _id: reelsCheck._id, 'comment._id': validatedBody.commentId }, { $pull: { "comment.$.reply": { _id: validatedBody.commentReplyId } }, $inc: { 'comment.$.totalReply': -1 } });
                return res.json(new response(deleteComment, responseMessage.COMMENT_DELETE_SUCCESS));
            }
        } catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/refferralAfterSocialLogin:
     *   get:
     *     tags:
     *       - USER
     *     description: profile
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: refereeCode
     *         description: refereeCode
     *         in: query
     *         required: false
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async refferralAfterSocialLogin(req, res, next) {
        try {
            let userResult = await findUserData({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let [feeRes, referralRes, adminRes, referralUserRes] = await Promise.all([
                findFee({ type: "SIGNUP", status: { $ne: status.DELETE } }),
                findFee({ type: "REFERREL", status: { $ne: status.DELETE } }),
                findUser({ userType: userType.ADMIN, status: { $ne: status.DELETE } }),
                findUser({ referralCode: req.query.refereeCode, _id: { $ne: userResult._id }, status: status.ACTIVE })])
            // if (Number(feeRes.amount) > Number(adminRes.bnbBalace)) {
            //     throw apiError.badRequest(responseMessage.ADMIN_LOW_BALANCE)
            // }
            if (req.query.refereeCode) {
                if (!referralUserRes) {
                    throw apiError.badRequest(responseMessage.REFERRAL);
                }
                //     if (Number(referralRes.amount) > Number(adminRes.bnbBalace)) {
                //         throw apiError.badRequest(responseMessage.ADMIN_LOW_BALANCE)
                //     }
            }

            if (req.query.refereeCode) {
                // await createTransaction({
                //     userId: adminRes._id,
                //     amount: Number(referralRes.amount),
                //     transactionType: "REFERRAL_FOR_ADMIN"
                // })
                await createTransaction({
                    userId: referralUserRes._id,
                    amount: Number(referralRes.amount),
                    transactionType: "REFERRAL_FOR_USER"
                })
                await Promise.all([
                    // updateUser({ _id: adminRes._id }, { bnbBalace: Number(adminRes.bnbBalace) - Number(referralRes.amount) }),
                    updateUser({ _id: referralUserRes._id }, { bnbBalace: Number(referralUserRes.bnbBalace) + Number(referralRes.amount), refferralBonus: Number(referralUserRes.refferralBonus) + Number(referralRes.amount) })])
            }
            // await createTransaction({
            //     userId: adminRes._id,
            //     amount: Number(feeRes.amount),
            //     transactionType: "SIGNUP_FOR_ADMIN"
            // })
            await createTransaction({
                userId: userResult._id,
                amount: Number(feeRes.amount),
                transactionType: "SIGNUP_FOR_USER"
            })
            await Promise.all([
                // updateUser({ _id: adminRes._id }, { bnbBalace: Number(adminRes.bnbBalace) - Number(feeRes.amount) }),
                updateUser({ _id: userResult._id }, { bnbBalace: Number(userResult.bnbBalace) + Number(feeRes.amount), signupBonus: Number(userResult.signupBonus) + Number(feeRes.amount) })])
            return res.json(new response({}, responseMessage.LOGIN));
        } catch (error) {
            console.log(error)
            return next(error);
        }
    }

    /**
     * @swagger
     * /user/userDashboard:
     *   get:
     *     tags:
     *       - USER
     *     description: userDashboard
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async userDashboard(req, res, next) {
        try {
            let userResult = await findUserData({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let referralRes = await findCount({ refereeCode: userResult.referralCode, status: { $ne: status.DELETE } })
            let obj = {
                tatalSignupBonus: userResult.signupBonus,
                totalrefferralBonus: userResult.refferralBonus,
                totalReferralUser: referralRes
            }
            return res.json(new response(obj, responseMessage.DATA_FOUND));
        } catch (error) {
            return next(error);
        }
    }


}
export default new userController()

const createChatFostoryrMember = async (senderId, receiverId, message) => {
    let req = {
        senderId: senderId,
        receiverId: receiverId
    };
    var query = { clearStatus: false }, chatQuery = {};
    if (senderId && receiverId) {
        query.$and = [{ $or: [{ senderId: senderId }, { senderId: receiverId }] }, { $or: [{ receiverId: receiverId }, { receiverId: senderId }] }]
    }
    let result = await chatSchema.findOne(query);
    if (!result) {
        req.messages = [{
            message: message,
            mediaType: "text",
            receiverId: receiverId,
            createdAt: new Date().toISOString()
        }]
        await new chatSchema(req).save();
    } else {
        req.messages = [{
            message: message,
            mediaType: "text",
            receiverId: receiverId,
            createdAt: new Date().toISOString()
        }]
        await chatSchema.findOneAndUpdate({ _id: result._id }, { $push: { messages: req } }, { new: true });
    }
}

const createChatForMember = async (senderId, receiverId) => {
    let req = {
        senderId: senderId,
        receiverId: receiverId
    };
    var query = { clearStatus: false }, chatQuery = {};
    if (senderId && receiverId) {
        query.$and = [{ $or: [{ senderId: senderId }, { senderId: receiverId }] }, { $or: [{ receiverId: receiverId }, { receiverId: senderId }] }]
    }
    let result = await chatSchema.findOne(query);
    if (!result) {
        req.messages = [{
            message: "Hey there! I am happy that you joined us!",
            mediaType: "text",
            receiverId: receiverId,
            createdAt: new Date().toISOString()
        }]
        await new chatSchema(req).save();
    }
}
const manageDonationData = async (senderUserId, userId, supporterCount, message, amount, coinName, certificate) => {
    if (supporterCount === true) {
        await updateUser({ _id: userId }, { $addToSet: { supporters: senderUserId }, $inc: { supporterCount: 1 } });
    }
    let findData = await findDonation({ userId: userId, status: { $ne: status.DELETE } });
    let obj = {
        userId: userId,
        history: [{
            senderUserId: senderUserId,
            message: message,
            amount, amount,
            coinName: coinName,
        }],
        certificateNumber: certificate
    }
    let updateQuery1 = {};
    let updateQuery = { $addToSet: { supporters: senderUserId } };
    if (coinName === "MASS") {
        obj.massBalance = amount;
        updateQuery.$inc = { massBalance: Number(amount) };
        updateQuery1.$inc = { massBalance: Number(amount) - 1 };
    }
    if (coinName === "BNB") {
        obj.bnbBalance = amount;
        updateQuery.$inc = { bnbBalace: Number(amount) };
        updateQuery1.$inc = { bnbBalace: Number(amount) - 1 };
    }
    if (coinName === "ETH") {
        obj.ethBalance = amount;
        updateQuery.$inc = { ethBalance: Number(amount) };
        updateQuery1.$inc = { ethBalance: Number(amount) - 1 };
    }
    if (coinName === "USDT") {
        obj.usdtBalance = amount;
        updateQuery.$inc = { usdtBalance: Number(amount) };
        updateQuery1.$inc = { usdtBalance: Number(amount) - 1 };
    }
    if (coinName === "WBTC") {
        obj.btcBalance = amount;
        updateQuery.$inc = { btcBalance: Number(amount) };
        updateQuery1.$inc = { btcBalance: Number(amount) - 1 };
    }
    let admin = await findUser({ userType: userType.ADMIN })
    let adminUp = await updateUser({ _id: admin._id }, updateQuery);
    if (adminUp) {
        await updateUser({ _id: userId }, updateQuery);
        await updateUser({ _id: senderUserId }, updateQuery1);
    }
    if (!findData) {
        await createDonation(obj);
    } else {
        let incrementQuery = {
            $push: {
                history: {
                    senderUserId: senderUserId,
                    message: message,
                    amount, amount,
                    coinName: coinName,
                }
            }
        };
        if (coinName === "MASS") {
            incrementQuery.$inc = { massBalance: Number(amount) };
        }
        if (coinName === "BNB") {
            incrementQuery.$inc = { bnbBalace: Number(amount) };
        }
        if (coinName === "ETH") {
            incrementQuery.$inc = { ethBalance: Number(amount) };
        }
        if (coinName === "USDT") {
            incrementQuery.$inc = { usdtBalance: Number(amount) };
        }
        if (coinName === "WBTC") {
            incrementQuery.$inc = { btcBalance: Number(amount) };
        }
        await updateDonation({ _id: findData._id }, incrementQuery);
    }
}
// USDT || BUSD || MASS || WARE || WBTC || ETH || BNB

const getCertificateNumber = () => {
    const digits = '0123456789';
    let txnId = '';
    for (let i = 0; i < 12; i++) {
        txnId += digits[Math.floor(Math.random() * 10)];
    }
    return txnId;
}
const getActiveUser = async () => {
    let userId = await userModel.find({ blockStatus: false }).select('_id');
    userId = userId.map(i => i._id);
    return userId;
}


const addUserIntoFeed = async (nftId, userId) => {
    let audienceRes = await postList({ nftId: { $in: [nftId] }, status: { $ne: status.DELETE } });
    audienceRes = audienceRes.map(i => i._id);
    await feedUpdateAll({ _id: { $in: audienceRes } }, { $addToSet: { users: userId } });

}
