import Express from "express";
import controller from "./controller";
import auth from "../../../../helper/auth";
import upload from '../../../../helper/uploadHandler';


export default Express.Router()

    .post('/ipfsUploadBase64', controller.ipfsUploadBase64)

    .use(auth.verifyToken)

    .post('/uploadNFT', controller.uploadNFT)
    .post('/collection', controller.createCollection)
    .get('/viewCollection/:_id', controller.viewCollection)
    .get('/myCollectionList', controller.myCollectionList)
    .put('/editCollection', controller.editCollection)
    .delete('/deleteCollection', controller.deleteCollection)
    .get('/listCollection', controller.listCollection)

    .use(upload.uploadFile)
    .post('/ipfsUpload', controller.ipfsUpload)
