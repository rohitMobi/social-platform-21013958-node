import Joi from "joi";
import _ from "lodash";
import config from "config";
import apiError from '../../../../helper/apiError';
import { pushNotification } from "../../../../helper/util";
import response from '../../../../../assets/response';
import responseMessage from '../../../../../assets/responseMessage';
import { userServices } from '../../services/user';
import { collectionServices } from '../../services/collection';
import { nftServices } from '../../services/nft';
import { notificationServices } from '../../services/notification';
import { collectionNftServices } from '../../services/collectionNft'
import { bundleServices } from '../../services/bundle';
import { auctionNftServices } from '../../services/auctionNft';
import { orderServices } from '../../services/order';
import { activityServices } from '../../services/userActivity';
import { feeServices } from '../../services/fee'
import { transactionServices } from '../../services/transaction';
const { createFee, findFee, updateFee, feeList } = feeServices
const { createTransaction, findTransaction, updateTransaction, transactionList, depositeList, depositeList1 } = transactionServices;
const { createActivity, findActivity, updateActivity, multiUpdateActivity, activityList, activityListWithSort } = activityServices;
const { userCheck, findUser, findUserData, createUser, updateUser, updateUserById, userSubscriberList } = userServices;
const { createNft, findNft, findNft1, updateNft, nftList1, nftSubscriber, nftSubscriber1, nftSubscriberList, nftList, nftPaginateSearch, myNftPaginateSearch, nftListWithoutShared, nftListWithAggregate, listAllNft, multiUpdate, nftListWithAggregatePipeline, findNftWithPopulateDetails } = nftServices;
const { createNotification, findNotification, updateNotification, multiUpdateNotification, notificationList, notificationListWithSort } = notificationServices;
const { createCollection, findCollection, updateCollection, collectionList, collectionPaginateSearch, myCollectionPaginateSearch,collectionSearchListWithToken } = collectionServices;
const { createCollectionNft, findCollectionNft, updateCollectionNft, CollectionNftList } = collectionNftServices;
const { createBundle, findBundle, updateBundle, bundleList } = bundleServices;
const { createAuctionNft, listAuction, findAuctionNft, updateAuctionNft, auctionNftList, allNftAuctionList } = auctionNftServices;
const { createOrder, findOrder, updateOrder, orderList } = orderServices;


import commonFunction from '../../../../helper/util';

import status from '../../../../enums/status';

import userType from "../../../../enums/userType";

import fs from 'fs';
import ipfsClient from 'ipfs-http-client';
const ipfs = ipfsClient({ host: 'ipfs.infura.io', port: '5001', protocol: 'https' });
import base64ToImage from 'base64-to-image';
import doAsync from 'doasync';

const rawImage = 'rawImage/'
//************************************************ Web3 ******************************************/

import Web3 from 'web3';
import ethers from 'ethers';
import { from } from "responselike";
import { log } from "console";

let NFTTokenABI = config.get('NFTTokenABI');

NFTTokenABI = NFTTokenABI.map(method => ({ ...method }));
var NFTTokenContract = config.get('NFTTokenContract');

let openMarketPlaceABI = config.get('openMarketPlaceABI');
openMarketPlaceABI = openMarketPlaceABI.map(method => ({ ...method }));
const OpenMarketplaceContract = config.get('OpenMarketplaceContract');

let BundleABI = config.get('BundleABI');
BundleABI = BundleABI.map(method => ({ ...method }));
// const BundleContract = config.get('BundleContract');

let IERC20ABI = config.get('IERC20ABI');

let testnode = config.get('testnode');
let web3 = new Web3(new Web3.providers.HttpProvider(testnode));


let NFTContract = new web3.eth.Contract(NFTTokenABI, NFTTokenContract);
let openMarketPlaceContract = new web3.eth.Contract(openMarketPlaceABI, OpenMarketplaceContract);
// let bundleContract = new web3.eth.Contract(BundleABI, BundleContract);
var adminAddress = config.get('adminAddress');
var adminPrivateKey = config.get('adminPrivateKey');



const mnemonic = config.get('mnemonic');
const blockchainBaseUrl = config.get('blockchainBaseUrl');
const blockchainUrl = config.get('blockchainTestnetBaseUrl');
// const blockchainUrl = config.get('blockchainMainnetBaseUrl');
// import binance from '../../binance/binance'
export class nftController {

    /**
     * @swagger
     * /nft/ipfsUpload:
     *   post:
     *     tags:
     *       - USER NFT
     *     description: ipfsUpload
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: file
     *         description: file
     *         in: formData
     *         type: file
     *         required: true
     *     responses:
     *       creatorAddress: Joi.string().optional(),
     *       200:
     *         description: Returns success message
     */
    async ipfsUpload(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            const fileName = req.files[0].filename;
            const filePath = req.files[0].path;
            const fileHash = await addFile(fileName, filePath);
            await deleteFile(filePath);
            let tokenData = {
                image: "https://ipfs.io/ipfs/" + fileHash // hash
            }
            let ipfsRes = await ipfsUpload(tokenData);
            let result = { ipfsHash: ipfsRes, fileHash: fileHash, imageUrl: tokenData.image };
            return res.json(new response(result, responseMessage.DETAILS_FETCHED));
        }
        catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /nft/ipfsUploadBase64:
     *   post:
     *     tags:
     *       - USER NFT
     *     description: ipfsUploadBase64
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: image
     *         description: image?? base 64
     *         in: formData
     *         required: true
     *     responses:
     *       creatorAddress: Joi.string().optional(),
     *       200:
     *         description: Returns success message
     */
    async ipfsUploadBase64(req, res, next) {
        try {
            // let userResult = await findUser({ _id: req.userId });
            // if (!userResult) {
            //     throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            // }
            const fileHash = await addBase64File(req.body.image);
            let tokenData = {
                image: "https://ipfs.io/ipfs/" + fileHash // hash
            }
            let ipfsRes = await ipfsUpload(tokenData);
            let result = { ipfsHash: ipfsRes, fileHash: fileHash, imageUrl: tokenData.image };
            return res.json(new response(result, responseMessage.DETAILS_FETCHED));
        }
        catch (error) {
            return next(error);
        }
    }

    /**
    * @swagger
    * /nft/uploadNFT:
    *   post:
    *     tags:
    *       - USER NFT
    *     description: uploadNFT
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: token
    *         description: token
    *         in: header
    *         required: true
    *       - name: tokenName
    *         description: tokenName
    *         in: formData
    *         required: false
    *       - name: description
    *         description: description
    *         in: formData
    *         required: false
    *       - name: image
    *         description: image
    *         in: formData
    *         required: false
    *     responses:
    *       creatorAddress: Joi.string().optional(),
    *       200:
    *         description: Returns success message
    */
    async uploadNFT(req, res, next) {
        const validationSchema = {
            tokenName: Joi.string().optional(),
            description: Joi.string().optional(),
            image: Joi.string().optional(),
        }
        try {
            const { tokenName, description, image } = await Joi.validate(req.body, validationSchema);
            let tokenData = {
                name: tokenName ? tokenName : "Test",
                description: description ? description : "Testing Data",
                image: image // hash
            }
            let ipfsRes = await ipfsUpload(tokenData);
            tokenData.ipfsHash = ipfsRes;
            return res.json(new response(tokenData, responseMessage.DETAILS_FETCHED));
        }
        catch (error) {
            return next(error);
        }
    }
    /**
     * @swagger
     * /nft/collection:
     *   post:
     *     tags:
     *       - COLLECTION
     *     description: createCollection
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: createCollection
     *         description: createCollection
     *         in: body
     *         required: true
     *         schema:
     *           $ref: '#/definitions/createCollection'
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async createCollection(req, res, next) {
        const validationSchema = {
            name: Joi.string().allow("").optional(),
            title: Joi.string().allow("").optional(),
            amount: Joi.string().required(),
            description: Joi.string().required(),
            image: Joi.string().required(),
            duration: Joi.string().required(),
        }
        try {
            const validatedBody = await Joi.validate(req.body, validationSchema);
            var { name, description, image, duration, amount, title } = validatedBody;
            let userResult = await findUser({ _id: req.userId, userType: userType.USER });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            if (image) {
                image = await commonFunction.getSecureUrl(image);
            }
            // let adminRes = await findUser({ userType: userType.ADMIN, status: { $ne: status.DELETE } })
            // let feeRes = await findFee({ type: "COLLECTION", status: { $ne: status.DELETE } })
            // if (parseFloat(feeRes.amount) >= parseFloat(userResult.bnbBalace) && parseFloat(feeRes.amount) <= parseFloat(amount)) {
            //     throw apiError.notFound(responseMessage.LOW_BALANCE)
            // }
            // await updateUser({ _id: adminRes._id }, { bnbBalace: adminRes.bnbBalace + parseFloat(feeRes.amount) })
            // await updateUser({ _id: userResult._id }, { bnbBalace: userResult.bnbBalace - parseFloat(feeRes.amount) })
            var obj = {
                name: name,
                title: title,
                description: description,
                image: image,
                userId: userResult._id,
                duration: duration,
                amount: amount
            };
            var result = await createCollection(obj);
            let obj1 = {
                title: "Add a new collection.",
                desctiption: "You add a new collection .",
                type: "COLLECTION",
                userId: userResult._id,
                collectionId: result._id,
            }
            await createActivity(obj1);
            // await createTransaction({
            //     userId: userResult._id,
            //     collectionId: result._id,
            //     commission: feeRes.amount,
            //     transactionType: "COLLECTION_SHARE_AMOUNT",
            // })
            // await createTransaction({
            //     userId: adminRes._id,
            //     collectionId: result._id,
            //     amount: feeRes.amount,
            //     transactionType: "COLLECTION_RECEIVE_AMOUNT",
            // })
            return res.json(new response(result, responseMessage.COLLECTION_ADDED));
        }
        catch (error) {
            console.log(error)
            return next(error);
        }
    }


    /**
     * @swagger
     * /nft/viewCollection/{_id}:
     *   get:
     *     tags:
     *       - COLLECTION
     *     description: viewCollection
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: _id
     *         description: _id
     *         in: path
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async viewCollection(req, res, next) {
        const validationSchema = {
            _id: Joi.string().required()
        }
        try {
            const { _id } = await Joi.validate(req.params, validationSchema);
            let userResult = await findUser({ _id: req.userId, userType: userType.USER });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            var bundleResult = await findCollection({ _id: _id, status: { $ne: status.DELETE } });
            if (!bundleResult) {
                throw apiError.conflict(responseMessage.DATA_NOT_FOUND);
            }
            return res.json(new response(bundleResult, responseMessage.DETAILS_FETCHED));
        }
        catch (error) {
            return next(error);
        }
    }

    // edit Collection 
    /**
     * @swagger
     * /nft/editCollection:
     *   put:
     *     tags:
     *       - COLLECTION
     *     description: editCollection
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: editCollection
     *         description: editCollection
     *         in: body
     *         required: true
     *         schema:
     *           $ref: '#/definitions/editCollection'
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async editCollection(req, res, next) {
        const validationSchema = {
            _id: Joi.string().required(),
            name: Joi.string().optional(),
            title: Joi.string().optional(),
            amount: Joi.string().optional(),
            description: Joi.string().optional(),
            image: Joi.string().optional(),
            duration: Joi.string().optional(),
        }
        try {
            var validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: userId, userType: userType.ADMIN });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            if (validatedBody.image) {
                validatedBody.image = await commonFunction.getSecureUrl(validatedBody.image);
            }
            var bundleResult = await findCollection({ _id: validatedBody._id, status: { $ne: status.DELETE } });
            if (!bundleResult) {
                throw apiError.conflict(responseMessage.DATA_NOT_FOUND);
            }
            var result = await updateCollection({ _id: bundleResult._id }, validatedBody);
            return res.json(new response(result, responseMessage.DETAILS_FETCHED));
        }
        catch (error) {
            return next(error);
        }
    }

    // delete Collection
    /**
     * @swagger
     * /nft/deleteCollection:
     *   delete:
     *     tags:
     *       - COLLECTION
     *     description: deleteCollection
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: _id
     *         description: _id
     *         in: query
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async deleteCollection(req, res, next) {
        const validationSchema = {
            _id: Joi.string().required(),
        }
        try {
            const { _id } = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, userType: userType.ADMIN });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            var bundleResult = await findCollection({ _id: _id, status: { $ne: status.DELETE } });
            if (!bundleResult) {
                throw apiError.conflict(responseMessage.DATA_NOT_FOUND);
            }
            var result = await updateCollection({ _id: bundleResult._id }, { status: status.DELETE });
            return res.json(new response(result, responseMessage.DETAILS_FETCHED));
        }
        catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /nft/myCollectionList:
     *   get:
     *     tags:
     *       - COLLECTION
     *     description: myCollectionList
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: search
     *         description: search
     *         in: query
     *         required: false
     *       - name: fromDate
     *         description: fromDate
     *         in: query
     *         required: false
     *       - name: toDate
     *         description: toDate
     *         in: query
     *         required: false
     *       - name: page
     *         description: page
     *         in: query
     *         type: integer
     *         required: false
     *       - name: limit
     *         description: limit
     *         in: query
     *         type: integer
     *         required: false
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async myCollectionList(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.number().optional(),
            limit: Joi.number().optional(),
        };
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId, userType: userType.USER });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let dataResults = await myCollectionPaginateSearch(validatedBody, userResult._id);
            if (dataResults.docs.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            }
            return res.json(new response(dataResults, responseMessage.DATA_FOUND));
        }
        catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /nft/listCollection:
     *   get:
     *     tags:
     *       - COLLECTION
     *     description: listCollection
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: search
     *         description: search
     *         in: query
     *         required: false
     *       - name: fromDate
     *         description: fromDate
     *         in: query
     *         required: false
     *       - name: toDate
     *         description: toDate
     *         in: query
     *         required: false
     *       - name: page
     *         description: page
     *         in: query
     *         type: integer
     *         required: false
     *       - name: limit
     *         description: limit
     *         in: query
     *         type: integer
     *         required: false
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async listCollection(req, res, next) {
        const validationSchema = {
            search: Joi.string().optional(),
            fromDate: Joi.string().optional(),
            toDate: Joi.string().optional(),
            page: Joi.number().optional(),
            limit: Joi.number().optional(),
        };
        try {
            const validatedBody = await Joi.validate(req.query, validationSchema);
            const paginateGood = (array, page_size, page_number) => {
                return array.slice((page_number - 1) * page_size, page_number * page_size);
            };
            let userResult = await findUser({ _id: req.userId, status: { $ne: status.DELETE } });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let dataResults = await collectionSearchListWithToken(validatedBody);
            if (dataResults.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            }
            let blockUserRes = []
            for (let i = 0; i < dataResults.length; i++) {
                if (!userResult.blockedUser.includes(dataResults[i].userId._id)) {
                    blockUserRes.push(dataResults[i])
                }
            }
            if (blockUserRes.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            }
            let options2 = {
                page: parseInt(req.query.page) || 1,
                limit: parseInt(req.query.limit) || 10,
            }
            let properResult = {
                docs: paginateGood(blockUserRes, options2.limit, options2.page),
                total: blockUserRes.length,
                limit: options2.limit,
                page: options2.page,
                pages: Math.ceil(blockUserRes.length / options2.limit)
            }
            if (properResult.docs.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND)
            }
            return res.json(new response(properResult, responseMessage.DATA_FOUND));
        }
        catch (error) {
            return next(error);
        }

    }



}

export default new nftController()

const ipfsUpload = async (tokenData) => {
    try {
        const { cid } = await ipfs.add({ content: JSON.stringify(tokenData) }, { cidVersion: 0, hashAlg: 'sha2-256' });
        await ipfs.pin.add(cid);
        return cid.toString()
    } catch (error) {
        return error;
    }
}

const addFile = async (fileName, filePath) => {
    const file = fs.readFileSync(filePath);
    const fileAdded = await ipfs.add({ path: fileName, content: file }, { cidVersion: 0, hashAlg: 'sha2-256' });
    const fileHash = fileAdded.cid.toString();
    await ipfs.pin.add(fileAdded.cid);
    return fileHash;
}

const addBase64File = async (base64) => {
    let fileName = "image";
    var optionalObj = { 'fileName': fileName, 'type': 'png' };
    var imageInfo = base64ToImage(base64, rawImage, optionalObj);
    let filePath = `${rawImage}${fileName}.png`;
    const file = await readData(filePath);
    const fileAdded = await ipfs.add({ path: fileName, content: file }, { cidVersion: 0, hashAlg: 'sha2-256' });
    const fileHash = fileAdded.cid.toString();
    await ipfs.pin.add(fileAdded.cid);
    deleteFile(filePath);
    return fileHash;
}

const readData = async (path) => {
    return new Promise((resolve, reject) => {
        doAsync(fs).readFile(path).then((data) => {
            resolve(data)
        })
    })
}

const deleteFile = async (filePath) => {
    fs.unlink(filePath, (deleteErr) => {
        if (deleteErr) {
            return deleteErr;
        }
    })
}

const notificattionToAllSubscriber = async (subscriberList, description, image) => {
    for (let i of subscriberList) {
        let obj = {
            title: `New Bundle Alert!`,
            notificationType: "Bundle_Create",
            description: description,
            userId: i,
            image: image
        }
        await createNotification(obj);
    }

}