import Joi from "joi";
import _ from "lodash";
import config from "config";
import userModel from "../../../../models/user";
import apiError from '../../../../helper/apiError';
import response from '../../../../../assets/response';
import responseMessage from '../../../../../assets/responseMessage';
import { userServices } from '../../services/user';
import { nftServices } from '../../services/nft';
import { orderServices } from '../../services/order';
import { bidServices } from '../../services/bid';
import { auctionNftServices } from '../../services/auctionNft';
import { notificationServices } from '../../services/notification';
import { transactionServices } from '../../services/transaction';
import { activityServices } from '../../services/userActivity';
import { postServices } from '../../services/post';
import { pushNotification } from "../../../../helper/util";
import { feeServices } from '../../services/fee'
const { createFee, findFee, updateFee, feeList } = feeServices
const { createUserPost, findOnePost, updatePost, listPost, paginatePostSearch, paginateAllPostSearch } = postServices;
const { createActivity, findActivity, updateActivity, multiUpdateActivity, activityList, activityListWithSort } = activityServices;
const { userCheck, profileSubscribeList, profileSubscriberList, userCount, checkUserExists, emailMobileExist, latestUserListWithPagination, createUser, findUser, multiUpdateForUser, findUserData, updateUser, updateUserById, userAllDetails, userAllDetailsByUserName, checkSocialLogin, userSubscriberListWithPagination, userSubscriberList } = userServices;
const { createNft, findNft, updateNft, nftList, nftPaginateSearch, myNftPaginateSearch } = nftServices;
const { createOrder, findOrder, findOrder1, findOrder2, findOrderWithPopulate, updateOrder, orderList, soldOrderList } = orderServices;
const { createBid, findBid, updateBid, updateManyBid, bidList } = bidServices;
const { createAuctionNft, findAuctionNft, updateAuctionNft, auctionNftList, allNftAuctionList, allmyNftAuctionList, allmyNftAuctionListBuy } = auctionNftServices;
const { createNotification, findNotification, updateNotification, notificationList } = notificationServices;
const { createTransaction, findTransaction, updateTransaction, transactionList, depositeList, depositeList1 } = transactionServices;

import commonFunction from '../../../../helper/util';
import status from '../../../../enums/status';
import userType from "../../../../enums/userType";
import Web3 from 'web3';
import ethers from 'ethers';
import moment from 'moment';

export class bidController {

    /**
     * @swagger
     * /bid/createBid:
     *   post:
     *     tags:
     *       - USER BID
     *     description: createBid
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: createBid
     *         description: createBid
     *         in: body
     *         required: true
     *         schema:
     *           $ref: '#/definitions/createBid'
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async createBid(req, res, next) {
        const validationSchema = {
            auctionId: Joi.string().required(),
            name: Joi.string().optional(),
            amountBid: Joi.string().optional(),
            date: Joi.string().optional(),
        }
        try {
            const validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUserData({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let auctionRes = await findAuctionNft({ _id: validatedBody.auctionId, userId: { $ne: userResult._id }, isSold: false, status: { $ne: status.DELETE } });
            if (!auctionRes) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            }
            let userResDeviceToken = await findUser({ _id: auctionRes.userId._id })
            var name = userResDeviceToken.name || userResDeviceToken.userName
            var bidResult = await findBid({ auctionPostId: auctionRes._id, userId: userResult._id, bidStatus: "PENDING", status: { $ne: status.DELETE } });
            if (bidResult) {
                let activityResult = {
                    userId: userResult._id,
                    bidId: bidResult._id,
                    title: "Update bid",
                    desctiption: "Bid updated successfully.",
                    type: "BID"
                }
                await createActivity(activityResult)
                let updateRes = await updateBid({ _id: bidResult._id }, validatedBody)
                await createNotification({
                    title: `New Bid!`,
                    description: `${name} bid your auction.`,
                    userId: userResDeviceToken._id,
                    notificationType: "BID_AUCTION",
                    bidBy: userResult._id,
                    bidId: bidResult._id
                });
                if (userResDeviceToken.deviceToken) {
                    let message = {
                        to: userResDeviceToken.deviceToken,
                        data: {
                            title: `New Bid!`,
                            body: `${name} bid your auction.`,
                            userId: userResDeviceToken._id,
                            notificationType: "BID_AUCTION",
                            bidBy: userResult._id,
                            bidId: bidResult._id,
                            sound: 'default'
                        },
                        notification: {
                            title: `New Bid!`,
                            body: `${name} bid your auction.`,
                            sound: 'default'
                        }
                    };
                    await commonFunction.pushNotification(message)
                }
                return res.json(new response(updateRes, responseMessage.BID_ADDED));
            }
            validatedBody.userId = userResult._id;
            validatedBody.auctionPostId = auctionRes._id;
            var result = await createBid(validatedBody);
            let activityResult = {
                userId: userResult._id,
                bidId: result._id,
                title: "Create bid",
                desctiption: "Bid added successfully.",
                type: "BID"
            }
            await createActivity(activityResult)
            await updateAuctionNft({ _id: auctionRes._id }, { $addToSet: { bidId: result._id } });
            await createNotification({
                title: `New Bid!`,
                description: `${name} bid your auction.`,
                userId: userResDeviceToken._id,
                notificationType: "BID_AUCTION",
                bidBy: userResult._id,
                bidId: result._id
            });
            if (userResDeviceToken.deviceToken) {
                let message = {
                    to: userResDeviceToken.deviceToken,
                    data: {
                        title: `New Bid!`,
                        body: `${name} bid your auction.`,
                        userId: userResDeviceToken._id,
                        notificationType: "BID_AUCTION",
                        bidBy: userResult._id,
                        bidId: result._id,
                        sound: 'default'
                    },
                    notification: {
                        title: `New Bid!`,
                        body: `${name} bid your auction.`,
                        sound: 'default'
                    }
                };
                await commonFunction.pushNotification(message)
            }
            return res.json(new response(result, responseMessage.BID_ADDED));
        }
        catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /bid/viewBid/{_id}:
     *   get:
     *     tags:
     *       - USER BID
     *     description: viewBid
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: _id
     *         description: _id
     *         in: path
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async viewBid(req, res, next) {
        const validationSchema = {
            _id: Joi.string().required()
        }
        try {
            const { _id } = await Joi.validate(req.params, validationSchema);
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            var bidResult = await findBid({ _id: _id, status: { $ne: status.DELETE } });
            if (!bidResult) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            }
            return res.json(new response(bidResult, responseMessage.DETAILS_FETCHED));
        }
        catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /bid/editBid:
     *   put:
     *     tags:
     *       - USER BID
     *     description: editBid
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: editBid
     *         description: editBid
     *         in: body
     *         required: true
     *         schema:
     *           $ref: '#/definitions/editBid'
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async editBid(req, res, next) {
        const validationSchema = {
            _id: Joi.string().required(),
            name: Joi.string().optional(),
            amountBid: Joi.string().optional(),
            date: Joi.string().optional(),
        }
        try {
            var validatedBody = await Joi.validate(req.body, validationSchema);
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            var bidResult = await findBid({ _id: validatedBody._id, userId: userResult._id, status: { $ne: status.DELETE } });
            if (!bidResult) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            }
            var result = await updateBid({ _id: bidResult._id }, validatedBody);
            return res.json(new response(result, responseMessage.DETAILS_FETCHED));
        }
        catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /bid/deleteBid:
     *   delete:
     *     tags:
     *       - USER BID
     *     description: deleteBid
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: _id
     *         description: _id
     *         in: query
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async deleteBid(req, res, next) {
        const validationSchema = {
            _id: Joi.string().required(),
        }
        try {
            const { _id } = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            var bidResult = await findBid({ _id: _id, userId: userResult._id, status: { $ne: status.DELETE } });
            if (!bidResult) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            }
            var result = await updateBid({ _id: bidResult._id }, { status: status.DELETE });
            return res.json(new response(result, responseMessage.DETAILS_FETCHED));
        }
        catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /bid/acceptBid:
     *   post:
     *     tags:
     *       - USER BID
     *     description: acceptBid
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: _id
     *         description: _id
     *         in: query
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async acceptBid(req, res, next) {
        const validationSchema = {
            _id: Joi.string().required(),
        }
        try {
            const { _id } = await Joi.validate(req.query, validationSchema);
            let userResult = await findUserData({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let postRes = await findAuctionNft({ $or: [{ userId: userResult._id }, { buyerId: userResult._id }], bidId: _id, status: { $ne: status.DELETE } })
            if (!postRes) {
                throw apiError.notFound(responseMessage.POST_NOT_FOUND);
            }
            var bidResult = await findBid({ auctionPostId: postRes._id, bidStatus: "PENDING", status: { $ne: status.DELETE } });
            if (!bidResult) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            }
            let userRes = await findUserData({ _id: bidResult.userId, status: { $ne: status.DELETE } })
            if (!userRes) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            if (parseFloat(bidResult.amountBid) >= parseFloat(userRes.bnbBalace)) {
                throw apiError.notFound(responseMessage.LOW_BALANCE)
            } else {
                let postResult = await findOnePost({ _id: postRes.postId })
                let postObj = {
                    buyerId: bidResult.userId,
                    amount: bidResult.amount,
                    creatorId: postResult.creatorId,
                    previousCreatorId: postResult.buyerId,
                    collectionId: postResult.collectionId,
                    mediaUrl: postResult.mediaUrl,
                    postTitle: postResult.postTitle,
                    details: postResult.details,
                    royality: postResult.royality,
                    isBuy: true,
                    type: "POST"
                }
                var savePost = await createUserPost(postObj)
                let obj = {
                    buyerId: bidResult.userId,
                    amount: bidResult.amountBid,
                    creatorId: postRes.userId,
                    postId: savePost._id,
                    title: postRes.title,
                    mediaUrl: postRes.mediaUrl,
                    details: postRes.details,
                    isBuy: true
                }
                await createAuctionNft(obj);
                let activityResult = {
                    buyerId: bidResult.userId,
                    bidId: bidResult._id,
                    title: "Accept bid",
                    desctiption: "Bid accept successfully.",
                    type: "BID"
                }

                let adminRes = await findUser({ userType: userType.ADMIN, status: { $ne: status.DELETE } })
                let feeRes = await findFee({ type: "AUCTION", status: { $ne: status.DELETE } })
                await updateUser({ _id: adminRes._id }, { bnbBalace: adminRes.bnbBalace + (parseFloat(feeRes.amount) * Number(bidResult.amountBid)) / 100 })
                let finalAmount = parseFloat(bidResult.amountBid) - (parseFloat(feeRes.amount) * Number(bidResult.amountBid)) / 100
                console.log("finalAmount", finalAmount)
                let royalityResult = (parseFloat(postResult.royality) * Number(finalAmount)) / 100
                console.log("royalityResult", royalityResult)
                let secondCreatorAmount = parseFloat(finalAmount) - parseFloat(royalityResult)
                console.log("secondCreatorAmount", secondCreatorAmount)

                await createActivity(activityResult)
                await updateAuctionNft({ _id: postRes._id }, { isSold: true })
                await updatePost({ _id: postRes.postId }, { isSold: true })
                await updateUser({ _id: userResult._id }, { bnbBalace: userResult.bnbBalace + Number(secondCreatorAmount) })
                await updateUser({ _id: userRes._id }, { bnbBalace: userRes.bnbBalace - Number(bidResult.amountBid) })

                await updateUser({ _id: postResult.creatorId }, { $inc: { bnbBalace: +Number(royalityResult) } })

                var result = await updateBid({ _id: bidResult._id }, { bidStatus: "ACCEPTED" });

                await createTransaction({
                    userId: adminRes._id,
                    bidId: bidResult._id,
                    amount: (parseFloat(feeRes.amount) * Number(bidResult.amountBid)) / 100,
                    transactionType: "BID_ACCEPT_RECEIVE_COMMISSION",
                })
                await createTransaction({
                    userId: userResult._id,
                    bidId: bidResult._id,
                    amount: bidResult.amountBid,
                    transactionType: "BUY_AUCTION",
                })
                await createTransaction({
                    userId: postRes.userId,
                    bidId: bidResult._id,
                    commission: (parseFloat(feeRes.amount) * Number(bidResult.amountBid)) / 100,
                    amount: bidResult.amountBid,
                    transactionType: "SOLD_AUCTION",
                })
                var name = userResult.name || userResult.userName
                await createNotification({
                    title: `Bid accept!`,
                    description: `${name} bid your accept.`,
                    userId: bidResult.userId,
                    notificationType: "BID_ACCEPT",
                    bidId: bidResult._id
                });
                return res.json(new response(result, responseMessage.DETAILS_FETCHED));
            }
        }
        catch (error) {
            console.log(error)
            return next(error);
        }
    }

    /**
     * @swagger
     * /bid/rejectBid:
     *   put:
     *     tags:
     *       - USER BID
     *     description: rejectBid
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: _id
     *         description: _id
     *         in: query
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async rejectBid(req, res, next) {
        const validationSchema = {
            _id: Joi.string().required(),
        }
        try {
            const { _id } = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let postRes = await findAuctionNft({ userId: userResult._id, bidId: _id, status: { $ne: status.DELETE } })
            if (!postRes) {
                throw apiError.notFound(responseMessage.ACUTION_NOT_FOUND);
            }
            var bidResult = await findBid({ auctionPostId: postRes._id, bidStatus: "PENDING", status: { $ne: status.DELETE } });
            if (!bidResult) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            }
            let activityResult = {
                userId: userResult._id,
                bidId: bidResult._id,
                title: "Reject bid",
                desctiption: "Bid rejected successfully.",
                type: "BID"
            }
            await createActivity(activityResult)
            var name = userResult.name || userResult.userName
            await createNotification({
                title: `Bid reject!`,
                description: `${name} bid your reject.`,
                userId: bidResult.userId,
                notificationType: "BID_REJECT",
                bidId: bidResult._id
            });
            var result = await updateBid({ _id: bidResult._id }, { bidStatus: "REJECTED" });
            return res.json(new response(result, responseMessage.DETAILS_FETCHED));
        }
        catch (error) {
            return next(error);
        }
    }

    /**
     * @swagger
     * /bid/listBid:
     *   get:
     *     tags:
     *       - USER BID
     *     description: listBid
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *       - name: postId
     *         description: postId
     *         in: query
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async listBid(req, res, next) {
        const validationSchema = {
            postId: Joi.string().required(),
        }
        try {
            const { postId } = await Joi.validate(req.query, validationSchema);
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let postRes = await findOnePost({ userId: userResult._id, _id: postId, status: { $ne: status.DELETE } })
            if (!postRes) {
                throw apiError.notFound(responseMessage.POST_NOT_FOUND);
            }
            let dataResults = await bidList({ auctionPostId: postRes._id, status: { $ne: status.DELETE } });
            if (dataResults.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            }
            return res.json(new response(dataResults, responseMessage.DATA_FOUND));
        }
        catch (error) {
            return next(error);
        }

    }

    /**
     * @swagger
     * /bid/myBid:
     *   get:
     *     tags:
     *       - USER BID
     *     description: myBid
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: token
     *         description: token
     *         in: header
     *         required: true
     *     responses:
     *       200:
     *         description: Returns success message
     */
    async myBid(req, res, next) {
        try {
            let userResult = await findUser({ _id: req.userId });
            if (!userResult) {
                throw apiError.notFound(responseMessage.USER_NOT_FOUND);
            }
            let dataResults = await bidList({ userId: userResult._id, status: { $ne: status.DELETE } });
            if (dataResults.length == 0) {
                throw apiError.notFound(responseMessage.DATA_NOT_FOUND);
            }
            return res.json(new response(dataResults, responseMessage.DATA_FOUND));
        }
        catch (error) {
            return next(error);
        }

    }


}

export default new bidController()
