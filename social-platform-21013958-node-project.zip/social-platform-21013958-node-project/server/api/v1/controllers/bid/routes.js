import Express from "express";
import controller from "./controller";
import auth from "../../../../helper/auth";
import upload from '../../../../helper/uploadHandler';


export default Express.Router()


    .use(auth.verifyToken)
    .post('/createBid', controller.createBid)
    .get('/viewBid/:_id', controller.viewBid)
    .put('/editBid', controller.editBid)
    .delete('/deleteBid', controller.deleteBid)
    .post('/acceptBid', controller.acceptBid)
    .put('/rejectBid', controller.rejectBid)
    .get('/listBid', controller.listBid)
    .get('/myBid', controller.myBid)





