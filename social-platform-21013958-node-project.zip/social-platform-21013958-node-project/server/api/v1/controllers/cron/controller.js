import { CronJob } from "cron";
import collectionSubscriptionModel from "../../../../models/collectionSubscription";
import moment from "moment";
import chatSchema from '../../../../models/chatting';
import userModel from "../../../../models/user";
import storyModel from "../../../../models/story";
import { userServices } from '../../services/user';
import { postPromotionServices } from '../../services/postPromotion'
import { disappearServices } from '../../services/disappear'
const { postPromotionList, updatePostPromotion } = postPromotionServices
const { createDisappear, findDisappear, updateDisappear } = disappearServices
const { updateUser, deleteUser, creatorList } = userServices;


let subscriptionListFunction = async () => {
  let subscriptionList = await collectionSubscriptionModel.find({ status: 'ACTIVE' });
  for (let obj of subscriptionList) {
    // count++;
    let now = moment(moment().toISOString());
    let duration = moment.duration(now.diff(obj.updatedAt));
    let dayDiffrence = obj.duration - duration.asDays();
    if (dayDiffrence < 0) {
      await collectionSubscriptionModel.findByIdAndUpdate({ _id: obj._id }, { $set: { status: 'DELETE' } }, { new: true });
    }
  }
}

let usersFunction = async () => {
  let users = await userModel.find({ status: { $ne: 'DELETE' }, userType: 'User' });
  for (let user of users) {
    let userStories = await storyModel.find({ userId: user._id, timeExpired: { $gte: moment().toISOString() }, status: { $ne: 'DELETE' } });
    if (userStories.length == 0) {
      await userModel.findByIdAndUpdate({ _id: user._id }, { $set: { isStory: false } }, { new: true });
    }
  }
}

let promotionListResFunction = async () => {
  let promotionListRes = await postPromotionList({ status: 'ACTIVE' });
  for (let obj of promotionListRes) {
    let now = moment(moment().toISOString());
    let duration = moment.duration(now.diff(obj.createdAt));
    let dayDiffrence = obj.dateTime - duration.asDays();
    if (dayDiffrence < 0) {
      await updatePostPromotion({ _id: obj._id }, { $set: { status: 'DELETE' } });
    }
  }
}

let userResFunction = async () => {
  let userRes = await creatorList({ status: { $ne: 'DELETE' }, otpVerification: false });
  var futureDate = Date.now()
  for (var i = 0; i < userRes.length; i++) {
    let otpTimeDiff = futureDate - userRes[i].otpTime
    if (otpTimeDiff > (60000 * 7)) {
      let updateRes = await deleteUser({ _id: userRes[i]._id })
    }

  }
}

let userMightFunction = async () => {
  let users = await userModel.find({ status: { $ne: 'DELETE' }, userType: 'User' });
  for (var i = 0; i < users.length; i++) {
    for (var j = i; j < users.length; j++) {
      if (users[i].interest.length != 0 && users[j].interest.length != 0 && users[i]._id.toString() != users[j]._id.toString()) {
        for (var x = 0; x < users[i].interest.length; x++) {
          for (var y = 0; y < users[j].interest.length; y++) {
            if (users[i].interest[x] == users[j].interest[y]) {
              await updateUser({ _id: users[i]._id }, { $addToSet: { mightUser: users[j]._id } })
              await updateUser({ _id: users[j]._id }, { $addToSet: { mightUser: users[i]._id } })
            }
          }
        }
      }
    }

  }
}

let chatResFunction = async () => {
  let chatRes = await chatSchema.find({ status: { $ne: 'DELETE' } });
  // let count = 0;
  for (var i = 0; i < chatRes.length; i++) {
    // count++;
    for (var j = 0; j < chatRes[i].messages.length; j++) {
      let dataRes = await findDisappear({ $and: [{ $or: [{ senderId: chatRes[i].senderId }, { senderId: chatRes[i].receiverId }] }, { $or: [{ receiverId: chatRes[i].receiverId }, { receiverId: chatRes[i].senderId }] }] })
      var today = new Date();
      if (dataRes) {
        let aftertime = new Date(today.getTime() + 1000 * dataRes.time);
        if (chatRes[i].messages[j].messageStatus == "Read" && chatRes[i].messages[j].disappear == true && (chatRes[i].messages[j].updatedAt).getTime() <= aftertime.getTime()) {
          await chatSchema.updateMany(
            {
              _id: chatRes[i]._id,
              "messages._id": chatRes[i].messages[j]._id,
            },
            {
              $set: { "messages.$.senderDelete": true, "messages.$.receiverDelete": true }
            },
            { new: true })
        }
      }
    }

  }
}

let commonCron = new CronJob('*/5 * * * * *', async () => {
  await Promise.all([subscriptionListFunction(), usersFunction(), promotionListResFunction(), userResFunction(), userMightFunction(),chatResFunction()])
});




commonCron.start();

