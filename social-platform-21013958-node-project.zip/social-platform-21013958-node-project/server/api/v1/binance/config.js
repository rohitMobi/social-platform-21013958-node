const BNB_URL = 'https://data-seed-prebsc-1-s1.binance.org:8545/';
const balance='https://api-testnet.bscscan.com/api?module=account&action=balance&address='
const balanceApikey='GQWQPRVJXUI35NTS2VK4J8KEMZCRXJAI4S'
const gasPrice='https://ethgasstation.info/api/ethgasAPI.json?api-key=ce8da4d2e680dad6465330e7869efe101517aad8274be133e44a8119d5c0'

module.exports = {BNB_URL,balance,balanceApikey,gasPrice}