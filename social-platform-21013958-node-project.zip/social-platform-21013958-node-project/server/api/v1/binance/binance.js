const bip39 = require('bip39')
import axios from 'axios'
const { BncClient } = require("@binance-chain/javascript-sdk")
import config1 from './config'
const BNB_URL = config1.BNB_URL;
// const config1=require('../../../../config')
import config from 'config'
import crypto from '../../../helper/util';
const len = 32;
import csprng from 'secure-random';
import { hdkey } from 'ethereumjs-wallet';
import Web3 from "web3";
const EthereumTx = require('ethereumjs-tx').Transaction;
const Common = require('ethereumjs-common');
const web3 = new Web3(new Web3.providers.HttpProvider(BNB_URL));

var tokenContractAddress = config.get("tokenContractAddress");
var contractABI = config.get("IERC20ABI");
contractABI = contractABI.map(method => ({ ...method }));
let NFTContract = new web3.eth.Contract(contractABI, tokenContractAddress);



async function accountBalance(senderAddress) {
    const response = await axios.get(`${config1.balance}${senderAddress}&apikey=${config1.balanceApikey}`)
    // const response = await axios.get(`https://api.bscscan.com/api?module=account&action=balance&address=${senderAddress}&tag=latest&apikey=GQWQPRVJXUI35NTS2VK4J8KEMZCRXJAI4S`) ;
    let balance = web3.utils.fromWei(response.data.result, "ether");
    return Number(balance)
}

async function preTransfer(senderAddress, amountToSend) {
    const { fee } = await EthHelper()
    let balance = await accountBalance(senderAddress)
    if (balance - amountToSend - fee < 0) {
        return 'Low Balance'
    } else {
        console.log("Transfer Possible")
        return 'Transfer Possible'

    }
}

async function getCurrentGasPrices() {
    try {
        let response = await axios.get(`${config1.gasPrice}`);
        let prices = {
            low: response.data.safeLow / 10,
            medium: response.data.average / 10,
            high: response.data.fast / 10
        };
        return prices;
    } catch (error) {
        console.log("58 error===>", error);
        return error
    }
}

async function EthHelper() {
    let currentGasPrice = await getCurrentGasPrices();
    // console.log("currentGasPrice", currentGasPrice)
    let gasPrice = currentGasPrice.high * 1000000000
    let gasLimit = 21000;
    let fee = gasLimit * gasPrice;
    let txFee = Number(web3.utils.fromWei(fee.toString(), "ether"));
    return { fee: txFee, gasPrice: gasPrice }
}

module.exports = {
    generateAddress: async () => {
        try {
            const address = await crypto.generatePrivateKey();
            return address;
        } catch (error) {
            return error
        }
    },

    generateMnemonic: async () => {
        try {
            let mnemonic = bip39.generateMnemonic();
            return mnemonic;
        } catch (error) {
            return error
        }
    },
    generateBNBWallet: async (count, mnemonic) => {
        try {
            const seed = bip39.mnemonicToSeedSync(mnemonic);
            let hdwallet = hdkey.fromMasterSeed(seed);
            let path = `m/44'/60'/0'/0/${count}`;

            let wallet = hdwallet.derivePath(path).getWallet();
            let address = "0x" + wallet.getAddress().toString("hex");
            let privateKey = wallet.getPrivateKey().toString("hex");
            let obj = {
                address: address,
                privateKey: privateKey
            }
            return obj
        } catch (error) {
            return error
        }

    },


    getBalance: async (senderAddress) => {
        try {
            const response = await axios.get(`${config1.balance}${senderAddress}&apikey=${config1.balanceApikey}`)
            // const response = await axios.get(`https://api.bscscan.com/api?module=account&action=balance&address=${req.query.senderAddress}&tag=latest&apikey=GQWQPRVJXUI35NTS2VK4J8KEMZCRXJAI4S`)
            let balance = web3.utils.fromWei(response.data.result);
            return balance;
        }
        catch (error) {
            return error;
        }

    },

    withdraw: async (senderAddress, privateKey, recieverAddress, amountToSend) => {
        try {
            var nonce = await web3.eth.getTransactionCount(senderAddress);
            const { gasPrice } = EthHelper()

            const { status } = preTransfer(senderAddress, amountToSend)
            if (status == false) {
                return 'Low Balance'
            }

            let txObject = {
                "to": recieverAddress,
                "value": web3.utils.toHex(web3.utils.toWei(amountToSend.toString(), 'ether')),
                "gas": 21000,
                "gasPrice": gasPrice,
                "nonce": nonce,
                // "chainId": 3 // EIP 155 chainId - mainnet: 1, rinkeby: 4
            };

            const common = Common.default.forCustomChain(
                'mainnet',
                {
                    name: 'bnb',
                    networkId: '0x61',
                    chainId: '0x61',
                },
                "petersburg",
            );

            const transaction = new EthereumTx(txObject, { common: common });

            let privKey = Buffer.from(privateKey, 'hex');
            transaction.sign(privKey);

            const serializedTransaction = transaction.serialize();

            const raw = '0x' + Buffer.from(serializedTransaction).toString('hex')
            const signTransaction = web3.eth.sendSignedTransaction(raw)

            return { Hash: signTransaction.transactionHash };
        } catch (error) {
            return error
        }
    },


    transfer: async (senderAddress, privateKey, recieverAddress, balance) => {
        try {
            var nonce = await web3.eth.getTransactionCount(senderAddress);
            const { fee, gasPrice } = await EthHelper()
            let amountToSend = Number(balance) - Number(fee);
            amountToSend = amountToSend.toFixed(18);
            if (amountToSend > 0) {
                let txObject = {
                    "to": recieverAddress,
                    "value": web3.utils.toHex(web3.utils.toWei(amountToSend.toString(), 'ether')),
                    "gas": 21000,
                    "gasPrice": gasPrice,
                    "nonce": nonce,
                    // "chainId": 3 // EIP 155 chainId - testnet: 1, rinkeby: 4
                };
                const common = Common.default.forCustomChain(
                    'mainnet',
                    {
                        name: 'bnb',
                        networkId: '0x61',
                        chainId: '0x61',
                    },
                    "petersburg",
                );
                const transaction = new EthereumTx(txObject, { common: common });
                let privKey = Buffer.from(privateKey, 'hex');
                transaction.sign(privKey);
                const serializedTransaction = transaction.serialize();
                const signTransaction = await web3.eth.sendSignedTransaction('0x' + serializedTransaction.toString('hex'));
                return { Hash: signTransaction.transactionHash }
            }
        }
        catch (error) {
            console.log(error)
            return error
        }
    },

    getTokenBalance: async (fromAddress) => {
        var balance = await NFTContract.methods.balanceOf(fromAddress).call();
        // balance = web3.utils.toWei(balance);
        return { balance: balance }
    },

    tokenWithdraw: async (fromAddress, privateKey, toAddress, amount) => {
        try {
            // amount = BigInt(amount);
            // var balance = web3.utils.fromWei(amount.toString(), "ether");
            const { gasPrice } = await EthHelper()
            const Data = await NFTContract.methods.transfer(toAddress, amount.toString()).encodeABI();
            const rawTransaction = {
                to: tokenContractAddress,
                from: fromAddress,
                value: 0,
                gasPrice: gasPrice, // Always in Wei (30 gwei)
                gasLimit: web3.utils.toHex('2000000'), // Always in Wei
                data: Data // Setting the pid 12 with 0 alloc and 0 deposit fee

            };
            const signPromise = await web3.eth.accounts.signTransaction(rawTransaction, privateKey.toString());

            let result = await web3.eth.sendSignedTransaction(signPromise.rawTransaction)
            if (result) {
                return {
                    Success: true,
                    Hash: signPromise.transactionHash
                };
            }

        } catch (error) {
            console.log(error)
            return { Success: false }

        }
    },


    tokenTransferUserToUser: async (fromAddress, privateKey, recieverAddress, amountToSend) => {
        try {
            if (recieverAddress || privateKey || amountToSend) {
                //    console.log({ Message: `Invalid payment details.` })
            }
            // let { recieverAddress, privateKey, amountToSend } = req.body;
            const balance = web3.utils.toWei(amountToSend.toString());

            const Data = await NFTContract.methods.transfer(recieverAddress, balance.toString()).encodeABI();

            const rawTransaction = {
                to: tokenContractAddress,
                gasPrice: web3.utils.toHex('30000000000'), // Always in Wei (30 gwei)
                gasLimit: web3.utils.toHex('200000'), // Always in Wei
                data: Data // Setting the pid 12 with 0 alloc and 0 deposit fee
            };
            // console.log("rawTransaction==>>", rawTransaction)
            // console.log("privateKey====>>", privateKey)
            const signPromise = await web3.eth.accounts.signTransaction(rawTransaction, privateKey.toString());
            // console.log("signPromise====>", signPromise);

            let data = await web3.eth.sendSignedTransaction(signPromise.rawTransaction)
            if (data) {
                return { responseCode: 200, responseMessage: "Success", responseResult: data };
            }
        }
        catch (error) {
            // console.log("error==>>", error);
            console.log({ responseCode: 501, responseMessage: "Something went wrong!", error: error.message })

        }
    }

}


// let withdraw= async function withdraw  (senderAddress, privateKey, recieverAddress, amountToSend) {
//     try {
//         var nonce = await web3.eth.getTransactionCount(senderAddress);
//         const { gasPrice } = EthHelper()

//         const { status } = preTransfer(senderAddress, amountToSend)
//         if (status == false) {
//             return 'Low Balance'
//         }

//         let txObject = {
//             "to": recieverAddress,
//             "value": web3.utils.toHex(web3.utils.toWei(amountToSend.toString(), 'ether')),
//             "gas": 21000,
//             "gasPrice": gasPrice,
//             "nonce": nonce,
//             // "chainId": 3 // EIP 155 chainId - mainnet: 1, rinkeby: 4
//         };

//         const common = Common.default.forCustomChain(
//             'mainnet',
//             {
//                 name: 'bnb',
//                 networkId: '0x61',
//                 chainId: '0x61',
//             },
//             "petersburg",
//         );

//         const transaction = new EthereumTx(txObject, { common: common });

//         let privKey = Buffer.from(privateKey, 'hex');
//         transaction.sign(privKey);

//         const serializedTransaction = transaction.serialize();

//         const raw = '0x' + Buffer.from(serializedTransaction).toString('hex')
//         const signTransaction = web3.eth.sendSignedTransaction(raw)
//         console.log("=============>785",signTransaction.transactionHash)
//         return { Hash: signTransaction.transactionHash };
//     } catch (error) {
//         return error
//     }
// }
// withdraw("0x7defa5fe88931fdb15b46f48298154f67f7c6c9f","a78c2704a5c948cab0762ef1a1e89076b633d4061e3dbab7a362da1c256ce0e9","0x0EC5F5B4AAF32fcF53170F7030f3434508Dad94A",0.01)


